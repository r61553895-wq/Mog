package dev.pulsefx;

public enum Module {
    JUMP_CIRCLES("circles", "Jump Circles"),
    TRAIL("trail", "Trail"),
    HIT_FX("hit", "Hit FX"),
    HUD("hud", "HUD");

    public final String id, label;
    public boolean on = true;

    Module(String id, String label) { this.id = id; this.label = label; }
}
