package dev.pulsefx;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;

import java.util.concurrent.ThreadLocalRandom;

public class PulseFX implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(Effects::tick);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(Effects::render);
        HudRenderCallback.EVENT.register(Hud::render);

        // Hit effects: ring on the ground + a small particle burst
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (Module.HIT_FX.on && world.isClient && entity instanceof LivingEntity) {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                double cy = entity.getBodyY(0.5);
                for (int i = 0; i < 14; i++) {
                    world.addParticle(i % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.ENCHANTED_HIT,
                            entity.getX(), cy, entity.getZ(),
                            (r.nextDouble() - 0.5) * 0.5, r.nextDouble() * 0.35, (r.nextDouble() - 0.5) * 0.5);
                }
                Effects.addCircle(entity.getX(), entity.getY(), entity.getZ());
            }
            return ActionResult.PASS;
        });

        // /pulsefx <circles|trail|hit|hud> toggles a module
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            var root = ClientCommandManager.literal("pulsefx");
            for (Module m : Module.values()) {
                root.then(ClientCommandManager.literal(m.id).executes(ctx -> {
                    m.on = !m.on;
                    ctx.getSource().sendFeedback(Text.literal("§d[PulseFX] §f" + m.label + ": " + (m.on ? "§aON" : "§cOFF")));
                    return 1;
                }));
            }
            dispatcher.register(root);
        });
    }
}
