package dev.pulsefx;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** World-space effects. One batched draw call per frame, no per-frame allocations except the buffer. */
public final class Effects {
    private record Circle(double x, double y, double z, long start) {}

    private static final List<Circle> circles = new ArrayList<>();
    private static final ArrayDeque<Vec3d> trail = new ArrayDeque<>();
    private static boolean wasGround;

    private static final int TRAIL_MAX = 28, SEG = 40, MAX_CIRCLES = 12;
    private static final long LIFE = 900;
    private static final int C1 = 0x9B5CFF, C2 = 0x35E6FF; // purple -> cyan

    private Effects() {}

    public static void addCircle(double x, double y, double z) {
        if (circles.size() < MAX_CIRCLES) circles.add(new Circle(x, y, z, System.currentTimeMillis()));
    }

    /** Animated purple/cyan gradient, returns RGB. */
    public static int grad(float angle, float time) {
        float f = (MathHelper.sin(angle * 2f + time) + 1f) * 0.5f;
        int r = (int) MathHelper.lerp(f, (C1 >> 16) & 255, (C2 >> 16) & 255);
        int g = (int) MathHelper.lerp(f, (C1 >> 8) & 255, (C2 >> 8) & 255);
        int b = (int) MathHelper.lerp(f, C1 & 255, C2 & 255);
        return (r << 16) | (g << 8) | b;
    }

    public static float time() {
        return (System.currentTimeMillis() % 6000L) / 6000f * MathHelper.TAU;
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { circles.clear(); trail.clear(); return; }

        boolean ground = p.isOnGround();
        if (Module.JUMP_CIRCLES.on && wasGround && !ground && p.getVelocity().y > 0.1) {
            addCircle(p.getX(), p.getY(), p.getZ());
        }
        wasGround = ground;

        if (Module.TRAIL.on) {
            Vec3d pos = p.getPos(), last = trail.peekLast();
            if (last == null || last.squaredDistanceTo(pos) > 0.0004) trail.addLast(pos);
            else trail.pollFirst(); // standing still: trail fades away
            while (trail.size() > TRAIL_MAX) trail.pollFirst();
        } else trail.clear();

        long now = System.currentTimeMillis();
        circles.removeIf(c -> now - c.start > LIFE);
    }

    public static void render(WorldRenderContext ctx) {
        boolean doTrail = Module.TRAIL.on && trail.size() > 1;
        boolean doCircles = !circles.isEmpty();
        if (!doTrail && !doCircles) return;
        MatrixStack ms = ctx.matrixStack();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (ms == null || mc.player == null) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f m = ms.peek().getPositionMatrix();
        float time = time();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        long now = System.currentTimeMillis();
        for (Circle c : circles) {
            float t = (now - c.start) / (float) LIFE;
            float ease = 1f - (1f - t) * (1f - t) * (1f - t);
            float r = 0.4f + 1.7f * ease;
            float w = 0.38f * (1f - t * 0.5f);
            int a = (int) ((1f - t) * 220f);
            float cx = (float) (c.x - cam.x), cy = (float) (c.y + 0.03 - cam.y), cz = (float) (c.z - cam.z);
            ring(b, m, cx, cy, cz, r - w, r, 0, a, time);          // soft inner glow
            ring(b, m, cx, cy, cz, r, r + w * 0.35f, a, 0, time);  // thin outer edge
        }

        if (doTrail) {
            Vec3d cur = mc.player.getLerpedPos(ctx.tickCounter().getTickDelta(false));
            int n = trail.size() + 1, i = 0;
            Vec3d prev = null;
            for (Vec3d p : trail) {
                if (prev != null) seg(b, m, cam, prev, p, (i - 1) / (float) n, i / (float) n, time);
                prev = p; i++;
            }
            if (prev != null) seg(b, m, cam, prev, cur, (i - 1) / (float) n, i / (float) n, time);
        }

        BuiltBuffer built = b.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void seg(BufferBuilder b, Matrix4f m, Vec3d cam, Vec3d p0, Vec3d p1, float f0, float f1, float time) {
        float x0 = (float) (p0.x - cam.x), y0 = (float) (p0.y - cam.y), z0 = (float) (p0.z - cam.z);
        float x1 = (float) (p1.x - cam.x), y1 = (float) (p1.y - cam.y), z1 = (float) (p1.z - cam.z);
        int c0 = grad(f0 * 5f, time), c1 = grad(f1 * 5f, time);
        int lo0 = (int) (f0 * 170), lo1 = (int) (f1 * 170), hi0 = lo0 / 6, hi1 = lo1 / 6;
        float h = 0.9f;
        b.vertex(m, x0, y0 + 0.05f, z0).color(argb(c0, lo0));
        b.vertex(m, x0, y0 + h, z0).color(argb(c0, hi0));
        b.vertex(m, x1, y1 + h, z1).color(argb(c1, hi1));
        b.vertex(m, x1, y1 + 0.05f, z1).color(argb(c1, lo1));
    }

    private static void ring(BufferBuilder b, Matrix4f m, float cx, float cy, float cz,
                             float r0, float r1, int a0, int a1, float time) {
        for (int i = 0; i < SEG; i++) {
            float t0 = i * MathHelper.TAU / SEG, t1 = (i + 1) * MathHelper.TAU / SEG;
            float s0 = MathHelper.sin(t0), k0 = MathHelper.cos(t0), s1 = MathHelper.sin(t1), k1 = MathHelper.cos(t1);
            int c0 = grad(t0, time), c1 = grad(t1, time);
            b.vertex(m, cx + k0 * r0, cy, cz + s0 * r0).color(argb(c0, a0));
            b.vertex(m, cx + k0 * r1, cy, cz + s0 * r1).color(argb(c0, a1));
            b.vertex(m, cx + k1 * r1, cy, cz + s1 * r1).color(argb(c1, a1));
            b.vertex(m, cx + k1 * r0, cy, cz + s1 * r0).color(argb(c1, a0));
        }
    }

    private static int argb(int rgb, int a) {
        return (MathHelper.clamp(a, 0, 255) << 24) | (rgb & 0xFFFFFF);
    }
}
