package dev.pulsefx;

import net.minecraft.util.math.MathHelper;
import java.util.Locale;

public final class Setting {
    public enum Type { BOOL, NUM, MODE }

    public final Type type;
    public final String id, label;
    public boolean b;
    public float v, min, max, step;
    public String[] modes;
    public int mode;
    public boolean hue;
    public float anim, hover; // UI smoothing state

    private Setting(Type t, String id, String label) { this.type = t; this.id = id; this.label = label; }

    public static Setting bool(String id, String label, boolean def) {
        Setting s = new Setting(Type.BOOL, id, label); s.b = def; s.anim = def ? 1f : 0f; return s;
    }

    public static Setting num(String id, String label, float min, float max, float step, float def) {
        Setting s = new Setting(Type.NUM, id, label);
        s.min = min; s.max = max; s.step = step; s.v = def; s.anim = s.norm(); return s;
    }

    public static Setting mode(String id, String label, int def, String... modes) {
        Setting s = new Setting(Type.MODE, id, label); s.modes = modes; s.mode = def; return s;
    }

    public float norm() { return max == min ? 0f : (v - min) / (max - min); }

    public void setNorm(float n) {
        n = MathHelper.clamp(n, 0f, 1f);
        float r = min + n * (max - min);
        if (step > 0f) r = (float) (Math.round((r - min) / step) * step + min);
        v = MathHelper.clamp(r, min, max);
    }

    public String display() {
        switch (type) {
            case BOOL: return b ? "On" : "Off";
            case MODE: return modes[mode];
            default:
                if (step >= 1f) return String.format(Locale.ROOT, "%.0f", v);
                if (step >= 0.1f) return String.format(Locale.ROOT, "%.1f", v);
                return String.format(Locale.ROOT, "%.2f", v);
        }
    }
}
