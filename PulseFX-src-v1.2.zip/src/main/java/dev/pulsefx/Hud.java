package dev.pulsefx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import java.util.Locale;

public final class Hud {
    private Hud() {}

    private static final Fx.Clock CLOCK = new Fx.Clock();
    private static final int PILL = 0xB4101018;

    private static float hitT = 9f, hpShown = 1f, hpGhost = 1f;
    private static boolean killHit;
    private static int lastId = -1, hpKey = -1, fpsKey = -1, pingKey = -1;
    private static long coordKey = Long.MIN_VALUE, infoAt;
    private static String coordStr = "", hpStr = "", info = "";

    public static void hitMarker(boolean kill) { hitT = 0f; killHit = kill; }

    public static void render(DrawContext g, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float dt = CLOCK.tick();
        for (Module m : Module.ALL) {
            if (m.noToggle) continue;
            m.hudA = Fx.damp(m.hudA, m.on ? 1f : 0f, 11f, dt);
        }
        if (mc.player == null) return;
        PulseHub.update(dt, mc);
        if (mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int sw = g.getScaledWindowWidth(), sh = g.getScaledWindowHeight();

        if (Module.PULSE_HUB.on) {
            if (Module.PULSE_HUB.flag("vignette") && Fx.danger > 0.04f) vignette(g, sw, sh);
            PulseHub.drawHud(g, tr, sw, sh);
        }
        if (Module.HIT_MARKER.on) marker(g, sw, sh, dt);
        if (Module.TARGET_HUD.on) targetHud(g, tr, mc, sw, sh, dt);
        if (Module.HUD.on) mainHud(g, tr, mc, sw);
    }

    private static void vignette(DrawContext g, int sw, int sh) {
        float base = Fx.danger * (0.16f + 0.34f * Fx.beat);
        int col = 0xFF2840;
        for (int i = 0; i < 14; i++) {
            float f = 1f - i / 14f;
            int c = Fx.argb(col, base * f * f);
            g.fill(0, i, sw, i + 1, c);
            g.fill(0, sh - 1 - i, sw, sh - i, c);
            g.fill(i, 0, i + 1, sh, c);
            g.fill(sw - 1 - i, 0, sw - i, sh, c);
        }
    }

    private static void marker(DrawContext g, int sw, int sh, float dt) {
        if (hitT > 1f) return;
        hitT += dt;
        float k = hitT / 0.30f;
        if (k >= 1f) return;
        float a = 1f - k;
        float size = Module.HIT_MARKER.num("size") * (killHit ? 1.35f : 1f);
        float dist = 4f + 7f * Fx.outCubic(k) * size;
        int col = killHit ? 0xFF4058 : Fx.gradT(0.1f);
        int c = Fx.argb(col, a);
        int cx = sw / 2, cy = sh / 2;
        if (Module.HIT_MARKER.mode("style") == 0) {
            int len = killHit ? 5 : 4;
            for (int i = 0; i < len; i++) {
                int d = (int) (dist + i);
                g.fill(cx + d, cy + d, cx + d + 1, cy + d + 1, c);
                g.fill(cx - d - 1, cy + d, cx - d, cy + d + 1, c);
                g.fill(cx + d, cy - d - 1, cx + d + 1, cy - d, c);
                g.fill(cx - d - 1, cy - d - 1, cx - d, cy - d, c);
            }
        } else {
            float r = dist + 2f;
            for (int i = 0; i < 28; i++) {
                float ang = i * 0.2243995f;
                Ui.pix(g, cx + Math.round(net.minecraft.util.math.MathHelper.cos(ang) * r),
                        cy + Math.round(net.minecraft.util.math.MathHelper.sin(ang) * r), c);
            }
        }
    }

    private static void targetHud(DrawContext g, TextRenderer tr, MinecraftClient mc, int sw, int sh, float dt) {
        LivingEntity t = Effects.hudTarget();
        if (t == null) { lastId = -1; return; }
        float a = Fx.smooth(Effects.targetFade());
        float hp = Fx.clamp01(t.getHealth() / Math.max(1f, t.getMaxHealth()));
        if (t.getId() != lastId) { lastId = t.getId(); hpShown = hp; hpGhost = hp; }
        hpShown = Fx.damp(hpShown, hp, 12f, dt);
        hpGhost = hpGhost > hpShown ? Fx.damp(hpGhost, hpShown, 2.2f, dt) : hpShown;

        int w = 110, h = Module.TARGET_HUD.flag("dist") ? 38 : 30;
        float x = sw / 2f + 26f, y = sh / 2f - 15f + (1f - a) * 4f;
        Ui.rr(g, x, y, w, h, 7, Ui.a(PILL, a));
        Ui.rr(g, x + 1, y + 6, 2, h - 12, 1, Fx.argb(Fx.gradT(0.1f), a));
        Ui.textF(g, tr, tr.trimToWidth(t.getName().getString(), w - 50), x + 8, y + 5, Fx.argb(0xECECF4, a));
        int hpI = Math.round(t.getHealth());
        if (hpI != hpKey) { hpKey = hpI; hpStr = hpI + " HP"; }
        Ui.textR(g, tr, hpStr, (int) x + w - 7, (int) y + 5, Fx.argb(0xB4B4CC, a));
        float bx = x + 8, by = y + 18, bw = w - 16;
        Ui.rr(g, bx, by, (int) bw, 5, 2, Fx.argb(0xFFFFFF, 0.10f * a));
        Ui.bar(g, bx, by, bw * hpGhost, 5, Fx.argb(0xFFFFFF, 0.35f * a));
        Ui.bar(g, bx, by, bw * hpShown, 5, Fx.argb(Fx.lerp(0xFF4058, Fx.gradT(0.2f), hpShown), a));
        if (Module.TARGET_HUD.flag("dist") && mc.player != null) {
            String d = ((int) mc.player.distanceTo(t)) + "m";
            Ui.text(g, tr, d, (int) bx, (int) y + 25, Fx.argb(0x8A8AA4, a));
        }
    }

    private static void mainHud(DrawContext g, TextRenderer tr, MinecraftClient mc, int sw) {
        long now = System.currentTimeMillis();
        if (now - infoAt > 250L) {
            infoAt = now;
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            int fps = mc.getCurrentFps();
            if (fps != fpsKey || ping != pingKey) {
                fpsKey = fps; pingKey = ping;
                info = "  " + fps + " fps  " + ping + " ms";
            }
        }
        float gl = Fx.pulse();
        int w = tr.getWidth("PulseFX") + tr.getWidth(info) + 14;
        Ui.rr(g, 6, 6, w, 15, 7, PILL);
        int x = Ui.gradText(g, tr, "PulseFX", 13, 10, Math.min(1f, gl), 0.07f);
        Ui.text(g, tr, info, x, 10, 0xFF9A9AB2);

        int y = 24;
        if (Module.HUD.flag("coords")) {
            double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
            long key = ((long) Math.round(px * 10) * 31L + Math.round(py * 10)) * 31L + Math.round(pz * 10);
            if (key != coordKey) {
                coordKey = key;
                coordStr = String.format(Locale.ROOT, "%.1f  %.1f  %.1f", px, py, pz);
            }
            int cw = tr.getWidth(coordStr) + 14;
            Ui.rr(g, 6, y, cw, 15, 7, PILL);
            Ui.text(g, tr, coordStr, 13, y + 4, 0xFFD6D6E6);
        }

        if (Module.HUD.flag("list")) {
            float ry = 6f;
            for (Module m : Module.ALL) {
                if (m.noToggle || m == Module.HUD || m.hudA < 0.01f) continue;
                if (m.lw < 0) m.lw = tr.getWidth(m.label);
                float a = Fx.smooth(m.hudA);
                int mw = m.lw + 14;
                float mx = sw - 6 - mw + (1f - a) * (mw + 10);
                Ui.rr(g, mx, ry, mw, 14, 6, Ui.a(PILL, a));
                Ui.rr(g, mx + 1, ry + 4, 2, 6, 1, Fx.argb(Fx.gradT(ry * 0.01f), a));
                Ui.textF(g, tr, m.label, mx + 7, ry + 3, Fx.argb(0xE6E6F4, a));
                ry += 17f * a;
            }
        }
    }
}
