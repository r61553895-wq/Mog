package dev.pulsefx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * Pulse Hub: the mod's signature feature. A live ECG-style monitor whose rhythm follows your fight:
 * hits you land spike the wave up, damage you take spikes it down, heart rate rises with adrenaline
 * and low health, and (optionally) the whole UI and every effect breathes with that heartbeat.
 */
public final class PulseHub {
    private PulseHub() {}

    public static final int PW = 128;
    private static final int N = 112;
    private static final int PILL = 0xB4101018;
    private static final float[] WAVE = new float[N];
    private static final long[] CLK = new long[40];

    private static int head, clkI;
    private static float acc, osc, hitE, hurtE, phase, adr, lastHp = -1f, cpsShown, pop;
    private static boolean wasDown;
    private static long lastHit;

    public static float beat, danger, bpm = 68f;
    public static int combo;

    private static int comboKey = -1, cpsKey = -1, bpmKey = -1;
    private static String comboStr = "", cpsStr = "", bpmStr = "";

    // ------------------------------------------------------------ events

    public static void onHit() {
        combo++;
        lastHit = System.currentTimeMillis();
        pop = 1f;
        hitE = Math.min(1.5f, hitE + 0.9f);
        adr = Math.min(1f, adr + 0.10f);
    }

    public static void onKill() {
        adr = Math.min(1f, adr + 0.25f);
        hitE = 1.5f;
        pop = 1.5f;
    }

    // ------------------------------------------------------------ model

    private static float gs(float x, float c, float w) {
        float d = (x - c) / w;
        return (float) Math.exp(-d * d);
    }

    private static float ecg(float f) {
        return 0.12f * gs(f, 0.92f, 0.035f) - 0.14f * gs(f, 0.045f, 0.012f) + gs(f, 0.065f, 0.014f)
                - 0.30f * gs(f, 0.085f, 0.012f) + 0.25f * gs(f, 0.30f, 0.05f);
    }

    private static float envelope(float f) {
        return Math.max(gs(f, 0.065f, 0.05f), 0.55f * gs(f, 0.32f, 0.06f));
    }

    private static float sample(float ph) {
        float v = 0.62f * ecg(ph) + hitE * 0.85f * MathHelper.sin(osc) - hurtE * 0.85f * MathHelper.sin(osc * 0.7f);
        return MathHelper.clamp(v, -1f, 1f);
    }

    /** Called once per frame from the HUD callback. */
    public static void update(float dt, MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) { lastHp = -1f; combo = 0; return; }
        long now = System.currentTimeMillis();

        float hp = p.getHealth();
        float ratio = Fx.clamp01(hp / Math.max(1f, p.getMaxHealth()));
        danger = Fx.damp(danger, Fx.clamp01((0.55f - ratio) / 0.45f), 3f, dt);
        if (lastHp >= 0f && hp < lastHp - 0.01f) {
            float d = lastHp - hp;
            hurtE = Math.min(1.5f, hurtE + 0.55f + d * 0.1f);
            adr = Math.min(1f, adr + 0.3f + d * 0.03f);
        }
        lastHp = hp;
        adr = Math.max(0f, adr - dt * 0.12f);
        bpm = Fx.damp(bpm, 62f + 72f * adr + 58f * danger, 2.5f, dt);
        float rate = bpm / 60f;
        phase += dt * rate;
        phase -= (float) Math.floor(phase);
        beat = envelope(phase);

        if (mc.currentScreen == null) {
            boolean d = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            if (d && !wasDown) { CLK[clkI] = now; clkI = (clkI + 1) % CLK.length; }
            wasDown = d;
        }
        int c = 0;
        for (long t : CLK) if (now - t <= 1000L) c++;
        cpsShown = Fx.damp(cpsShown, c, 10f, dt);
        if (combo > 0 && now - lastHit > 3000L) combo = 0;
        pop = Math.max(0f, pop - dt * 3.5f);

        boolean hub = Module.PULSE_HUB.on;
        if (hub) {
            float sr = 72f * Module.PULSE_HUB.num("speed");
            acc += dt * sr;
            int total = (int) acc;
            acc -= total;
            int n = Math.min(total, 8);
            float step = rate / sr;
            for (int k = 0; k < n; k++) {
                float ph = phase - (n - 1 - k) * step;
                ph -= (float) Math.floor(ph);
                osc += 38f / sr;
                WAVE[head] = sample(ph);
                head = (head + 1) % N;
            }
            float decay = (float) Math.exp(-3.4f * dt);
            hitE *= decay;
            hurtE *= decay;
        }
        boolean sync = hub && Module.PULSE_HUB.flag("sync");
        Fx.beat = sync ? beat : 0f;
        Fx.danger = sync ? danger : 0f;
        Fx.applyTint();

        int b = Math.round(bpm);
        if (b != bpmKey) { bpmKey = b; bpmStr = b + " BPM"; }
    }

    public static String bpmText() { return bpmStr; }

    // ------------------------------------------------------------ drawing

    public static void drawEcg(DrawContext g, int x, int y, int w, int h, float a) {
        Ui.rr(g, x, y, w, h, 4, Ui.a(0x40000000, a));
        int mid = y + h / 2;
        float amp = h / 2f - 2f;
        g.fill(x + 2, mid, x + w - 2, mid + 1, Fx.argb(0xFFFFFF, 0.06f * a));
        float cw = (w - 4) / (float) (N - 1);
        int prevY = mid, prevX = x + 2;
        for (int i = 0; i < N; i++) {
            float v = WAVE[(head + i) % N];
            int yy = mid - Math.round(v * amp);
            int cx = x + 2 + Math.round(i * cw);
            if (i > 0) {
                int x1 = Math.max(cx, prevX + 1);
                float t = i / (float) (N - 1);
                float al = t * t * a;
                int lo = Math.min(prevY, yy), hi = Math.max(prevY, yy) + 1;
                int col = Fx.gradT(t * 0.5f);
                g.fill(prevX, lo - 1, x1, hi + 1, Fx.argb(col, al * 0.16f));
                g.fill(prevX, lo, x1, hi, Fx.argb(col, al * 0.95f));
            }
            prevY = yy;
            prevX = cx;
        }
        float gp = 2.5f + 2f * beat;
        Ui.rr(g, prevX - gp, prevY - gp + 0.5f, Math.round(gp * 2), Math.round(gp * 2), (int) gp, Fx.argb(Fx.gradT(0.3f), 0.25f * a));
        Ui.rr(g, prevX - 1, prevY - 1, 3, 3, 1, Fx.argb(0xFFFFFF, a));
    }

    public static int panelH() {
        return 20 + (Module.PULSE_HUB.flag("ecg") ? 28 : 0) + (Module.PULSE_HUB.flag("stats") ? 15 : 0);
    }

    public static void draw(DrawContext g, TextRenderer tr, int x, int y, float a) {
        boolean ecg = Module.PULSE_HUB.flag("ecg"), stats = Module.PULSE_HUB.flag("stats");
        int h = panelH();
        float gl = 1f + 0.5f * Fx.beat;
        Ui.rr(g, x - 1, y - 1, PW + 2, h + 2, 9, Fx.argb(Fx.gradT(0f), 0.10f * gl * a));
        Ui.rr(g, x, y, PW, h, 8, Ui.a(PILL, a));
        Ui.gradText(g, tr, "PULSE", x + 8, y + 6, a, 0.12f);
        float hs = 2f + 1.6f * Fx.beat;
        int heart = Fx.lerp(Fx.e1, 0xFF4058, 0.55f);
        int bw = tr.getWidth(bpmStr);
        Ui.text(g, tr, bpmStr, x + PW - 8 - bw, y + 6, Fx.argb(0xB4B4CC, a));
        Ui.rr(g, x + PW - 8 - bw - 8 - hs, y + 9.5f - hs, Math.round(hs * 2), Math.round(hs * 2), (int) hs, Fx.argb(heart, a));
        int yy = y + 18;
        if (ecg) { drawEcg(g, x + 6, yy, PW - 12, 24, a); yy += 28; }
        if (stats) {
            long now = System.currentTimeMillis();
            if (combo > 0) {
                if (combo != comboKey) { comboKey = combo; comboStr = "x" + combo; }
                MatrixStack m = g.getMatrices();
                float sc = 1f + 0.45f * pop;
                m.push();
                m.translate(x + 8, yy + 4, 0f);
                m.scale(sc, sc, 1f);
                Ui.gradText(g, tr, comboStr, 0, 0, a, 0.15f);
                m.pop();
                float rem = Fx.clamp01(1f - (now - lastHit) / 3000f);
                Ui.bar(g, x + 8, y + h - 3, (PW - 16) * rem, 1, Fx.argb(Fx.gradT(0.2f), 0.8f * a));
            } else {
                Ui.text(g, tr, "no combo", x + 8, yy + 4, Fx.argb(0x6A6A84, a));
            }
            int cps = Math.round(cpsShown);
            if (cps != cpsKey) { cpsKey = cps; cpsStr = cps + " CPS"; }
            Ui.textR(g, tr, cpsStr, x + PW - 8, yy + 4, Fx.argb(0xB4B4CC, a));
        }
    }

    public static void drawHud(DrawContext g, TextRenderer tr, int sw, int sh) {
        int h = panelH();
        int x = Module.PULSE_HUB.mode("side") == 0 ? sw - 6 - PW : 6;
        draw(g, tr, x, sh - h - 8, 1f);
    }
}
