package dev.pulsefx;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** World-space effects. Depth-tested (hidden behind blocks/entities) and batched into one draw call per frame. */
public final class Effects {
    private Effects() {}

    record Circle(double x, double y, double z, long start, float scale, boolean self) {}

    private static final int SEG = 40, MAX_CIRCLES = 14;
    private static final long TARGET_LIFE = 6000L;
    private static final float TAU = 6.2831855f;
    private static final float[] COS = new float[SEG + 1], SIN = new float[SEG + 1];

    static {
        for (int i = 0; i <= SEG; i++) {
            COS[i] = (float) Math.cos(TAU * i / SEG);
            SIN[i] = (float) Math.sin(TAU * i / SEG);
        }
    }

    private static final List<Circle> CIRCLES = new ArrayList<>();
    private static final ArrayDeque<Vec3d> TRAIL = new ArrayDeque<>();
    private static final Vec3d[] BUF = new Vec3d[128];
    private static final Fx.Clock CLOCK = new Fx.Clock();

    private static boolean wasGround = true, trailLive;
    private static LivingEntity target, lastHit;
    private static long targetTime, lastHitMs, lastLand;
    private static float targetFade;
    private static int verts;

    public static void addCircle(double x, double y, double z, float scale, boolean self) {
        if (CIRCLES.size() >= MAX_CIRCLES) CIRCLES.remove(0);
        CIRCLES.add(new Circle(x, y, z, System.currentTimeMillis(), scale, self));
    }

    public static LivingEntity hudTarget() { return targetFade > 0.01f ? target : null; }
    public static float targetFade() { return targetFade; }

    /** Called when the local player attacks a living entity. */
    public static void onAttack(LivingEntity le) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.currentTimeMillis();
        if (Module.TARGET_ESP.on || Module.TARGET_HUD.on) { target = le; targetTime = now; }
        lastHit = le;
        lastHitMs = now;
        PulseHub.onHit();
        if (Module.HIT_MARKER.on) Hud.hitMarker(false);
        if (Module.HIT_FX.on && mc.world != null) {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            int n = (int) Module.HIT_FX.num("count");
            double cy = le.getY() + le.getHeight() * 0.55;
            for (int i = 0; i < n; i++) {
                mc.world.addParticle(i % 3 == 0 ? ParticleTypes.CRIT : ParticleTypes.END_ROD,
                        le.getX(), cy, le.getZ(),
                        r.nextDouble(-0.25, 0.25), r.nextDouble(-0.05, 0.3), r.nextDouble(-0.25, 0.25));
            }
            if (Module.HIT_FX.flag("ring")) addCircle(le.getX(), le.getY(), le.getZ(), 0.9f, false);
        }
    }

    private static void onKill(MinecraftClient mc, LivingEntity le) {
        PulseHub.onKill();
        if (Module.HIT_MARKER.on) Hud.hitMarker(true);
        if (Module.HIT_FX.on && Module.HIT_FX.flag("kill") && mc.world != null) {
            addCircle(le.getX(), le.getY(), le.getZ(), 1.8f, false);
            ThreadLocalRandom r = ThreadLocalRandom.current();
            double cy = le.getY() + le.getHeight() * 0.5;
            for (int i = 0; i < 26; i++) {
                mc.world.addParticle(i % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.FIREWORK,
                        le.getX(), cy, le.getZ(),
                        r.nextDouble(-0.3, 0.3), r.nextDouble(-0.05, 0.35), r.nextDouble(-0.3, 0.3));
            }
        }
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            CIRCLES.clear(); TRAIL.clear(); target = null; lastHit = null;
            return;
        }
        long now = System.currentTimeMillis();
        boolean ground = p.isOnGround();
        if (Module.JUMP_CIRCLES.on) {
            if (wasGround && !ground && p.getVelocity().y > 0.0) {
                addCircle(p.getX(), p.getY(), p.getZ(), 1f, true);
            } else if (!wasGround && ground && Module.JUMP_CIRCLES.flag("land") && now - lastLand > 250L) {
                lastLand = now;
                addCircle(p.getX(), p.getY(), p.getZ(), 0.8f, true);
            }
        }
        wasGround = ground;

        if (lastHit != null) {
            if (lastHit.getHealth() <= 0f || !lastHit.isAlive()) {
                if (now - lastHitMs < 4000L && lastHit.getHealth() <= 0f) onKill(mc, lastHit);
                lastHit = null;
            } else if (now - lastHitMs > 4000L) {
                lastHit = null;
            }
        }

        if (Module.TRAIL.on) {
            Vec3d pos = p.getPos();
            Vec3d last = TRAIL.peekLast();
            int len = (int) Module.TRAIL.num("length");
            trailLive = false;
            if (last != null && last.squaredDistanceTo(pos) > 64.0) TRAIL.clear();
            if (last == null || last.squaredDistanceTo(pos) > 0.0009) {
                TRAIL.addLast(pos);
                trailLive = true;
            } else if (TRAIL.size() > 1) {
                TRAIL.pollFirst(); // fades away when standing still
            }
            while (TRAIL.size() > Math.min(len, BUF.length - 2)) TRAIL.pollFirst();
        } else {
            TRAIL.clear();
        }
    }

    // ---------------------------------------------------------------- render

    private static void vtx(BufferBuilder b, Matrix4f m, double x, double y, double z, int c) {
        b.vertex(m, (float) x, (float) y, (float) z).color(c);
        verts++;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        MatrixStack ms = ctx.matrixStack();
        if (p == null || ms == null) return;

        float dt = CLOCK.tick();
        long now = System.currentTimeMillis();

        boolean valid = target != null && (Module.TARGET_ESP.on || Module.TARGET_HUD.on) && target.isAlive()
                && !target.isRemoved() && now - targetTime < TARGET_LIFE;
        targetFade = Fx.damp(targetFade, valid ? 1f : 0f, valid ? 9f : 5f, dt);
        if (!valid && targetFade < 0.01f) target = null;

        final long life = (long) Module.JUMP_CIRCLES.num("life");
        if (!CIRCLES.isEmpty()) CIRCLES.removeIf(c -> now - c.start() >= life);

        boolean fp = mc.options.getPerspective().isFirstPerson();
        boolean showSelf = !fp || Module.JUMP_CIRCLES.flag("fp");
        boolean doCircles = !CIRCLES.isEmpty();
        boolean doTrail = Module.TRAIL.on && TRAIL.size() > 1 && (!fp || Module.TRAIL.flag("fp"));
        boolean doTarget = Module.TARGET_ESP.on && target != null && targetFade > 0.01f;
        if (!doCircles && !doTrail && !doTarget) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f m = ms.peek().getPositionMatrix();
        float td = ctx.tickCounter().getTickDelta(true);
        float glow = Fx.pulse();

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        verts = 0;

        float size = Module.JUMP_CIRCLES.num("size");
        float lifeF = Math.max(1f, Module.JUMP_CIRCLES.num("life"));
        for (Circle c : CIRCLES) {
            if (c.self() && !showSelf) continue;
            double dx = c.x() - cam.x, dz = c.z() - cam.z;
            if (dx * dx + dz * dz > 9216.0) continue;
            float a = Fx.clamp01((now - c.start()) / lifeF);
            float sz = size * c.scale();
            float r = sz * (0.25f + 0.95f * Fx.outCubic(a));
            float alpha = (float) Math.pow(1f - a, 1.6) * 0.9f * glow;
            softRing(b, m, cam, c.x(), c.y() + 0.03, c.z(), r, 0.20f * sz * (1f - 0.4f * a), 0.04f + 0.05f * sz,
                    alpha, a * 0.4f, a * 2f);
        }

        if (doTrail) trail(b, m, cam, p, td, glow);
        if (doTarget) target(b, m, cam, td, now, glow);

        BuiltBuffer built = b.endNullable();
        if (built != null) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.enableDepthTest();
            RenderSystem.disableCull();
            RenderSystem.depthMask(false);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferRenderer.drawWithGlobalProgram(built);
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
        }
    }

    /** Ring with soft glow on both edges: transparent -> peak -> transparent. */
    private static void softRing(BufferBuilder b, Matrix4f m, Vec3d cam, double cx, double cy, double cz,
                                 float r, float wIn, float wOut, float alpha, float phase, float rot) {
        if (alpha < 0.01f) return;
        float rin = Math.max(0.001f, r - wIn), rout = r + wOut;
        double ox = cx - cam.x, oy = cy - cam.y, oz = cz - cam.z;
        float cr = MathHelper.cos(rot), sr = MathHelper.sin(rot);
        float c0 = COS[0] * cr - SIN[0] * sr, s0 = SIN[0] * cr + COS[0] * sr;
        int k0 = Fx.argb(Fx.gradT(phase), alpha);
        for (int i = 0; i < SEG; i++) {
            float c1 = COS[i + 1] * cr - SIN[i + 1] * sr, s1 = SIN[i + 1] * cr + COS[i + 1] * sr;
            int k1 = Fx.argb(Fx.gradT(phase + (i + 1f) / SEG), alpha);
            int z0 = k0 & 0xFFFFFF, z1 = k1 & 0xFFFFFF;
            vtx(b, m, ox + c0 * rin, oy, oz + s0 * rin, z0);
            vtx(b, m, ox + c1 * rin, oy, oz + s1 * rin, z1);
            vtx(b, m, ox + c1 * r, oy, oz + s1 * r, k1);
            vtx(b, m, ox + c0 * r, oy, oz + s0 * r, k0);
            vtx(b, m, ox + c0 * r, oy, oz + s0 * r, k0);
            vtx(b, m, ox + c1 * r, oy, oz + s1 * r, k1);
            vtx(b, m, ox + c1 * rout, oy, oz + s1 * rout, z1);
            vtx(b, m, ox + c0 * rout, oy, oz + s0 * rout, z0);
            c0 = c1; s0 = s1; k0 = k1;
        }
    }

    private static void trail(BufferBuilder b, Matrix4f m, Vec3d cam, ClientPlayerEntity p, float td, float glow) {
        int n = 0;
        for (Vec3d v : TRAIL) BUF[n++] = v;
        if (trailLive && n > 0) BUF[n - 1] = p.getLerpedPos(td); // smooth head between ticks
        if (n < 2) return;
        float h = Module.TRAIL.num("height");
        for (int j = 0; j < n - 1; j++) {
            float t0 = j / (float) (n - 1), t1 = (j + 1f) / (n - 1);
            float a0 = (float) Math.pow(t0, 1.4) * 0.75f * glow, a1 = (float) Math.pow(t1, 1.4) * 0.75f * glow;
            int b0 = Fx.argb(Fx.gradT(t0 * 0.6f), a0), b1 = Fx.argb(Fx.gradT(t1 * 0.6f), a1);
            float h0 = h * (0.3f + 0.7f * t0), h1 = h * (0.3f + 0.7f * t1);
            Vec3d p0 = BUF[j], p1 = BUF[j + 1];
            double x0 = p0.x - cam.x, y0 = p0.y + 0.04 - cam.y, z0 = p0.z - cam.z;
            double x1 = p1.x - cam.x, y1 = p1.y + 0.04 - cam.y, z1 = p1.z - cam.z;
            vtx(b, m, x0, y0, z0, b0);
            vtx(b, m, x1, y1, z1, b1);
            vtx(b, m, x1, y1 + h1, z1, b1 & 0xFFFFFF);
            vtx(b, m, x0, y0 + h0, z0, b0 & 0xFFFFFF);
        }
    }

    private static void target(BufferBuilder b, Matrix4f m, Vec3d cam, float td, long now, float glow) {
        Vec3d pos = target.getLerpedPos(td);
        float w = target.getWidth() * 0.75f + 0.2f;
        float h = target.getHeight();
        float speed = Module.TARGET_ESP.num("speed");
        int style = Module.TARGET_ESP.mode("style");
        float tt = (float) (now * 0.0026 * speed);
        float f = Fx.smooth(targetFade);

        if (style == 0 || style == 2) {
            for (int k = 0; k < 2; k++) {
                float yy = (float) pos.y + h * (0.5f + 0.5f * MathHelper.sin(tt + k * 3.1415927f));
                softRing(b, m, cam, pos.x, yy, pos.z, w, 0.10f, 0.03f, 0.85f * f * glow, tt * 0.12f + k * 0.5f,
                        tt * (k == 0 ? 0.8f : -0.8f));
            }
        }
        if (style == 1 || style == 2) {
            softRing(b, m, cam, pos.x, pos.y + 0.03, pos.z, w * 1.15f + 0.04f * MathHelper.sin(tt * 1.4f),
                    0.32f, 0.06f, 0.6f * f * glow, tt * 0.1f, tt * 0.5f);
        }
    }
}
