package dev.pulsefx;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

public final class ViewModel {
    private ViewModel() {}

    public static void apply(MatrixStack m, Arm arm) {
        float side = arm == Arm.RIGHT ? 1f : -1f;
        Module v = Module.VIEWMODEL;
        m.translate(v.num("x") * side, v.num("y"), v.num("z"));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(v.num("rx")));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(v.num("ry") * side));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(v.num("rz") * side));
        float s = v.num("scale");
        m.scale(s, s, s);
    }
}
