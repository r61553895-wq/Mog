package dev.pulsefx;

import net.minecraft.util.math.MathHelper;

/** Colors, easing and frame-rate independent smoothing helpers. */
public final class Fx {
    private Fx() {}

    public static final long T0 = System.currentTimeMillis();

    /** Heartbeat values shared by the whole mod (0 when Heartbeat sync is off). */
    public static float beat, danger;
    /** Effective accent colors (user accent tinted toward red when health is low). */
    public static int e1 = 0x9B5CFF, e2 = 0x35E6FF;

    public static double ms() { return System.currentTimeMillis() - T0; }

    public static void applyTint() {
        e1 = lerp(Config.c1, 0xFF4058, danger * 0.8f);
        e2 = lerp(Config.c2, 0xFF8A40, danger * 0.8f);
    }

    /** Glow multiplier that breathes with the heartbeat. */
    public static float pulse() { return 1f + 0.35f * beat; }

    /** Per-consumer frame clock, returns seconds since last tick (clamped). */
    public static final class Clock {
        private long last = System.nanoTime();
        public float tick() {
            long n = System.nanoTime();
            float d = (n - last) * 1e-9f;
            last = n;
            return d < 0f ? 0f : Math.min(d, 0.05f);
        }
    }

    /** Damped spring: soft overshoot for panels, indicators, knobs. */
    public static final class Spring {
        public float p, v, target;
        public Spring(float p) { this.p = p; this.target = p; }
        public void step(float dt, float freq, float damping) {
            int n = Math.max(1, (int) Math.ceil(dt / 0.006f));
            float h = dt / n;
            for (int i = 0; i < n; i++) {
                v += (-freq * freq * (p - target) - 2f * damping * freq * v) * h;
                p += v * h;
            }
        }
        public void snap(float x) { p = x; target = x; v = 0f; }
    }

    /** Exponential smoothing, independent of FPS. */
    public static float damp(float cur, float tgt, float rate, float dt) {
        return cur + (tgt - cur) * (1f - (float) Math.exp(-rate * dt));
    }

    public static float clamp01(float a) { return a < 0f ? 0f : Math.min(a, 1f); }
    public static float outCubic(float a) { float u = 1f - clamp01(a); return 1f - u * u * u; }
    public static float smooth(float a) { a = clamp01(a); return a * a * (3f - 2f * a); }

    public static int rgb(float hue) {
        return MathHelper.hsvToRgb(hue - (float) Math.floor(hue), 0.62f, 1f);
    }

    public static int lerp(int a, int b, float t) {
        t = clamp01(t);
        int r = ((a >> 16) & 255) + (int) ((((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = ((a >> 8) & 255) + (int) ((((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (a & 255) + (int) (((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int argb(int rgb, float alpha) {
        int a = (int) (clamp01(alpha) * 255f);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    /** Accent gradient; t is a cyclic phase (period 1). Returns 0xRRGGBB. */
    public static int grad(float t) {
        if (Config.rainbow) return rgb(t);
        float k = 0.5f + 0.5f * MathHelper.sin(t * 6.2831855f);
        return lerp(e1, e2, k);
    }

    /** Time-animated gradient. */
    public static int gradT(float offset) {
        return grad(offset + (float) (ms() * 0.00018));
    }
}
