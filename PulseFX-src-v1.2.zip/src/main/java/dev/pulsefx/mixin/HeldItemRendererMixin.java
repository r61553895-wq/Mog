package dev.pulsefx.mixin;

import dev.pulsefx.Module;
import dev.pulsefx.SwingAnim;
import dev.pulsefx.ViewModel;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {

    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
    private float pulsefx$hideVanillaSwing(float swingProgress) {
        SwingAnim.realProgress = swingProgress;
        return SwingAnim.custom() ? 0f : swingProgress;
    }

    @Inject(method = "applyEquipOffset", at = @At("TAIL"))
    private void pulsefx$viewModel(MatrixStack matrices, Arm arm, float equipProgress, CallbackInfo ci) {
        if (Module.VIEWMODEL.on) ViewModel.apply(matrices, arm);
    }

    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true)
    private void pulsefx$swing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        if (SwingAnim.custom()) {
            SwingAnim.apply(matrices, arm, SwingAnim.realProgress);
            ci.cancel();
        }
    }
}
