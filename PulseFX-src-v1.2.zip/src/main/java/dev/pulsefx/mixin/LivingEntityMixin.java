package dev.pulsefx.mixin;

import dev.pulsefx.Module;
import dev.pulsefx.SwingAnim;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {

    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void pulsefx$swingDuration(CallbackInfoReturnable<Integer> cir) {
        if (SwingAnim.custom() && (Object) this == MinecraftClient.getInstance().player) {
            cir.setReturnValue((int) Module.SWING.num("duration"));
        }
    }
}
