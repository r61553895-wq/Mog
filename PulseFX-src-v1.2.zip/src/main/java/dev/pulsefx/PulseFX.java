package dev.pulsefx;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class PulseFX implements ClientModInitializer {
    public static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pulsefx.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.pulsefx"));

        ClientTickEvents.END_CLIENT_TICK.register(PulseFX::onEndTick);
        WorldRenderEvents.LAST.register(Effects::render);
        HudRenderCallback.EVENT.register((g, tc) -> {
            Hud.render(g, tc);
            Nearby.render(g, tc);
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient && player == mc.player && entity instanceof LivingEntity le) Effects.onAttack(le);
            return ActionResult.PASS;
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("pulsefx");
            for (Module m : Module.ALL) {
                if (m.noToggle) continue;
                root.then(ClientCommandManager.literal(m.id).executes(ctx -> {
                    m.on = !m.on;
                    Config.save();
                    ctx.getSource().sendFeedback(Text.literal("§d[PulseFX] §f" + m.label + ": " + (m.on ? "§aON" : "§cOFF")));
                    return 1;
                }));
            }
            root.executes(ctx -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                mc.execute(() -> mc.setScreen(new MenuScreen()));
                return 1;
            });
            dispatcher.register(root);
        });
    }

    private static void onEndTick(MinecraftClient mc) {
        Effects.tick(mc);
        if (mc.currentScreen == null) {
            while (menuKey.wasPressed()) mc.setScreen(new MenuScreen());
            if (mc.player != null) {
                long win = mc.getWindow().getHandle();
                for (Module m : Module.ALL) {
                    if (m.bind == 0 || m.noToggle) continue;
                    boolean down = InputUtil.isKeyPressed(win, m.bind);
                    if (down && !m.wasDown) {
                        m.on = !m.on;
                        Config.save();
                        mc.player.sendMessage(Text.literal("§d[PulseFX] §f" + m.label + ": " + (m.on ? "§aON" : "§cOFF")), true);
                    }
                    m.wasDown = down;
                }
            }
        }
    }
}
