package dev.pulsefx;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Dark glass panel on a small virtual resolution that is scaled up (pixel-aligned) so everything looks big.
 * Vertical sidebar, spring open/close, sliding tab pill, inertial scroll, ambient pulse particles.
 */
public class MenuScreen extends Screen {
    private static final String[] TABS = {"Hub", "Visuals", "HUD", "Motion", "View", "Theme"};
    private static final int W = 330, H = 204, SIDE = 84, HEAD = 22, ROW = 18, TRACK = 76, TAB_H = 20;
    private static final int K_TAB = 0, K_MOD = 1, K_BOOL = 2, K_MODE = 3, K_SLIDER = 4;
    private static final int NP = 36;

    private record Hit(int x, int y, int w, int h, int kind, int idx, Module m, Setting s) {}

    private final Fx.Clock clock = new Fx.Clock();
    private final Fx.Spring open = new Fx.Spring(0f);
    private final Fx.Spring indY = new Fx.Spring(0f);
    private final float[] tabSel = new float[TABS.length], tabHov = new float[TABS.length];
    private final List<List<Module>> mods = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private final float[] ppx = new float[NP], ppy = new float[NP], ppv = new float[NP];
    private final int[] pps = new int[NP];
    private final Random rng = new Random();

    private int tab;
    private boolean closing, firstFrame = true;
    private float scroll, scrollT, tabFade = 1f, am = 1f, maxScroll;
    private Module binding;
    private Setting dragging;
    private int dragX;
    private float lcx, lcy, lscale = 1f, loff;
    private int crx, cry, crw, crh, px, py;

    public MenuScreen() {
        super(Text.literal("PulseFX"));
        for (String t : TABS) {
            List<Module> l = new ArrayList<>();
            for (Module m : Module.ALL) if (m.category.equals(t)) l.add(m);
            mods.add(l);
        }
        for (int i = 0; i < NP; i++) {
            ppx[i] = rng.nextFloat();
            ppy[i] = rng.nextFloat();
            ppv[i] = 0.02f + rng.nextFloat() * 0.05f;
            pps[i] = rng.nextInt(3) == 0 ? 2 : 1;
        }
    }

    @Override public boolean shouldPause() { return false; }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    @Override public void removed() { Config.save(); }

    private int c(int argb) { return Ui.a(argb, am); }

    private static boolean in(float mx, float my, int x, int y, int w, int h) {
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }

    /** Scale that makes the virtual panel big while keeping text pixel-perfect (whole real pixels). */
    private float baseScale() {
        double gs = client.getWindow().getScaleFactor();
        float fit = Math.min(width * 0.56f / W, height * 0.68f / H) * Module.THEME.num("uiscale");
        fit = MathHelper.clamp(fit, 1f, 4f);
        int real = Math.max(1, Math.round((float) (fit * gs)));
        float k = (float) (real / gs);
        while (real > 1 && (k * W > width - 6 || k * H > height - 6)) { real--; k = (float) (real / gs); }
        return k;
    }

    /** Scissor in raw screen coordinates (transform the local rect by the panel transform). */
    private void scis(DrawContext g, float x0, float y0, float x1, float y1) {
        int ax = (int) Math.floor(lcx + (x0 - lcx) * lscale), ay = (int) Math.floor(lcy + loff + (y0 - lcy) * lscale);
        int bx = (int) Math.ceil(lcx + (x1 - lcx) * lscale), by = (int) Math.ceil(lcy + loff + (y1 - lcy) * lscale);
        MatrixStack ms = g.getMatrices();
        ms.push();
        ms.peek().getPositionMatrix().identity();
        g.enableScissor(ax, ay, bx, by);
        ms.pop();
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        float dt = clock.tick();
        open.target = closing ? 0f : 1f;
        open.step(dt, 17f, closing ? 1f : 0.62f);
        if (closing && open.p < 0.015f) { client.setScreen(null); return; }

        float p = MathHelper.clamp(open.p, 0f, 1.2f);
        float ga = Fx.clamp01(p * 1.25f);
        float k = baseScale();
        float s = k * (0.93f + 0.07f * Math.min(p, 1.1f));
        int cx = width / 2, cy = height / 2;
        px = cx - W / 2;
        py = cy - H / 2;
        float off = (1f - Math.min(p, 1f)) * 10f;
        lcx = cx; lcy = cy; lscale = s; loff = off;
        float mxl = cx + (mx - cx) / s, myl = cy + (my - cy - off) / s;
        am = ga;

        g.fillGradient(0, 0, width, height, Ui.a(0x70040408, ga),
                Ui.a(0xFF000000 | Fx.lerp(0x05050A, Fx.e1, 0.20f), 0.62f * ga));
        drawParticles(g, dt, ga);

        hits.clear();
        MatrixStack ms = g.getMatrices();
        ms.push();
        ms.translate(cx, cy + off, 0f);
        ms.scale(s, s, 1f);
        ms.translate(-cx, -cy, 0f);

        Ui.shadow(g, px, py, W, H, 10, ga);
        Ui.rr(g, px, py, W, H, 10, c(0xB80A0A12));
        g.fillGradient(px + 6, py + 1, px + W - 6, py + 46, c(Fx.argb(Fx.gradT(0f), 0.10f)), 0);
        Ui.rr(g, px + 6, py + 6, SIDE - 4, H - 12, 7, c(0x38000000));
        for (int i = 0; i < 24; i++) {
            int x0 = px + 12 + (W - 24) * i / 24, x1 = px + 12 + (W - 24) * (i + 1) / 24;
            int col = Fx.argb(Fx.gradT(i / 24f), 0.38f * am);
            g.fill(x0, py, x1, py + 1, col);
            g.fill(x0, py + H - 1, x1, py + H, col);
        }
        g.fill(px, py + 12, px + 1, py + H - 12, c(Fx.argb(Fx.gradT(0.1f), 0.22f)));
        g.fill(px + W - 1, py + 12, px + W, py + H - 12, c(Fx.argb(Fx.gradT(0.6f), 0.22f)));

        // logo
        ms.push();
        ms.translate(px + 14, py + 11, 0f);
        ms.scale(1.35f, 1.35f, 1f);
        Ui.gradText(g, textRenderer, "PulseFX", 0, 0, ga, 0.08f);
        ms.pop();
        Ui.text(g, textRenderer, "v1.2  MC 1.21.4", px + 14, py + 27, c(0xFF565670));

        drawTabs(g, dt, mxl, myl);
        drawHeart(g);
        drawContent(g, dt, mxl, myl);
        Ui.text(g, textRenderer, "LMB toggle  -  RMB settings  -  MMB bind", px + SIDE + 12, py + H - 14, c(0xFF565670));

        ms.pop();
        firstFrame = false;
    }

    private void drawParticles(DrawContext g, float dt, float ga) {
        double t = Fx.ms() * 0.001;
        for (int i = 0; i < NP; i++) {
            ppy[i] -= ppv[i] * dt;
            if (ppy[i] < -0.02f) { ppy[i] = 1.02f; ppx[i] = rng.nextFloat(); }
            float tw = 0.5f + 0.5f * MathHelper.sin((float) (t * 1.3 + i));
            int x = (int) (ppx[i] * width), y = (int) (ppy[i] * height);
            g.fill(x, y, x + pps[i], y + pps[i], Fx.argb(Fx.gradT(i * 0.031f), (0.10f + 0.24f * tw) * ga));
        }
    }

    private void drawTabs(DrawContext g, float dt, float mx, float my) {
        int ty0 = py + 46;
        indY.target = ty0 + tab * (TAB_H + 2);
        if (firstFrame) indY.snap(indY.target);
        indY.step(dt, 24f, 0.8f);
        Ui.rr(g, px + 8, indY.p, SIDE - 12, TAB_H, 6, c(Fx.argb(Fx.gradT(0f), 0.20f)));
        Ui.rr(g, px + 8, indY.p + 5, 2, TAB_H - 10, 1, c(Fx.argb(Fx.gradT(0.3f), 0.95f)));
        for (int i = 0; i < TABS.length; i++) {
            int ty = ty0 + i * (TAB_H + 2);
            boolean hov = in(mx, my, px + 8, ty, SIDE - 12, TAB_H);
            tabSel[i] = Fx.damp(tabSel[i], i == tab ? 1f : 0f, 16f, dt);
            tabHov[i] = Fx.damp(tabHov[i], hov ? 1f : 0f, 18f, dt);
            int col = Fx.lerp(0x8B8BA3, 0xFFFFFF, Math.max(tabSel[i], tabHov[i] * 0.7f));
            Ui.textF(g, textRenderer, TABS[i], px + 18 + 2 * tabSel[i], ty + 6, c(0xFF000000 | col));
            hits.add(new Hit(px + 8, ty, SIDE - 12, TAB_H, K_TAB, i, null, null));
        }
    }

    private void drawHeart(DrawContext g) {
        float bs = 3f + 2.5f * PulseHub.beat;
        int cx = px + 18, cy = py + H - 18;
        int heart = Fx.lerp(Fx.e1, 0xFF4058, 0.55f);
        Ui.rr(g, cx - bs - 2, cy - bs - 2, Math.round(bs * 2 + 4), Math.round(bs * 2 + 4), (int) bs + 2, c(Fx.argb(heart, 0.18f)));
        Ui.rr(g, cx - bs, cy - bs, Math.round(bs * 2), Math.round(bs * 2), (int) bs, c(Fx.argb(heart, 0.95f)));
        Ui.text(g, textRenderer, PulseHub.bpmText(), px + 30, py + H - 22, c(0xFF8B8BA3));
    }

    private void drawContent(DrawContext g, float dt, float mx, float my) {
        int rx = px + SIDE + 4, ry = py + 10, rw = W - SIDE - 12, rh = H - 36;
        crx = rx; cry = ry; crw = rw; crh = rh;

        tabFade = Fx.damp(tabFade, 1f, 11f, dt);
        scroll = Fx.damp(scroll, scrollT, 15f, dt);
        float saved = am;
        am = saved * Fx.smooth(tabFade);
        float slide = (1f - Fx.smooth(tabFade)) * 8f;

        scis(g, rx - 2, ry, rx + rw + 3, ry + rh);
        float y = ry - scroll + slide;
        float startY = y;
        if (tab == 0) y += drawPreview(g, rx, y, rw) + 4f;
        for (Module m : mods.get(tab)) y += drawModule(g, dt, m, rx, y, rw, mx, my) + 4f;
        g.disableScissor();

        float contentH = y - startY;
        maxScroll = Math.max(0f, contentH - rh);
        scrollT = MathHelper.clamp(scrollT, 0f, maxScroll);
        if (maxScroll > 0f) {
            float th = Math.max(16f, rh * rh / contentH);
            float ty = ry + (rh - th) * (scroll / maxScroll);
            Ui.rr(g, rx + rw + 3, ty, 2, (int) th, 1, c(0x40FFFFFF));
        }
        am = saved;
    }

    private float drawPreview(DrawContext g, float y, int rx, int rw) {
        Ui.rr(g, rx, y, rw, 46, 7, c(Ui.a(0xFFFFFFFF, 0.06f)));
        Ui.text(g, textRenderer, "LIVE MONITOR", rx + 10, (int) y + 6, c(0xFF8B8BA3));
        Ui.textR(g, textRenderer, PulseHub.bpmText(), rx + rw - 10, (int) y + 6, c(0xFFD0D0E4));
        PulseHub.drawEcg(g, rx + 8, (int) y + 17, rw - 16, 24, am);
        return 46f;
    }

    /** Draws one module card. Returns its animated height. */
    private float drawModule(DrawContext g, float dt, Module m, int rx, float y, int rw, float mx, float my) {
        boolean hovHead = in(mx, my, rx, (int) y, rw, HEAD) && in(mx, my, crx, cry, crw, crh);
        m.hover = Fx.damp(m.hover, hovHead ? 1f : 0f, 18f, dt);
        m.anim = Fx.damp(m.anim, m.on ? 1f : 0f, 16f, dt);
        boolean wantOpen = m.alwaysOpen || m.expanded;
        m.openAnim = Fx.damp(m.openAnim, wantOpen ? 1f : 0f, 13f, dt);
        float oa = Fx.smooth(m.openAnim);
        int n = m.settings.size();
        float h = HEAD + (n * ROW + 6f) * oa;

        if (y + h < cry - 4 || y > cry + crh + 4) { settleSettings(m, dt); return h; }

        Ui.rr(g, rx, y, rw, Math.round(h), 7, c(Ui.a(0xFFFFFFFF, 0.06f + 0.05f * m.hover)));
        if (!m.noToggle) {
            if (m.anim > 0.02f) Ui.rr(g, rx, y + 6, 2, HEAD - 12, 1, c(Fx.argb(Fx.gradT(y * 0.004f), m.anim)));
            Ui.toggle(g, rx + 9, (int) y + 6, 20, 10, m.anim, am);
        } else {
            for (int i = 0; i < 10; i++) {
                g.fill(rx + 9 + i * 2, (int) y + 7, rx + 11 + i * 2, (int) y + 15, c(Fx.argb(Fx.gradT(i / 10f), 0.95f)));
            }
        }
        int lx = m.noToggle ? rx + 36 : rx + 36;
        int lc = m.noToggle ? 0xFFFFFF : Fx.lerp(0x8B8BA3, 0xFFFFFF, Math.max(m.anim * 0.7f, m.hover * 0.6f));
        Ui.text(g, textRenderer, m.label, lx, (int) y + 7, c(0xFF000000 | lc));

        int rightEdge = rx + rw - 8;
        if (!m.settings.isEmpty() && !m.alwaysOpen) {
            Ui.chevron(g, rx + rw - 13, y + HEAD / 2f, m.openAnim * 90f, c(Ui.a(0xFFFFFFFF, 0.35f + 0.4f * m.hover)));
            rightEdge -= 14;
        }
        if (!m.noToggle && (m.bind != 0 || binding == m)) {
            String t = binding == m ? "..." : InputUtil.fromKeyCode(m.bind, 0).getLocalizedText().getString();
            int tw = textRenderer.getWidth(t) + 10;
            float pulse = binding == m ? 0.55f + 0.45f * MathHelper.sin((float) (Fx.ms() * 0.01)) : 0.5f;
            Ui.rr(g, rightEdge - tw, y + 5, tw, 12, 6, c(Fx.argb(Fx.gradT(0.2f), 0.16f + 0.1f * pulse)));
            Ui.text(g, textRenderer, t, rightEdge - tw + 5, (int) y + 7, c(0xFFD0D0E4));
        }
        hits.add(new Hit(rx, (int) y, rw, HEAD, K_MOD, 0, m, null));

        if (oa > 0.02f) {
            float savedAm = am;
            am = savedAm * oa * oa;
            for (int i = 0; i < n; i++) {
                float sy = y + HEAD + 2 + i * ROW + (1f - oa) * -6f;
                drawSetting(g, dt, m.settings.get(i), rx, sy, rw, mx, my);
            }
            am = savedAm;
        } else {
            settleSettings(m, dt);
        }
        return h;
    }

    private void settleSettings(Module m, float dt) {
        for (Setting s : m.settings) s.anim = Fx.damp(s.anim, s.type == Setting.Type.NUM ? s.norm() : (s.b ? 1f : 0f), 20f, dt);
    }

    private void drawSetting(DrawContext g, float dt, Setting s, int rx, float sy, int rw, float mx, float my) {
        int right = rx + rw - 10;
        boolean hov = in(mx, my, rx, (int) sy, rw, ROW) && in(mx, my, crx, cry, crw, crh);
        s.hover = Fx.damp(s.hover, (hov || dragging == s) ? 1f : 0f, 18f, dt);
        Ui.text(g, textRenderer, s.label, rx + 13, (int) sy + 5, c(Ui.a(0xFFFFFFFF, 0.55f + 0.35f * s.hover)));

        switch (s.type) {
            case BOOL -> {
                s.anim = Fx.damp(s.anim, s.b ? 1f : 0f, 18f, dt);
                Ui.toggle(g, right - 20, (int) sy + 3, 20, 10, s.anim, am);
                hits.add(new Hit(rx, (int) sy, rw, ROW, K_BOOL, 0, null, s));
            }
            case MODE -> {
                int pw = 84;
                Ui.rr(g, right - pw, sy + 2, pw, 13, 6, c(Ui.a(0xFFFFFFFF, 0.08f + 0.05f * s.hover)));
                String t = s.modes[s.mode];
                Ui.text(g, textRenderer, t, right - pw / 2 - textRenderer.getWidth(t) / 2, (int) sy + 5, c(0xFF000000 | Fx.gradT(0.1f)));
                Ui.text(g, textRenderer, "<", right - pw + 5, (int) sy + 5, c(0xFF565670));
                Ui.text(g, textRenderer, ">", right - 10, (int) sy + 5, c(0xFF565670));
                hits.add(new Hit(right - pw, (int) sy, pw, ROW, K_MODE, 0, null, s));
            }
            case NUM -> {
                s.anim = Fx.damp(s.anim, s.norm(), 24f, dt);
                Ui.textR(g, textRenderer, s.display(), right, (int) sy + 5, c(0xFFD0D0E4));
                int x0 = right - 34 - 6 - TRACK;
                float ty = sy + 7.5f;
                float f = Fx.clamp01(s.anim);
                if (s.hue) {
                    for (int i = 0; i < TRACK / 4; i++) {
                        g.fill(x0 + i * 4, (int) ty, x0 + i * 4 + 4, (int) ty + 3, c(0xFF000000 | Fx.rgb(i / (TRACK / 4f))));
                    }
                } else {
                    Ui.rr(g, x0, ty, TRACK, 3, 1, c(0x26FFFFFF));
                    Ui.bar(g, x0, ty, TRACK * f, 3, c(Fx.argb(Fx.gradT(0.2f), 0.95f)));
                }
                float kr = 3.5f + 1.2f * s.hover;
                float kx = x0 + TRACK * f;
                if (s.hover > 0.02f) Ui.rr(g, kx - kr - 2, ty + 1.5f - kr - 2, Math.round(kr * 2 + 4), Math.round(kr * 2 + 4),
                        (int) kr + 2, c(Fx.argb(Fx.gradT(0.2f), 0.18f * s.hover)));
                Ui.rr(g, kx - kr, ty + 1.5f - kr, Math.round(kr * 2), Math.round(kr * 2), (int) kr, c(0xFFFFFFFF));
                hits.add(new Hit(x0 - 4, (int) sy, TRACK + 8, ROW, K_SLIDER, 0, null, s));
            }
        }
    }

    // ------------------------------------------------------------------ input

    private float toLocalX(double mx) { return lcx + ((float) mx - lcx) / lscale; }
    private float toLocalY(double my) { return lcy + ((float) my - lcy - loff) / lscale; }

    private void slide(Setting s, float mxl) {
        s.setNorm((mxl - dragX) / TRACK);
        if (Module.THEME.settings.contains(s)) {
            if (s.hue) Module.THEME.s("preset").mode = 0;
            Config.refresh();
        }
    }

    @Override
    public boolean mouseClicked(double mxRaw, double myRaw, int button) {
        if (closing) return true;
        float mx = toLocalX(mxRaw), my = toLocalY(myRaw);
        if (!in(mx, my, px, py, W, H)) { closing = true; return true; }
        binding = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!in(mx, my, h.x(), h.y(), h.w(), h.h())) continue;
            if (h.kind() != K_TAB && !in(mx, my, crx, cry, crw, crh)) continue;
            switch (h.kind()) {
                case K_TAB -> { if (tab != h.idx()) { tab = h.idx(); scrollT = 0f; scroll = 0f; tabFade = 0f; } }
                case K_MOD -> {
                    Module m = h.m();
                    if (button == 0 && !m.noToggle) { m.on = !m.on; Config.save(); }
                    else if (button == 1 && !m.settings.isEmpty() && !m.alwaysOpen) m.expanded = !m.expanded;
                    else if (button == 2 && !m.noToggle) binding = m;
                }
                case K_BOOL -> { h.s().b = !h.s().b; Config.refresh(); Config.save(); }
                case K_MODE -> {
                    Setting s = h.s();
                    int n = s.modes.length;
                    s.mode = (s.mode + (button == 1 ? n - 1 : 1)) % n;
                    if (s == Module.THEME.s("preset")) Config.applyPreset();
                    Config.save();
                }
                case K_SLIDER -> { dragging = h.s(); dragX = h.x() + 4; slide(dragging, mx); }
                default -> { }
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { slide(dragging, toLocalX(mx)); return true; }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) { dragging = null; Config.save(); }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scrollT = MathHelper.clamp(scrollT - (float) vAmount * 30f, 0f, maxScroll);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding != null) {
            binding.bind = keyCode == 256 ? 0 : keyCode;
            binding = null;
            Config.save();
            return true;
        }
        if (keyCode == 256 || (PulseFX.menuKey != null && PulseFX.menuKey.matchesKey(keyCode, scanCode))) {
            closing = true;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
