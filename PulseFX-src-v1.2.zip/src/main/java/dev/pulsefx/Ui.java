package dev.pulsefx;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Tiny 2D toolkit: anti-aliased rounded rects, soft shadow, sub-pixel positioning. */
public final class Ui {
    private Ui() {}

    private static final int MAXR = 32;
    private static final int[][] SOLID = new int[MAXR + 1][];
    private static final float[][] EDGE = new float[MAXR + 1][];
    private static final String[] CH = new String[256];

    private static void table(int r) {
        int[] so = new int[r];
        float[] ed = new float[r];
        for (int i = 0; i < r; i++) {
            float d = r - i - 0.5f;
            float inset = r - (float) Math.sqrt(r * r - d * d);
            int fi = (int) Math.floor(inset);
            so[i] = fi + 1;
            ed[i] = 1f - (inset - fi);
        }
        SOLID[r] = so;
        EDGE[r] = ed;
    }

    private static String ch(char c) {
        if (c < 256) {
            String s = CH[c];
            if (s == null) CH[c] = s = String.valueOf(c);
            return s;
        }
        return String.valueOf(c);
    }

    public static int a(int argb, float k) {
        int al = (int) ((argb >>> 24) * MathHelper.clamp(k, 0f, 1f));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    /** Rounded rect with anti-aliased corners. x/y may be fractional (applied via the matrix). */
    public static void rr(DrawContext g, float x, float y, int w, int h, int r, int c) {
        if ((c >>> 24) < 2 || w <= 0 || h <= 0) return;
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        float fx = x - ix, fy = y - iy;
        MatrixStack m = g.getMatrices();
        boolean t = fx > 0.004f || fy > 0.004f;
        if (t) { m.push(); m.translate(fx, fy, 0f); }
        r = Math.min(r, Math.min(Math.min(w, h) / 2, MAXR));
        if (r <= 0) {
            g.fill(ix, iy, ix + w, iy + h, c);
        } else {
            if (SOLID[r] == null) table(r);
            int[] so = SOLID[r];
            float[] ed = EDGE[r];
            if (h - 2 * r > 0) g.fill(ix, iy + r, ix + w, iy + h - r, c);
            for (int i = 0; i < r; i++) {
                int s = so[i];
                int xl = ix + s, xr = ix + w - s;
                if (xl < xr) {
                    g.fill(xl, iy + i, xr, iy + i + 1, c);
                    g.fill(xl, iy + h - 1 - i, xr, iy + h - i, c);
                }
                int ec = a(c, ed[i]);
                int e = s - 1;
                g.fill(ix + e, iy + i, ix + e + 1, iy + i + 1, ec);
                g.fill(ix + w - 1 - e, iy + i, ix + w - e, iy + i + 1, ec);
                g.fill(ix + e, iy + h - 1 - i, ix + e + 1, iy + h - i, ec);
                g.fill(ix + w - 1 - e, iy + h - 1 - i, ix + w - e, iy + h - i, ec);
            }
        }
        if (t) m.pop();
    }

    public static void shadow(DrawContext g, float x, float y, int w, int h, int r, float k) {
        for (int i = 4; i >= 1; i--) {
            float f = 1f - i / 5f;
            rr(g, x - i, y - i + 2, w + 2 * i, h + 2 * i, r + i, a(0x40000000, k * f * f * 0.7f));
        }
    }

    /** Bar with a fractional right edge (anti-aliased column) so fills grow smoothly. */
    public static void bar(DrawContext g, float x, float y, float w, int h, int c) {
        if (w <= 0f) return;
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        int ww = (int) w;
        float frac = w - ww;
        if (ww > 0) g.fill(ix, iy, ix + ww, iy + h, c);
        if (frac > 0.02f) g.fill(ix + ww, iy, ix + ww + 1, iy + h, a(c, frac));
    }

    public static void pix(DrawContext g, int x, int y, int c) {
        if ((c >>> 24) < 4) return;
        g.fill(x, y, x + 1, y + 1, c);
    }

    public static void text(DrawContext g, TextRenderer tr, String s, int x, int y, int c) {
        if ((c >>> 24) < 8) return;
        g.drawText(tr, s, x, y, c, false);
    }

    /** Text at a fractional position (smooth slide animations). */
    public static void textF(DrawContext g, TextRenderer tr, String s, float x, float y, int c) {
        if ((c >>> 24) < 8) return;
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y);
        float fx = x - ix, fy = y - iy;
        if (fx > 0.01f || fy > 0.01f) {
            MatrixStack m = g.getMatrices();
            m.push();
            m.translate(fx, fy, 0f);
            g.drawText(tr, s, ix, iy, c, false);
            m.pop();
        } else {
            g.drawText(tr, s, ix, iy, c, false);
        }
    }

    public static void textR(DrawContext g, TextRenderer tr, String s, int right, int y, int c) {
        text(g, tr, s, right - tr.getWidth(s), y, c);
    }

    /** Text with a per-character animated accent gradient. */
    public static int gradText(DrawContext g, TextRenderer tr, String s, int x, int y, float alpha, float phaseStep) {
        for (int i = 0; i < s.length(); i++) {
            String c = ch(s.charAt(i));
            text(g, tr, c, x, y, Fx.argb(Fx.gradT(i * phaseStep), alpha));
            x += tr.getWidth(c);
        }
        return x;
    }

    /** Smooth switch: knob position and track color follow k (0..1). */
    public static void toggle(DrawContext g, int x, int y, int w, int h, float k, float alpha) {
        int accent = Fx.gradT(x * 0.002f);
        int track = Fx.lerp(0x3A3A4C, accent, k);
        if (k > 0.02f) rr(g, x - 1, y - 1, w + 2, h + 2, h / 2 + 1, Fx.argb(accent, 0.18f * k * alpha));
        rr(g, x, y, w, h, h / 2, Fx.argb(track, alpha));
        int kd = h - 4;
        rr(g, x + 2 + (w - kd - 4) * k, y + 2, kd, kd, kd / 2, Fx.argb(0xFFFFFF, alpha * (0.78f + 0.22f * k)));
    }

    public static void chevron(DrawContext g, float cx, float cy, float deg, int c) {
        MatrixStack m = g.getMatrices();
        m.push();
        m.translate(cx, cy, 0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(deg));
        for (int i = -3; i <= 3; i++) {
            int xx = 1 - Math.abs(i);
            g.fill(xx, i, xx + 1, i + 1, c);
        }
        m.pop();
    }
}
