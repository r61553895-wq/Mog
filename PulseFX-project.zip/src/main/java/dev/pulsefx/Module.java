package dev.pulsefx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Module {
    public static final List<Module> ALL = new ArrayList<>();

    public static final Module JUMP_CIRCLES = new Module("circles", "Jump Circles", "Visuals")
            .num("size", "Size", 0.5f, 2.5f, 0.1f, 1.0f)
            .num("life", "Duration (ms)", 400, 1800, 50, 900);
    public static final Module TRAIL = new Module("trail", "Trail", "Visuals")
            .num("length", "Length", 8, 60, 1, 28)
            .num("height", "Height", 0.3f, 2.0f, 0.1f, 0.9f);
    public static final Module HIT_FX = new Module("hit", "Hit FX", "Visuals")
            .num("count", "Particles", 0, 40, 1, 14)
            .bool("ring", "Ground ring", true);
    public static final Module TARGET_ESP = new Module("target", "Target ESP", "Visuals")
            .mode("style", "Style", "Bands", "Ring", "Both")
            .num("speed", "Speed", 0.3f, 3.0f, 0.1f, 1.0f);
    public static final Module HUD = new Module("hud", "HUD", "Visuals")
            .bool("coords", "Coordinates", true)
            .bool("list", "Module list", true);

    public static final Module SWING = new Module("swing", "Swing Animation", "Animations")
            .mode("mode", "Animation", "Smooth", "Slash", "Spin", "Stab", "Chop", "Whip", "Vanilla")
            .num("power", "Intensity", 0.5f, 2.0f, 0.05f, 1.0f);

    public static final Module VIEWMODEL = new Module("viewmodel", "View Model", "ViewModel")
            .num("x", "Position X", -1f, 1f, 0.02f, 0f)
            .num("y", "Position Y", -1f, 1f, 0.02f, 0f)
            .num("z", "Position Z", -1f, 1f, 0.02f, 0f)
            .num("rx", "Rotation X", -180, 180, 1, 0)
            .num("ry", "Rotation Y", -180, 180, 1, 0)
            .num("rz", "Rotation Z", -180, 180, 1, 0)
            .num("scale", "Scale", 0.3f, 1.5f, 0.05f, 1.0f);

    public final String id, label, category;
    public boolean on = true;
    public int bind = -1;
    boolean wasDown;
    public final List<Setting> settings = new ArrayList<>();
    private final Map<String, Setting> map = new HashMap<>();

    // GUI state
    public boolean expanded;
    public float anim = 1f, openAnim;

    private Module(String id, String label, String category) {
        this.id = id; this.label = label; this.category = category;
        ALL.add(this);
    }

    private Module add(Setting s) { settings.add(s); map.put(s.id, s); return this; }
    private Module num(String id, String l, float min, float max, float step, float def) { return add(Setting.num(id, l, min, max, step, def)); }
    private Module bool(String id, String l, boolean def) { return add(Setting.bool(id, l, def)); }
    private Module mode(String id, String l, String... modes) { return add(Setting.mode(id, l, modes)); }

    public float num(String id) { return map.get(id).v; }
    public boolean flag(String id) { return map.get(id).b; }
    public int mode(String id) { return map.get(id).mode; }
}
