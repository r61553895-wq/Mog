package dev.pulsefx;

public enum Module {
    JUMP_CIRCLES("circles", "Jump Circles"),
    TRAIL("trail", "Trail"),
    HIT_FX("hit", "Hit FX"),
    TARGET_ESP("target", "Target ESP"),
    HUD("hud", "HUD");

    public final String id, label;
    public boolean on = true;
    public int bind = -1;      // GLFW key code, -1 = none
    boolean wasDown;

    Module(String id, String label) { this.id = id; this.label = label; }
}
