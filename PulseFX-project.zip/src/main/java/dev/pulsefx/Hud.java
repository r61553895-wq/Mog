package dev.pulsefx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;

public final class Hud {
    private Hud() {}

    public static void render(DrawContext g, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Module.HUD.on || mc.player == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        float time = Effects.time();

        PlayerListEntry e = mc.getNetworkHandler() == null ? null
                : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        int ping = e == null ? 0 : e.getLatency();

        String name = "PulseFX";
        String info = mc.getCurrentFps() + " FPS  " + ping + " ms  "
                + (int) mc.player.getX() + " " + (int) mc.player.getY() + " " + (int) mc.player.getZ();

        int x = 6, y = 6;
        int w = tr.getWidth(name) + tr.getWidth(info) + 20;

        g.fill(x, y, x + w, y + 16, 0x99101018);
        for (int i = 0; i < w; i += 3) {
            g.fill(x + i, y, Math.min(x + i + 3, x + w), y + 1, 0xFF000000 | Effects.grad(i / 40f, time));
        }

        int cx = x + 6;
        for (char ch : name.toCharArray()) {
            String s = String.valueOf(ch);
            g.drawText(tr, s, cx, y + 4, 0xFF000000 | Effects.grad(cx / 20f, time), true);
            cx += tr.getWidth(s);
        }
        g.drawText(tr, info, cx + 10, y + 4, 0xFFE6E6F0, true);

        int ry = y + 20;
        for (Module m : Module.values()) {
            if (!m.on || m == Module.HUD) continue;
            int tw = tr.getWidth(m.label);
            g.fill(x, ry, x + tw + 8, ry + 11, 0x77101018);
            g.fill(x, ry, x + 2, ry + 11, 0xFF000000 | Effects.grad(ry / 15f, time));
            g.drawText(tr, m.label, x + 5, ry + 2, 0xFFFFFFFF, true);
            ry += 12;
        }
    }
}
