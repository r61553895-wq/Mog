package dev.pulsefx;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    public static int c1 = 0x9B5CFF, c2 = 0x35E6FF;
    public static boolean rainbow = false;

    private Config() {}

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("pulsefx.json"); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            if (o.has("c1")) c1 = o.get("c1").getAsInt();
            if (o.has("c2")) c2 = o.get("c2").getAsInt();
            if (o.has("rainbow")) rainbow = o.get("rainbow").getAsBoolean();
            JsonObject ms = o.has("modules") ? o.getAsJsonObject("modules") : null;
            if (ms != null) for (Module m : Module.values()) {
                if (!ms.has(m.id)) continue;
                JsonObject mo = ms.getAsJsonObject(m.id);
                if (mo.has("on")) m.on = mo.get("on").getAsBoolean();
                if (mo.has("bind")) m.bind = mo.get("bind").getAsInt();
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("c1", c1);
            o.addProperty("c2", c2);
            o.addProperty("rainbow", rainbow);
            JsonObject ms = new JsonObject();
            for (Module m : Module.values()) {
                JsonObject mo = new JsonObject();
                mo.addProperty("on", m.on);
                mo.addProperty("bind", m.bind);
                ms.add(m.id, mo);
            }
            o.add("modules", ms);
            Files.writeString(file(), o.toString());
        } catch (Exception ignored) {}
    }
}
