package dev.pulsefx;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** World-space effects. One batched draw call per frame. Everything is depth-tested (nothing through walls). */
public final class Effects {
    private record Circle(double x, double y, double z, long start) {}

    private static final List<Circle> circles = new ArrayList<>();
    private static final ArrayDeque<Vec3d> trail = new ArrayDeque<>();
    private static boolean wasGround;

    private static LivingEntity target;
    private static long targetTime, targetStart;

    private static final int TRAIL_MAX = 28, SEG = 40, MAX_CIRCLES = 12;
    private static final long LIFE = 900, TARGET_LIFE = 4000;

    private Effects() {}

    public static void addCircle(double x, double y, double z) {
        if (circles.size() < MAX_CIRCLES) circles.add(new Circle(x, y, z, System.currentTimeMillis()));
    }

    public static void setTarget(LivingEntity e) {
        long now = System.currentTimeMillis();
        if (target != e || now - targetTime > TARGET_LIFE) targetStart = now;
        target = e;
        targetTime = now;
    }

    /** Theme gradient (or rainbow), returns RGB. */
    public static int grad(float angle, float time) {
        if (Config.rainbow) {
            float h = (angle * 0.16f + time / MathHelper.TAU) % 1f;
            if (h < 0) h += 1f;
            return MathHelper.hsvToRgb(h, 0.65f, 1f) & 0xFFFFFF;
        }
        float f = (MathHelper.sin(angle * 2f + time) + 1f) * 0.5f;
        return lerpRgb(Config.c1, Config.c2, f);
    }

    public static int lerpRgb(int a, int b, float f) {
        int r = (int) MathHelper.lerp(f, (a >> 16) & 255, (b >> 16) & 255);
        int g = (int) MathHelper.lerp(f, (a >> 8) & 255, (b >> 8) & 255);
        int bl = (int) MathHelper.lerp(f, a & 255, b & 255);
        return (r << 16) | (g << 8) | bl;
    }

    public static float time() {
        return (System.currentTimeMillis() % 6000L) / 6000f * MathHelper.TAU;
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { circles.clear(); trail.clear(); target = null; return; }

        boolean ground = p.isOnGround();
        if (Module.JUMP_CIRCLES.on && wasGround && !ground && p.getVelocity().y > 0.1) {
            addCircle(p.getX(), p.getY(), p.getZ());
        }
        wasGround = ground;

        if (Module.TRAIL.on) {
            Vec3d pos = p.getPos(), last = trail.peekLast();
            if (last == null || last.squaredDistanceTo(pos) > 0.0004) trail.addLast(pos);
            else trail.pollFirst();
            while (trail.size() > TRAIL_MAX) trail.pollFirst();
        } else trail.clear();

        long now = System.currentTimeMillis();
        circles.removeIf(c -> now - c.start > LIFE);
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        MatrixStack ms = ctx.matrixStack();
        if (ms == null || mc.player == null) return;

        long now = System.currentTimeMillis();
        LivingEntity t = Module.TARGET_ESP.on ? target : null;
        if (t != null && (!t.isAlive() || t.isRemoved() || t == mc.player || now - targetTime > TARGET_LIFE)) {
            target = null; t = null;
        }
        boolean doTrail = Module.TRAIL.on && trail.size() > 1;
        if (circles.isEmpty() && !doTrail && t == null) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f m = ms.peek().getPositionMatrix();
        float time = time();
        float tickDelta = ctx.tickCounter().getTickDelta(false);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        for (Circle c : circles) {
            float k = (now - c.start) / (float) LIFE;
            float ease = 1f - (1f - k) * (1f - k) * (1f - k);
            float r = 0.4f + 1.7f * ease;
            float w = 0.38f * (1f - k * 0.5f);
            int a = (int) ((1f - k) * 220f);
            float cx = (float) (c.x - cam.x), cy = (float) (c.y + 0.03 - cam.y), cz = (float) (c.z - cam.z);
            ring(b, m, cx, cy, cz, r - w, r, 0, a, time);
            ring(b, m, cx, cy, cz, r, r + w * 0.35f, a, 0, time);
        }

        if (doTrail) {
            Vec3d cur = mc.player.getLerpedPos(tickDelta);
            int n = trail.size() + 1, i = 0;
            Vec3d prev = null;
            for (Vec3d p : trail) {
                if (prev != null) seg(b, m, cam, prev, p, (i - 1) / (float) n, i / (float) n, time);
                prev = p; i++;
            }
            if (prev != null) seg(b, m, cam, prev, cur, (i - 1) / (float) n, i / (float) n, time);
        }

        if (t != null) {
            Vec3d tp = t.getLerpedPos(tickDelta);
            float age = now - targetTime;
            float fade = Math.min(1f, (now - targetStart) / 250f) * Math.min(1f, (TARGET_LIFE - age) / 800f);
            float h = t.getHeight(), r = t.getWidth() * 0.7f + 0.2f;
            float cx = (float) (tp.x - cam.x), cy = (float) (tp.y - cam.y), cz = (float) (tp.z - cam.z);
            int a = (int) (210 * fade);
            float hh = 0.12f + h * 0.06f;
            float p = 0.5f + 0.5f * MathHelper.sin((now % 2400L) / 2400f * MathHelper.TAU);
            band(b, m, cx, cy + h * p, cz, r, hh, a, time);
            band(b, m, cx, cy + h * (1f - p), cz, r, hh, a / 2, time + 1f);
            ring(b, m, cx, cy + 0.03f, cz, r * 0.7f, r, 0, a / 2, time);
        }

        BuiltBuffer built = b.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    /** Vertical glowing band around the target (alpha fades up and down from the middle). */
    private static void band(BufferBuilder b, Matrix4f m, float cx, float cy, float cz,
                             float r, float hh, int a, float time) {
        for (int i = 0; i < SEG; i++) {
            float t0 = i * MathHelper.TAU / SEG, t1 = (i + 1) * MathHelper.TAU / SEG;
            float x0 = cx + MathHelper.cos(t0) * r, z0 = cz + MathHelper.sin(t0) * r;
            float x1 = cx + MathHelper.cos(t1) * r, z1 = cz + MathHelper.sin(t1) * r;
            int c0 = argbRgb(grad(t0, time)), c1 = argbRgb(grad(t1, time));
            // lower half
            b.vertex(m, x0, cy - hh, z0).color(withA(c0, 0));
            b.vertex(m, x0, cy, z0).color(withA(c0, a));
            b.vertex(m, x1, cy, z1).color(withA(c1, a));
            b.vertex(m, x1, cy - hh, z1).color(withA(c1, 0));
            // upper half
            b.vertex(m, x0, cy, z0).color(withA(c0, a));
            b.vertex(m, x0, cy + hh, z0).color(withA(c0, 0));
            b.vertex(m, x1, cy + hh, z1).color(withA(c1, 0));
            b.vertex(m, x1, cy, z1).color(withA(c1, a));
        }
    }

    private static void seg(BufferBuilder b, Matrix4f m, Vec3d cam, Vec3d p0, Vec3d p1, float f0, float f1, float time) {
        float x0 = (float) (p0.x - cam.x), y0 = (float) (p0.y - cam.y), z0 = (float) (p0.z - cam.z);
        float x1 = (float) (p1.x - cam.x), y1 = (float) (p1.y - cam.y), z1 = (float) (p1.z - cam.z);
        int c0 = grad(f0 * 5f, time), c1 = grad(f1 * 5f, time);
        int lo0 = (int) (f0 * 170), lo1 = (int) (f1 * 170), hi0 = lo0 / 6, hi1 = lo1 / 6;
        float h = 0.9f;
        b.vertex(m, x0, y0 + 0.05f, z0).color(argb(c0, lo0));
        b.vertex(m, x0, y0 + h, z0).color(argb(c0, hi0));
        b.vertex(m, x1, y1 + h, z1).color(argb(c1, hi1));
        b.vertex(m, x1, y1 + 0.05f, z1).color(argb(c1, lo1));
    }

    private static void ring(BufferBuilder b, Matrix4f m, float cx, float cy, float cz,
                             float r0, float r1, int a0, int a1, float time) {
        for (int i = 0; i < SEG; i++) {
            float t0 = i * MathHelper.TAU / SEG, t1 = (i + 1) * MathHelper.TAU / SEG;
            float s0 = MathHelper.sin(t0), k0 = MathHelper.cos(t0), s1 = MathHelper.sin(t1), k1 = MathHelper.cos(t1);
            int c0 = grad(t0, time), c1 = grad(t1, time);
            b.vertex(m, cx + k0 * r0, cy, cz + s0 * r0).color(argb(c0, a0));
            b.vertex(m, cx + k0 * r1, cy, cz + s0 * r1).color(argb(c0, a1));
            b.vertex(m, cx + k1 * r1, cy, cz + s1 * r1).color(argb(c1, a1));
            b.vertex(m, cx + k1 * r0, cy, cz + s1 * r0).color(argb(c1, a0));
        }
    }

    private static int argbRgb(int rgb) { return rgb & 0xFFFFFF; }
    private static int withA(int rgb, int a) { return argb(rgb, a); }
    private static int argb(int rgb, int a) {
        return (MathHelper.clamp(a, 0, 255) << 24) | (rgb & 0xFFFFFF);
    }
}
