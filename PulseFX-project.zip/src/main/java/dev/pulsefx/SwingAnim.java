package dev.pulsefx;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Replacement for vanilla first-person swing transform. Every animation is identity at progress 0 and 1. */
public final class SwingAnim {
    private SwingAnim() {}

    private static void rx(MatrixStack m, float d) { m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(d)); }
    private static void ry(MatrixStack m, float d) { m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(d)); }
    private static void rz(MatrixStack m, float d) { m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(d)); }

    /** @return true if the animation was applied (vanilla swing must be cancelled). */
    public static boolean apply(MatrixStack m, Arm arm, float p) {
        int mode = Module.SWING.mode("mode");
        if (mode == 6) return false; // Vanilla
        float k = Module.SWING.num("power");
        float i = arm == Arm.RIGHT ? 1f : -1f;
        float s = MathHelper.sin(p * MathHelper.PI);
        float g = MathHelper.sin(MathHelper.sqrt(p) * MathHelper.PI);

        switch (mode) {
            case 0 -> { // Smooth
                float q = p * p * (3f - 2f * p);
                float e = MathHelper.sin(q * MathHelper.PI);
                ry(m, i * 45f);
                rz(m, i * e * -18f * k);
                rx(m, e * -90f * k);
                ry(m, i * -45f);
                m.translate(0f, 0f, -e * 0.08f * k);
            }
            case 1 -> { // Slash
                rz(m, i * g * -35f * k);
                ry(m, i * g * 65f * k);
                rx(m, g * -25f * k);
                m.translate(i * -g * 0.12f * k, 0f, 0f);
            }
            case 2 -> { // Spin
                float q = p * p * (3f - 2f * p);
                m.translate(0f, s * 0.15f, -s * 0.12f);
                ry(m, i * 360f * q);
            }
            case 3 -> { // Stab
                m.translate(0f, -s * 0.04f * k, -s * 0.75f * k);
                rx(m, s * -12f);
            }
            case 4 -> { // Chop
                rz(m, i * g * -30f * k);
                rx(m, g * -120f * k);
                m.translate(0f, -g * 0.15f, -g * 0.1f);
            }
            case 5 -> { // Whip
                float w = MathHelper.sin(p * MathHelper.TAU);
                rx(m, w * -55f * k);
                rz(m, i * s * -25f * k);
                m.translate(0f, 0f, -s * 0.2f * k);
            }
            default -> { return false; }
        }
        return true;
    }
}
