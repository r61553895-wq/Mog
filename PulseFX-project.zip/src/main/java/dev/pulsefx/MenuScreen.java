package dev.pulsefx;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class MenuScreen extends Screen {
    private static final int PW = 340, PH = 272, ROW = 22, SW = 98;
    private static final int[][] PRESETS = {
            {0x9B5CFF, 0x35E6FF}, {0xFF3D3D, 0xFFC13D}, {0x2F6BFF, 0x2FFFD0},
            {0x3DFFA2, 0xD0FF3D}, {0xFF5CA8, 0xFFC2E0}
    };
    private static final int[] CH_COLORS = {0xFFE05050, 0xFF50C060, 0xFF5080E0};

    private Module listening;
    private int dragging = -1;

    public MenuScreen() { super(Text.literal("PulseFX")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x77000000);
    }

    private int px() { return (width - PW) / 2; }
    private int py() { return (height - PH) / 2; }
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
    private void ctext(DrawContext g, String s, int cx, int y, int col) {
        g.drawText(textRenderer, s, cx - textRenderer.getWidth(s) / 2, y, col, true);
    }
    private static String keyName(int key) {
        if (key < 0) return "NONE";
        String s = InputUtil.fromKeyCode(key, 0).getLocalizedText().getString().toUpperCase();
        return s.length() > 10 ? s.substring(0, 10) : s;
    }
    private static int ch(int rgb, int k) { return (rgb >> (16 - 8 * k)) & 255; }
    private static int setCh(int rgb, int k, int v) {
        int sh = 16 - 8 * k;
        return (rgb & ~(255 << sh)) | (v << sh);
    }
    private int sliderX(int d) { return px() + 14 + (d % 3) * (SW + 8); }
    private int sliderY(int d) { return py() + 150 + (d / 3 == 0 ? 48 : 78); }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        float time = Effects.time();
        int px = px(), py = py();

        g.fill(px, py, px + PW, py + PH, 0xEE111118);
        for (int i = 0; i < PW; i += 4) {
            g.fill(px + i, py, Math.min(px + i + 4, px + PW), py + 2, 0xFF000000 | Effects.grad(i / 50f, time));
        }
        g.drawText(textRenderer, "PulseFX", px + 14, py + 11, 0xFF000000 | Effects.grad(0f, time), true);
        String hint = "click bind, then press a key (Backspace = clear)";
        g.drawText(textRenderer, hint, px + PW - 14 - textRenderer.getWidth(hint), py + 11, 0xFF8A8A99, false);

        Module[] ms = Module.values();
        for (int i = 0; i < ms.length; i++) {
            Module m = ms[i];
            int ry = py + 30 + i * ROW;
            int bx = px + PW - 14 - 100, tx = bx - 6 - 50;
            g.fill(px + 8, ry, px + PW - 8, ry + ROW - 2, in(mx, my, px + 8, ry, PW - 16, ROW - 2) ? 0x33FFFFFF : 0x18FFFFFF);
            g.drawText(textRenderer, m.label, px + 14, ry + 7, 0xFFFFFFFF, true);

            g.fill(tx, ry + 3, tx + 50, ry + 17, m.on ? 0xFF000000 | Effects.grad(i, time) : 0xFF2A2A33);
            ctext(g, m.on ? "ON" : "OFF", tx + 25, ry + 7, 0xFFFFFFFF);

            g.fill(bx, ry + 3, bx + 100, ry + 17, listening == m ? 0xFF3A3A55 : 0xFF22222B);
            ctext(g, listening == m ? "press key..." : keyName(m.bind), bx + 50, ry + 7, listening == m ? 0xFFFFFFFF : 0xFFB8B8C8);
        }

        int cy0 = py + 150;
        g.drawText(textRenderer, "Theme", px + 14, cy0, 0xFFFFFFFF, true);
        for (int i = 0; i < 6; i++) {
            int x = px + 14 + i * 46, y = cy0 + 12;
            for (int s = 0; s < 40; s += 2) {
                float f = s / 40f;
                int col = i < 5 ? Effects.lerpRgb(PRESETS[i][0], PRESETS[i][1], f)
                        : MathHelper.hsvToRgb(f, 0.65f, 1f);
                g.fill(x + s, y, x + s + 2, y + 16, 0xFF000000 | col);
            }
            boolean sel = i < 5 ? (!Config.rainbow && Config.c1 == PRESETS[i][0] && Config.c2 == PRESETS[i][1]) : Config.rainbow;
            if (sel || in(mx, my, x, y, 40, 16)) {
                int bc = sel ? 0xFFFFFFFF : 0x88FFFFFF;
                g.fill(x - 1, y - 1, x + 41, y, bc); g.fill(x - 1, y + 16, x + 41, y + 17, bc);
                g.fill(x - 1, y, x, y + 16, bc); g.fill(x + 40, y, x + 41, y + 16, bc);
            }
        }

        g.drawText(textRenderer, "Color 1", px + 14, cy0 + 36, 0xFFB8B8C8, false);
        g.drawText(textRenderer, "Color 2", px + 14, cy0 + 66, 0xFFB8B8C8, false);
        for (int d = 0; d < 6; d++) {
            int x = sliderX(d), y = sliderY(d), k = d % 3;
            int v = ch(d < 3 ? Config.c1 : Config.c2, k);
            g.fill(x, y, x + SW, y + 12, 0xFF22222B);
            g.fill(x, y, x + (int) (SW * v / 255f), y + 12, CH_COLORS[k]);
            ctext(g, String.valueOf(v), x + SW / 2, y + 2, 0xFFFFFFFF);
        }

        for (int s = 0; s < PW - 28; s += 2) {
            float f = s / (float) (PW - 28);
            int col = Config.rainbow ? MathHelper.hsvToRgb(f, 0.65f, 1f) : Effects.lerpRgb(Config.c1, Config.c2, f);
            g.fill(px + 14 + s, cy0 + 98, px + 16 + s, cy0 + 106, 0xFF000000 | col);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        int px = px(), py = py();

        Module[] ms = Module.values();
        for (int i = 0; i < ms.length; i++) {
            Module m = ms[i];
            int ry = py + 30 + i * ROW;
            int bx = px + PW - 14 - 100, tx = bx - 6 - 50;
            if (in(mx, my, tx, ry + 3, 50, 14)) { m.on = !m.on; Config.save(); return true; }
            if (in(mx, my, bx, ry + 3, 100, 14)) { listening = listening == m ? null : m; return true; }
        }

        int cy0 = py + 150;
        for (int i = 0; i < 6; i++) {
            if (in(mx, my, px + 14 + i * 46, cy0 + 12, 40, 16)) {
                if (i < 5) { Config.c1 = PRESETS[i][0]; Config.c2 = PRESETS[i][1]; Config.rainbow = false; }
                else Config.rainbow = true;
                Config.save();
                return true;
            }
        }

        for (int d = 0; d < 6; d++) {
            if (in(mx, my, sliderX(d), sliderY(d) - 2, SW, 16)) {
                dragging = d;
                setSlider(d, mx);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    private void setSlider(int d, double mx) {
        int v = MathHelper.clamp((int) ((mx - sliderX(d)) / SW * 255), 0, 255);
        if (d < 3) Config.c1 = setCh(Config.c1, d % 3, v);
        else Config.c2 = setCh(Config.c2, d % 3, v);
        Config.rainbow = false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging >= 0) { setSlider(dragging, mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging >= 0) { dragging = -1; Config.save(); return true; }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) listening.bind = -1;
            else if (keyCode != GLFW.GLFW_KEY_ESCAPE) listening.bind = keyCode;
            listening = null;
            Config.save();
            return true;
        }
        if (PulseFX.menuKey.matchesKey(keyCode, scanCode)) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { Config.save(); }
}
