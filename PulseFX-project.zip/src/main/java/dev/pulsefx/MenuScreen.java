package dev.pulsefx;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

public class MenuScreen extends Screen {
    private static final String[] TABS = {"Visuals", "Animations", "ViewModel", "Theme"};
    private static final int[][] PRESETS = {
            {0x9B5CFF, 0x35E6FF}, {0xFF3D3D, 0xFFC13D}, {0x2F6BFF, 0x2FFFD0},
            {0x3DFFA2, 0xD0FF3D}, {0xFF5CA8, 0xFFC2E0}
    };
    private static final int[] CH = {0xFFE05050, 0xFF50C060, 0xFF5080E0};
    private static final int SIDE = 104;

    private static final class Hit {
        int x, y, w, h, bx, bw;
        boolean scrolled;
        IntConsumer click;
        DoubleConsumer drag;
    }

    private final List<Hit> hits = new ArrayList<>();
    private int tab;
    private float scroll, contentH;
    private Module listening;
    private DoubleConsumer dragFn;
    private int dragX, dragW;
    private int wx, wy, W, H, ax0, ay0, ax1, ay1;

    public MenuScreen() { super(Text.literal("PulseFX")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x88000000);
    }

    // ---------- helpers ----------
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
    private static void rrect(DrawContext g, int x, int y, int w, int h, int c) {
        g.fill(x + 1, y, x + w - 1, y + h, c);
        g.fill(x, y + 1, x + w, y + h - 1, c);
    }
    private static int argb(int a, int rgb) { return (MathHelper.clamp(a, 0, 255) << 24) | (rgb & 0xFFFFFF); }
    private void ctext(DrawContext g, String s, int cx, int y, int col) {
        g.drawText(textRenderer, s, cx - textRenderer.getWidth(s) / 2, y, col, true);
    }
    private void rtext(DrawContext g, String s, int rx, int y, int col) {
        g.drawText(textRenderer, s, rx - textRenderer.getWidth(s), y, col, true);
    }
    private static String keyName(int key) {
        if (key < 0) return "NONE";
        String s = InputUtil.fromKeyCode(key, 0).getLocalizedText().getString().toUpperCase();
        return s.length() > 8 ? s.substring(0, 8) : s;
    }
    private static int ch(int rgb, int k) { return (rgb >> (16 - 8 * k)) & 255; }
    private static int setCh(int rgb, int k, int v) { int sh = 16 - 8 * k; return (rgb & ~(255 << sh)) | (v << sh); }

    private void hit(int x, int y, int w, int h, boolean scrolled, IntConsumer click) {
        Hit t = new Hit(); t.x = x; t.y = y; t.w = w; t.h = h; t.scrolled = scrolled; t.click = click; hits.add(t);
    }
    private void hitDrag(int x, int y, int w, int h, boolean scrolled, int bx, int bw, DoubleConsumer drag) {
        Hit t = new Hit(); t.x = x; t.y = y; t.w = w; t.h = h; t.scrolled = scrolled; t.bx = bx; t.bw = bw; t.drag = drag; hits.add(t);
    }

    private void drawSwitch(DrawContext g, int x, int y, int w, int h, float a, float time, int seed) {
        rrect(g, x, y, w, h, 0xFF000000 | Effects.lerpRgb(0x2A2A35, Effects.grad(seed / 30f, time), a));
        int kx = x + 1 + (int) ((w - h) * a);
        rrect(g, kx, y + 1, h - 2, h - 2, 0xFFFFFFFF);
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        hits.clear();
        float time = Effects.time();

        W = Math.min(470, width - 16);
        H = Math.min(310, height - 16);
        wx = (width - W) / 2;
        wy = (height - H) / 2;
        ax0 = wx + SIDE + 12; ay0 = wy + 36; ax1 = wx + W - 12; ay1 = wy + H - 12;

        rrect(g, wx, wy, W, H, 0xF00D0D13);
        g.fill(wx + 1, wy, wx + SIDE, wy + H, 0xFF101018);
        g.fill(wx + SIDE, wy, wx + SIDE + 1, wy + H, 0x14FFFFFF);
        for (int i = 0; i < W; i += 4) g.fill(wx + i, wy, Math.min(wx + i + 4, wx + W), wy + 1, 0xFF000000 | Effects.grad(i / 60f, time));

        // logo
        g.getMatrices().push();
        g.getMatrices().translate(wx + 14, wy + 12, 0);
        g.getMatrices().scale(1.5f, 1.5f, 1f);
        int lx = 0;
        for (char c : "PulseFX".toCharArray()) {
            String s = String.valueOf(c);
            g.drawText(textRenderer, s, lx, 0, 0xFF000000 | Effects.grad(lx / 12f, time), true);
            lx += textRenderer.getWidth(s);
        }
        g.getMatrices().pop();

        // tabs
        for (int i = 0; i < TABS.length; i++) {
            int ty = wy + 48 + i * 24;
            boolean sel = i == tab, hov = in(mx, my, wx + 8, ty, SIDE - 16, 20);
            if (sel) {
                rrect(g, wx + 8, ty, SIDE - 16, 20, argb(0x40, Effects.grad(i, time)));
                g.fill(wx + 8, ty + 3, wx + 10, ty + 17, 0xFF000000 | Effects.grad(i, time));
            } else if (hov) rrect(g, wx + 8, ty, SIDE - 16, 20, 0x18FFFFFF);
            g.drawText(textRenderer, TABS[i], wx + 18, ty + 6, sel ? 0xFFFFFFFF : 0xFF8A8A99, true);
            final int idx = i;
            hit(wx + 8, ty, SIDE - 16, 20, false, b -> { tab = idx; scroll = 0; });
        }
        g.drawText(textRenderer, "RShift: close", wx + 14, wy + H - 16, 0xFF55556A, false);

        // header
        g.drawText(textRenderer, TABS[tab], ax0, wy + 14, 0xFFFFFFFF, true);
        String hint = tab == 3 ? "colors apply everywhere" : "LMB: toggle   RMB: settings";
        rtext(g, hint, ax1, wy + 14, 0xFF6A6A7A);
        g.fill(ax0, wy + 28, ax1, wy + 29, 0x22FFFFFF);

        if (tab == 3) renderTheme(g, mx, my, time);
        else renderModules(g, mx, my, time);
    }

    private void renderModules(DrawContext g, int mx, int my, float time) {
        float maxScroll = Math.max(0, contentH - (ay1 - ay0));
        scroll = MathHelper.clamp(scroll, 0, maxScroll);
        int y = ay0 - (int) scroll, cw = ax1 - ax0;
        g.enableScissor(ax0 - 4, ay0, ax1 + 4, ay1);

        for (Module m : Module.ALL) {
            if (!m.category.equals(TABS[tab])) continue;
            int sh = m.settings.isEmpty() ? 0 : m.settings.size() * 17 + 8;
            m.openAnim += ((m.expanded ? 1f : 0f) - m.openAnim) * 0.25f;
            m.anim += ((m.on ? 1f : 0f) - m.anim) * 0.25f;
            int h = 28 + (int) (sh * m.openAnim);
            boolean hov = in(mx, my, ax0, y, cw, 28) && my >= ay0 && my < ay1;

            rrect(g, ax0, y, cw, h, hov ? 0xFF1D1D29 : 0xFF16161F);
            if (m.anim > 0.02f) g.fill(ax0, y + 4, ax0 + 2, y + 24, argb((int) (255 * m.anim), Effects.grad(y / 30f, time)));
            g.drawText(textRenderer, m.label, ax0 + 12, y + 10, 0xFFFFFFFF, true);

            int arrowX = ax0 + 12 + textRenderer.getWidth(m.label) + 4;
            if (!m.settings.isEmpty()) g.drawText(textRenderer, m.expanded ? "v" : ">", arrowX + 2, y + 10, 0xFF6A6A7A, false);

            int swx = ax1 - 10 - 26, bx = swx - 10 - 54;
            drawSwitch(g, swx, y + 8, 26, 12, m.anim, time, y);
            rrect(g, bx, y + 6, 54, 16, listening == m ? 0xFF34344D : 0xFF202029);
            ctext(g, listening == m ? "..." : keyName(m.bind), bx + 27, y + 10, listening == m ? 0xFFFFFFFF : 0xFFA8A8B8);

            hit(ax0, y, bx - 6 - ax0, 28, true, b -> {
                if (b == 1 && !m.settings.isEmpty()) m.expanded = !m.expanded;
                else if (b == 0) { m.on = !m.on; Config.save(); }
            });
            if (!m.settings.isEmpty()) hit(arrowX - 2, y + 4, 16, 20, true, b -> m.expanded = !m.expanded);
            hit(bx, y + 6, 54, 16, true, b -> listening = listening == m ? null : m);
            hit(swx, y + 6, 26, 16, true, b -> { m.on = !m.on; Config.save(); });

            if (sh > 0 && m.openAnim > 0.05f) {
                g.enableScissor(ax0, y + 28, ax0 + cw, y + h);
                int sy = y + 32;
                for (Setting s : m.settings) {
                    drawSetting(g, s, sy, cw, time, m.openAnim > 0.9f);
                    sy += 17;
                }
                g.disableScissor();
            }
            y += h + 6;
        }
        g.disableScissor();
        contentH = y + (int) scroll - ay0;
    }

    private void drawSetting(DrawContext g, Setting s, int y, int cw, float time, boolean active) {
        g.drawText(textRenderer, s.label, ax0 + 12, y + 4, 0xFFB8B8C8, false);
        int rx = ax1 - 10;
        switch (s.type) {
            case BOOL -> {
                s.anim += ((s.b ? 1f : 0f) - s.anim) * 0.25f;
                drawSwitch(g, rx - 22, y + 2, 22, 11, s.anim, time, y);
                if (active) hit(rx - 24, y, 26, 15, true, b -> { s.b = !s.b; Config.save(); });
            }
            case NUM -> {
                int bw = 100, bx = rx - 46 - bw;
                float f = (s.v - s.min) / (s.max - s.min);
                int fw = (int) (bw * f);
                g.fill(bx, y + 6, bx + bw, y + 9, 0xFF2A2A35);
                for (int px = 0; px < fw; px += 2) {
                    g.fill(bx + px, y + 6, Math.min(bx + px + 2, bx + fw), y + 9, 0xFF000000 | Effects.grad(px / 20f, time));
                }
                g.fill(bx + fw - 2, y + 3, bx + fw + 2, y + 12, 0xFFFFFFFF);
                rtext(g, s.display(), rx, y + 4, 0xFFE0E0EE);
                if (active) hitDrag(bx - 3, y, bw + 6, 15, true, bx, bw, n -> s.setNorm(n));
            }
            case MODE -> {
                rrect(g, rx - 110, y + 1, 110, 13, 0xFF202029);
                ctext(g, "< " + s.modes[s.mode] + " >", rx - 55, y + 4, 0xFFE0E0EE);
                if (active) hit(rx - 110, y, 110, 15, true, b -> {
                    int n = s.modes.length;
                    s.mode = (s.mode + (b == 1 ? -1 : 1) + n) % n;
                    Config.save();
                });
            }
        }
    }

    private void renderTheme(DrawContext g, int mx, int my, float time) {
        int cw = ax1 - ax0;
        g.drawText(textRenderer, "Presets", ax0, ay0 - 2, 0xFFB8B8C8, false);
        for (int i = 0; i < 6; i++) {
            int x = ax0 + i * 54, y = ay0 + 10;
            for (int s = 0; s < 48; s += 2) {
                float f = s / 48f;
                int col = i < 5 ? Effects.lerpRgb(PRESETS[i][0], PRESETS[i][1], f) : MathHelper.hsvToRgb(f, 0.65f, 1f);
                g.fill(x + s, y, x + s + 2, y + 20, 0xFF000000 | col);
            }
            boolean sel = i < 5 ? (!Config.rainbow && Config.c1 == PRESETS[i][0] && Config.c2 == PRESETS[i][1]) : Config.rainbow;
            if (sel || in(mx, my, x, y, 48, 20)) {
                int bc = sel ? 0xFFFFFFFF : 0x88FFFFFF;
                g.fill(x - 1, y - 1, x + 49, y, bc); g.fill(x - 1, y + 20, x + 49, y + 21, bc);
                g.fill(x - 1, y, x, y + 20, bc); g.fill(x + 48, y, x + 49, y + 20, bc);
            }
            final int idx = i;
            hit(x, y, 48, 20, false, b -> {
                if (idx < 5) { Config.c1 = PRESETS[idx][0]; Config.c2 = PRESETS[idx][1]; Config.rainbow = false; }
                else Config.rainbow = true;
                Config.save();
            });
        }

        int sw = (cw - 16) / 3;
        for (int row = 0; row < 2; row++) {
            int ly = ay0 + 44 + row * 38;
            g.drawText(textRenderer, row == 0 ? "Color 1" : "Color 2", ax0, ly, 0xFFB8B8C8, false);
            for (int k = 0; k < 3; k++) {
                int x = ax0 + k * (sw + 8), y = ly + 12;
                int v = ch(row == 0 ? Config.c1 : Config.c2, k);
                rrect(g, x, y, sw, 14, 0xFF22222B);
                g.fill(x, y, x + (int) (sw * v / 255f), y + 14, CH[k]);
                ctext(g, String.valueOf(v), x + sw / 2, y + 3, 0xFFFFFFFF);
                final int fr = row, fk = k;
                hitDrag(x, y, sw, 14, false, x, sw, n -> {
                    int val = (int) (n * 255);
                    if (fr == 0) Config.c1 = setCh(Config.c1, fk, val); else Config.c2 = setCh(Config.c2, fk, val);
                    Config.rainbow = false;
                });
            }
        }

        int py = ay0 + 124;
        g.drawText(textRenderer, "Preview", ax0, py, 0xFFB8B8C8, false);
        for (int s = 0; s < cw; s += 2) {
            float f = s / (float) cw;
            int col = Config.rainbow ? MathHelper.hsvToRgb(f, 0.65f, 1f) : Effects.lerpRgb(Config.c1, Config.c2, f);
            g.fill(ax0 + s, py + 12, ax0 + s + 2, py + 24, 0xFF000000 | col);
        }
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (listening != null) { listening = null; return true; }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!in(mx, my, h.x, h.y, h.w, h.h)) continue;
            if (h.scrolled && (my < ay0 || my >= ay1)) continue;
            if (h.drag != null) {
                if (button == 0) {
                    dragFn = h.drag; dragX = h.bx; dragW = h.bw;
                    dragFn.accept(MathHelper.clamp((mx - dragX) / dragW, 0.0, 1.0));
                }
                return true;
            }
            h.click.accept(button);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragFn != null) { dragFn.accept(MathHelper.clamp((mx - dragX) / dragW, 0.0, 1.0)); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragFn != null) { dragFn = null; Config.save(); return true; }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (tab == 3) return true;
        float max = Math.max(0, contentH - (ay1 - ay0));
        scroll = MathHelper.clamp(scroll - (float) vAmount * 18f, 0, max);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) listening.bind = -1;
            else if (keyCode != GLFW.GLFW_KEY_ESCAPE) listening.bind = keyCode;
            listening = null;
            Config.save();
            return true;
        }
        if (PulseFX.menuKey.matchesKey(keyCode, scanCode)) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { Config.save(); }
}
