package dev.pulsefx.mixin;

import dev.pulsefx.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {

    /** Hide the vanilla crosshair while the custom one is enabled. require = 0: if this method changes the game still starts. */
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void pulsefx$crosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (Module.CROSSHAIR.on) ci.cancel();
    }
}
