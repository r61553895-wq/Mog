package dev.pulsefx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** HUD: list and/or radar of players around you. Uses only entities the client already has loaded. */
public final class Nearby {
    private Nearby() {}

    private record Row(String name, float dist, float hp, float maxHp, double dx, double dz) {}

    private static final int RADAR_R = 42;

    public static void render(DrawContext g, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Module.NEARBY.on || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (mc.currentScreen instanceof MenuScreen) return;

        float range = Module.NEARBY.num("range");
        List<Row> rows = new ArrayList<>();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            float d = mc.player.distanceTo(p);
            if (d > range) continue;
            rows.add(new Row(p.getName().getString(), d, p.getHealth(), Math.max(1f, p.getMaxHealth()),
                    p.getX() - mc.player.getX(), p.getZ() - mc.player.getZ()));
        }
        rows.sort((a, b) -> Float.compare(a.dist, b.dist));

        int style = Module.NEARBY.mode("style");
        boolean right = Module.NEARBY.mode("side") == 0;
        float time = Effects.time();
        TextRenderer tr = mc.textRenderer;
        int sw = g.getScaledWindowWidth();

        int y = 6;
        if (style != 0) y = drawRadar(g, rows, range, right, sw, y, time) + 6;
        if (style != 1) drawList(g, tr, rows, right, sw, y, time);
    }

    private static int drawRadar(DrawContext g, List<Row> rows, float range, boolean right, int sw, int y, float time) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int cx = right ? sw - 6 - RADAR_R : 6 + RADAR_R;
        int cy = y + RADAR_R;

        // glass disc
        for (int dy = -RADAR_R; dy <= RADAR_R; dy++) {
            int half = (int) Math.sqrt(RADAR_R * RADAR_R - dy * dy);
            g.fill(cx - half, cy + dy, cx + half, cy + dy + 1, 0x88101018);
        }
        // rim
        int rim = 0xFF000000 | Effects.grad(0.5f, time);
        for (int dy = -RADAR_R; dy <= RADAR_R; dy++) {
            int ho = (int) Math.sqrt(RADAR_R * RADAR_R - dy * dy);
            int hi = Math.abs(dy) >= RADAR_R - 1 ? 0 : (int) Math.sqrt((RADAR_R - 1) * (RADAR_R - 1) - dy * dy);
            if (hi <= 0) { g.fill(cx - ho, cy + dy, cx + ho, cy + dy + 1, rim); continue; }
            g.fill(cx - ho, cy + dy, cx - hi, cy + dy + 1, rim);
            g.fill(cx + hi, cy + dy, cx + ho, cy + dy + 1, rim);
        }
        // cross + inner ring marker
        g.fill(cx - RADAR_R + 2, cy, cx + RADAR_R - 1, cy + 1, 0x22FFFFFF);
        g.fill(cx, cy - RADAR_R + 2, cx + 1, cy + RADAR_R - 1, 0x22FFFFFF);
        // you
        g.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);

        double rad = Math.toRadians(mc.player.getYaw());
        double fx = -Math.sin(rad), fz = Math.cos(rad);       // forward on the XZ plane
        double rxv = -Math.cos(rad), rzv = -Math.sin(rad);    // right on the XZ plane
        float scale = (RADAR_R - 4) / range;

        for (Row r : rows) {
            double sx = (r.dx * rxv + r.dz * rzv) * scale;
            double sy = -(r.dx * fx + r.dz * fz) * scale;
            double len = Math.sqrt(sx * sx + sy * sy);
            double max = RADAR_R - 4;
            if (len > max) { sx = sx / len * max; sy = sy / len * max; }
            int px = cx + (int) Math.round(sx), py = cy + (int) Math.round(sy);
            int col = 0xFF000000 | Effects.lerpRgb(0xFF4040, 0x40FF80, MathHelper.clamp(r.hp / r.maxHp, 0f, 1f));
            g.fill(px - 2, py - 2, px + 3, py + 3, 0xCC000000);
            g.fill(px - 1, py - 1, px + 2, py + 2, col);
        }
        return cy + RADAR_R;
    }

    private static void drawList(DrawContext g, TextRenderer tr, List<Row> rows, boolean right, int sw, int y, float time) {
        int max = (int) Module.NEARBY.num("max");
        boolean showHp = Module.NEARBY.flag("health"), showDist = Module.NEARBY.flag("dist");

        String title = "Nearby (" + rows.size() + ")";
        int w = tr.getWidth(title) + 12;
        List<String> labels = new ArrayList<>();
        int n = Math.min(max, rows.size());
        for (int i = 0; i < n; i++) {
            Row r = rows.get(i);
            String s = r.name;
            if (showDist) s += "  " + String.format(Locale.ROOT, "%.0fm", r.dist);
            labels.add(s);
            w = Math.max(w, tr.getWidth(s) + 14 + (showHp ? 28 : 0));
        }
        w = Math.max(w, 96);
        int x = right ? sw - 6 - w : 6;

        g.fill(x, y, x + w, y + 14, 0x99101018);
        for (int i = 0; i < w; i += 8) g.fill(x + i, y, Math.min(x + i + 8, x + w), y + 1, 0xFF000000 | Effects.grad(i / 40f, time));
        g.drawText(tr, title, x + 6, y + 3, 0xFFFFFFFF, true);
        y += 15;

        for (int i = 0; i < n; i++) {
            Row r = rows.get(i);
            g.fill(x, y, x + w, y + 12, 0x77101018);
            float f = MathHelper.clamp(r.hp / r.maxHp, 0f, 1f);
            int col = 0xFF000000 | Effects.lerpRgb(0xFF4040, 0x40FF80, f);
            g.fill(x, y, x + 2, y + 12, col);
            g.drawText(tr, labels.get(i), x + 6, y + 2, 0xFFFFFFFF, true);
            if (showHp) {
                String hp = String.valueOf(Math.round(r.hp));
                g.drawText(tr, hp, x + w - 4 - tr.getWidth(hp), y + 2, col, true);
            }
            y += 13;
        }
        if (rows.size() > n) g.drawText(tr, "+" + (rows.size() - n) + " more", x + 6, y + 1, 0xFFB8B8C8, true);
    }
}
