package dev.pulsefx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Module {
    public static final List<Module> ALL = new ArrayList<>();

    public static final Module JUMP_CIRCLES = new Module("circles", "Jump Circles", "Visuals")
            .num("size", "Size", 0.5f, 2.5f, 0.1f, 1.0f)
            .num("life", "Duration (ms)", 400, 1800, 50, 900);
    public static final Module TRAIL = new Module("trail", "Trail", "Visuals")
            .num("length", "Length", 8, 60, 1, 28)
            .num("height", "Height", 0.3f, 2.0f, 0.1f, 0.9f);
    public static final Module HIT_FX = new Module("hit", "Hit FX", "Visuals")
            .num("count", "Particles", 0, 40, 1, 14)
            .bool("ring", "Ground ring", true);
    public static final Module TARGET_ESP = new Module("target", "Target ESP", "Visuals")
            .mode("style", "Style", "Bands", "Ring", "Both")
            .num("speed", "Speed", 0.3f, 3.0f, 0.1f, 1.0f);
    public static final Module HUD = new Module("hud", "HUD", "Visuals")
            .bool("coords", "Coordinates", true)
            .bool("list", "Module list", true);

    public static final Module NEARBY = new Module("nearby", "Nearby Players", "Visuals")
            .mode("style", "Style", "List", "Radar", "Both")
            .mode("side", "Side", "Right", "Left")
            .num("range", "Range (blocks)", 10, 256, 5, 64)
            .num("max", "Max players", 3, 15, 1, 8)
            .bool("health", "Health", true)
            .bool("dist", "Distance", true);

    public static final Module AURA = new Module("aura", "Glow Aura", "Atmosphere")
            .num("orbs", "Orbs", 0, 10, 1, 4)
            .num("radius", "Radius", 0.6f, 2.0f, 0.1f, 1.1f)
            .num("speed", "Speed", 0.3f, 3.0f, 0.1f, 1.0f)
            .bool("rings", "Halo rings", true)
            .bool("others", "Other players", false);
    public static final Module FIREFLIES = new Module("fireflies", "Fireflies", "Atmosphere")
            .num("count", "Amount", 10, 150, 5, 60)
            .num("size", "Size", 0.5f, 2.5f, 0.1f, 1.0f)
            .num("range", "Range (blocks)", 6, 24, 1, 14);
    public static final Module KILLFX = new Module("killfx", "Hit and Kill FX", "Atmosphere")
            .bool("sparks", "Hit sparks", true)
            .bool("burst", "Kill burst", true)
            .bool("wave", "Shockwave", true)
            .num("amount", "Intensity", 0.5f, 2.0f, 0.1f, 1.0f);
    public static final Module SCREENGLOW = new Module("screenglow", "Screen Glow", "Atmosphere")
            .num("intensity", "Intensity", 0.2f, 1.0f, 0.05f, 0.6f)
            .num("size", "Size", 0.08f, 0.3f, 0.01f, 0.16f)
            .bool("pulse", "Pulse", true)
            .bool("lowhp", "Low HP warning", true)
            .bool("hurt", "Hurt flash", true);
    public static final Module CROSSHAIR = new Module("crosshair", "Custom Crosshair", "Atmosphere")
            .mode("style", "Style", "Cross", "Dot", "Circle")
            .num("size", "Size", 2, 14, 1, 6)
            .num("gap", "Gap", 0, 10, 1, 3)
            .num("thick", "Thickness", 1, 3, 1, 1)
            .bool("dynamic", "Dynamic gap", true)
            .bool("glow", "Glow", true)
            .bool("hit", "Hit pulse", true)
            .bool("cooldown", "Attack cooldown bar", true);
    public static final Module FULLBRIGHT = new Module("fullbright", "Fullbright", "Atmosphere").off();
    public static final Module GLOW = new Module("glow", "Glow Boost", "Atmosphere")
            .bool("additive", "Additive blending", true)
            .num("strength", "Strength", 0.6f, 2.0f, 0.1f, 1.2f);
    public static final Module OPT = new Module("optimizer", "Optimizer", "Atmosphere")
            .mode("quality", "Quality", "Low", "Medium", "High")
            .bool("guard", "FPS guard", true)
            .num("fps", "Guard below FPS", 20, 120, 5, 45);

    public static final Module SWING = new Module("swing", "Swing Animation", "Animations")
            .mode("anim", "Animation", "Smooth", "Slash", "Spin", "Stab", "Chop", "Whip", "Flip", "Vanilla")
            .num("duration", "Duration (ticks)", 4, 20, 1, 10)
            .num("power", "Intensity", 0.5f, 1.5f, 0.05f, 1.0f);

    public static final Module VIEWMODEL = new Module("viewmodel", "View Model", "ViewModel")
            .num("x", "Position X", -1f, 1f, 0.02f, 0f)
            .num("y", "Position Y", -1f, 1f, 0.02f, 0f)
            .num("z", "Position Z", -1f, 1f, 0.02f, 0f)
            .num("rx", "Rotation X", -180, 180, 1, 0)
            .num("ry", "Rotation Y", -180, 180, 1, 0)
            .num("rz", "Rotation Z", -180, 180, 1, 0)
            .num("scale", "Scale", 0.3f, 1.5f, 0.05f, 1.0f);

    public final String id, label, category;
    public boolean on = true;
    public int bind = -1;
    boolean wasDown;
    public final List<Setting> settings = new ArrayList<>();
    private final Map<String, Setting> map = new HashMap<>();

    // GUI state
    public boolean expanded;
    public float anim = 1f, openAnim;

    private Module(String id, String label, String category) {
        this.id = id; this.label = label; this.category = category;
        ALL.add(this);
    }

    private Module off() { on = false; anim = 0f; return this; }
    private Module add(Setting s) { settings.add(s); map.put(s.id, s); return this; }
    private Module num(String id, String l, float min, float max, float step, float def) { return add(Setting.num(id, l, min, max, step, def)); }
    private Module bool(String id, String l, boolean def) { return add(Setting.bool(id, l, def)); }
    private Module mode(String id, String l, String... modes) { return add(Setting.mode(id, l, modes)); }

    public float num(String id) { return map.get(id).v; }
    public boolean flag(String id) { return map.get(id).b; }
    public int mode(String id) { return map.get(id).mode; }
}
