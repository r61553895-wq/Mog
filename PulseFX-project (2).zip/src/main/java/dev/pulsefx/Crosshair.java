package dev.pulsefx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Animated crosshair: dynamic gap, glow, hit pulse and attack cooldown bar. Replaces the vanilla one (see InGameHudMixin). */
public final class Crosshair {
    private Crosshair() {}

    private static float dyn, pulse;
    private static long lastNs;

    public static void hit() { pulse = 1f; }

    public static void render(DrawContext g, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Module.CROSSHAIR.on || mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;

        long ns = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : MathHelper.clamp((ns - lastNs) / 1.0e9f, 0f, 0.1f);
        lastNs = ns;
        float k = 1f - (float) Math.exp(-dt * 14f);

        Vec3d v = mc.player.getVelocity();
        float sp = (float) Math.sqrt(v.x * v.x + v.z * v.z);
        float target = Module.CROSSHAIR.flag("dynamic") ? Math.min(7f, sp * 22f + (mc.player.isOnGround() ? 0f : 3f)) : 0f;
        dyn += (target - dyn) * k;
        pulse = Math.max(0f, pulse - dt * 3.2f);

        float time = Effects.time();
        int accent = Effects.grad(0f, time);
        if (Module.CROSSHAIR.flag("hit") && pulse > 0f) accent = Effects.lerpRgb(accent, 0xFF4040, pulse);
        int col = 0xFF000000 | accent;
        boolean glow = Module.CROSSHAIR.flag("glow");

        int cx = g.getScaledWindowWidth() / 2, cy = g.getScaledWindowHeight() / 2;
        int size = (int) Module.CROSSHAIR.num("size"), th = (int) Module.CROSSHAIR.num("thick");
        int gap = Math.round(Module.CROSSHAIR.num("gap") + dyn + (Module.CROSSHAIR.flag("hit") ? pulse * 3f : 0f));
        int style = Module.CROSSHAIR.mode("style");
        int o = th / 2;

        if (style == 0) {
            bar(g, cx - gap - size, cy - o, cx - gap, cy - o + th, col, accent, glow);
            bar(g, cx + gap, cy - o, cx + gap + size, cy - o + th, col, accent, glow);
            bar(g, cx - o, cy - gap - size, cx - o + th, cy - gap, col, accent, glow);
            bar(g, cx - o, cy + gap, cx - o + th, cy + gap + size, col, accent, glow);
        } else if (style == 1) {
            int r = th + 1;
            bar(g, cx - r / 2, cy - r / 2, cx - r / 2 + r, cy - r / 2 + r, col, accent, glow);
        } else {
            int r = 4 + gap + size / 2;
            for (int i = 0; i < 28; i++) {
                double an = i * Math.PI * 2 / 28;
                int x = cx + (int) Math.round(Math.cos(an) * r), y = cy + (int) Math.round(Math.sin(an) * r);
                if (glow) g.fill(x - 1, y - 1, x + th + 1, y + th + 1, 0x30000000 | accent);
                g.fill(x, y, x + th, y + th, col);
            }
            bar(g, cx - 1, cy - 1, cx + 1, cy + 1, col, accent, glow);
        }

        if (Module.CROSSHAIR.flag("cooldown")) {
            float cd = mc.player.getAttackCooldownProgress(0f);
            if (cd < 1f) {
                int bw = 20, by = cy + gap + size + 6;
                g.fill(cx - bw / 2, by, cx + bw / 2, by + 2, 0x66000000);
                g.fill(cx - bw / 2, by, cx - bw / 2 + (int) (bw * cd), by + 2, col);
            }
        }
    }

    private static void bar(DrawContext g, int x1, int y1, int x2, int y2, int col, int accent, boolean glow) {
        if (glow) {
            g.fill(x1 - 2, y1 - 2, x2 + 2, y2 + 2, 0x20000000 | accent);
            g.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0x38000000 | accent);
        } else {
            g.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0x70000000);
        }
        g.fill(x1, y1, x2, y2, col);
    }
}
