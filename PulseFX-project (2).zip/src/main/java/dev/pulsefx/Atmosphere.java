package dev.pulsefx;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Glow based world effects: aura (halo rings + orbiting orbs), fireflies, hit/kill sparks, shockwave and beam.
 * Everything is additive, depth tested, drawn in ONE batch per frame, and uses preallocated arrays (no garbage per frame).
 */
public final class Atmosphere {
    private Atmosphere() {}

    // ---- particle pool (struct of arrays) ----
    private static final int MAXP = 480;
    private static final double[] px = new double[MAXP], py = new double[MAXP], pz = new double[MAXP];
    private static final float[] vx = new float[MAXP], vy = new float[MAXP], vz = new float[MAXP];
    private static final float[] age = new float[MAXP], life = new float[MAXP], psize = new float[MAXP], grav = new float[MAXP];
    private static final int[] pcol = new int[MAXP];
    private static int pc;

    // ---- fireflies ----
    private static final int MAXF = 150;
    private static final double[] fx = new double[MAXF], fy = new double[MAXF], fz = new double[MAXF];
    private static final float[] fph = new float[MAXF];

    private record Wave(double x, double y, double z, long start) {}
    private static final List<Wave> waves = new ArrayList<>();

    private static LivingEntity lastHit;
    private static long lastHitTime, lastNs;
    private static boolean fbApplied;

    private static final Vector3f R = new Vector3f(), U = new Vector3f();
    private static final float[] HC = {1f, 0.5f, -0.5f, -1f, -0.5f, 0.5f};
    private static final float[] HS = {0f, 0.866f, 0.866f, 0f, -0.866f, -0.866f};
    private static final float[] ex = new float[6], ey = new float[6], ez = new float[6];

    // ================= logic =================
    public static void onAttack(LivingEntity e) {
        lastHit = e;
        lastHitTime = System.currentTimeMillis();
        if (Module.KILLFX.on && Module.KILLFX.flag("sparks")) {
            int n = Math.round(9 * Module.KILLFX.num("amount") * Perf.mult());
            sparks(e.getX(), e.getBodyY(0.55), e.getZ(), n, 1.7f, 0.45f);
        }
    }

    private static void sparks(double x, double y, double z, int n, float speed, float lifeSec) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float time = Effects.time();
        for (int i = 0; i < n; i++) {
            double a = r.nextDouble() * MathHelper.TAU, cy = r.nextDouble() * 2 - 1, s = Math.sqrt(1 - cy * cy);
            float sp = speed * (0.5f + r.nextFloat());
            spawn(x, y, z, (float) (Math.cos(a) * s) * sp, (float) cy * sp + speed * 0.35f, (float) (Math.sin(a) * s) * sp,
                    lifeSec * (0.6f + r.nextFloat() * 0.8f), 0.04f + r.nextFloat() * 0.06f, Effects.grad(i * 0.7f, time), 6f);
        }
    }

    private static void spawn(double x, double y, double z, float ax, float ay, float az, float lf, float sz, int rgb, float g) {
        if (pc >= MAXP) return;
        int i = pc++;
        px[i] = x; py[i] = y; pz[i] = z; vx[i] = ax; vy[i] = ay; vz[i] = az;
        age[i] = 0f; life[i] = lf; psize[i] = sz; pcol[i] = rgb; grav[i] = g;
    }

    private static void killBurst(LivingEntity e) {
        if (!Module.KILLFX.on) return;
        float amt = Module.KILLFX.num("amount");
        if (Module.KILLFX.flag("burst")) {
            double y = e.getY() + e.getHeight() * 0.5;
            sparks(e.getX(), y, e.getZ(), Math.round(42 * amt * Perf.mult()), 4.2f, 0.9f);
            sparks(e.getX(), y, e.getZ(), Math.round(14 * amt * Perf.mult()), 1.6f, 1.4f);
        }
        if (Module.KILLFX.flag("wave")) {
            if (waves.size() < 6) waves.add(new Wave(e.getX(), e.getY(), e.getZ(), System.currentTimeMillis()));
        }
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { pc = 0; waves.clear(); lastHit = null; fbApplied = false; return; }

        if (lastHit != null) {
            if (System.currentTimeMillis() - lastHitTime > 4000) lastHit = null;
            else if (!lastHit.isAlive()) { killBurst(lastHit); lastHit = null; }
        }

        if (Module.FULLBRIGHT.on) {
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 300) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
            }
            fbApplied = true;
        } else if (fbApplied) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fbApplied = false;
        }
    }

    // ================= rendering =================
    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        MatrixStack ms = ctx.matrixStack();
        if (ms == null || mc.player == null || mc.world == null) return;

        long now = System.currentTimeMillis();
        waves.removeIf(w -> now - w.start > 900);
        boolean aura = Module.AURA.on, ff = Module.FIREFLIES.on;
        if (!aura && !ff && pc == 0 && waves.isEmpty()) { lastNs = 0; return; }

        long ns = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : MathHelper.clamp((ns - lastNs) / 1.0e9f, 0f, 0.1f);
        lastNs = ns;
        stepParticles(dt);

        Vec3d cam = ctx.camera().getPos();
        Matrix4f m = ms.peek().getPositionMatrix();
        float td = ctx.tickCounter().getTickDelta(false);
        float time = Effects.time();
        float secs = (now % 1000000L) / 1000f;
        Quaternionf q = ctx.camera().getRotation();
        R.set(1f, 0f, 0f).rotate(q);
        U.set(0f, 1f, 0f).rotate(q);

        RenderSystem.enableBlend();
        Perf.additive();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        if (ff) fireflies(b, m, cam, dt, secs, time);
        if (aura) {
            auraFor(b, m, cam, mc.player, td, secs, time, 1f);
            if (Module.AURA.flag("others")) {
                int c = 0;
                for (PlayerEntity pl : mc.world.getPlayers()) {
                    if (pl == mc.player || c >= 8 || pl.isInvisible()) continue;
                    if (mc.player.squaredDistanceTo(pl) > 32 * 32) continue;
                    auraFor(b, m, cam, pl, td, secs, time, 0.6f);
                    c++;
                }
            }
        }
        drawParticles(b, m, cam);
        drawWaves(b, m, cam, now, time);

        BuiltBuffer built = b.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);

        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void stepParticles(float dt) {
        float drag = Math.max(0f, 1f - 1.6f * dt);
        for (int i = 0; i < pc; ) {
            age[i] += dt;
            if (age[i] >= life[i]) {
                int l = --pc;
                if (i != l) {
                    px[i] = px[l]; py[i] = py[l]; pz[i] = pz[l]; vx[i] = vx[l]; vy[i] = vy[l]; vz[i] = vz[l];
                    age[i] = age[l]; life[i] = life[l]; psize[i] = psize[l]; pcol[i] = pcol[l]; grav[i] = grav[l];
                }
                continue;
            }
            vy[i] -= grav[i] * dt;
            vx[i] *= drag; vy[i] *= drag; vz[i] *= drag;
            px[i] += vx[i] * dt; py[i] += vy[i] * dt; pz[i] += vz[i] * dt;
            i++;
        }
    }

    private static void drawParticles(BufferBuilder b, Matrix4f m, Vec3d cam) {
        for (int i = 0; i < pc; i++) {
            float k = age[i] / life[i], f = 1f - k;
            float x = (float) (px[i] - cam.x), y = (float) (py[i] - cam.y), z = (float) (pz[i] - cam.z);
            int a = (int) (255 * f * f * 0.9f);
            float s = psize[i] * (1f - 0.5f * k);
            disc(b, m, x, y, z, s * 3.4f, pcol[i], (int) (a * 0.65f), 0);
            disc(b, m, x, y, z, s, Effects.lerpRgb(pcol[i], 0xFFFFFF, 0.6f), a, (int) (a * 0.5f));
        }
    }

    private static void drawWaves(BufferBuilder b, Matrix4f m, Vec3d cam, long now, float time) {
        for (Wave w : waves) {
            float k = (now - w.start) / 800f;
            if (k >= 1f) continue;
            float e = 1f - (1f - k) * (1f - k) * (1f - k), f = 1f - k;
            float cx = (float) (w.x - cam.x), cy = (float) (w.y - cam.y) + 0.05f, cz = (float) (w.z - cam.z);
            float r = 0.4f + 4.2f * e, wd = 0.45f * f + 0.08f;
            int a = (int) (f * 230f);
            ring(b, m, cx, cy, cz, r - wd, r, 0, a, time);
            ring(b, m, cx, cy, cz, r, r + wd * 0.4f, a, 0, time);
            if (k < 0.65f) {
                float bf = 1f - k / 0.65f, hw = 0.28f * bf + 0.04f, hh = 3.2f * (0.4f + 0.6f * bf);
                int ba = (int) (bf * 210f), col = Effects.grad(0.5f, time);
                b.vertex(m, cx - hw, cy, cz).color(argb(col, ba));
                b.vertex(m, cx + hw, cy, cz).color(argb(col, ba));
                b.vertex(m, cx + hw * 0.2f, cy + hh, cz).color(argb(col, 0));
                b.vertex(m, cx - hw * 0.2f, cy + hh, cz).color(argb(col, 0));
                b.vertex(m, cx, cy, cz - hw).color(argb(col, ba));
                b.vertex(m, cx, cy, cz + hw).color(argb(col, ba));
                b.vertex(m, cx, cy + hh, cz + hw * 0.2f).color(argb(col, 0));
                b.vertex(m, cx, cy + hh, cz - hw * 0.2f).color(argb(col, 0));
            }
        }
    }

    private static void fireflies(BufferBuilder b, Matrix4f m, Vec3d cam, float dt, float secs, float time) {
        int n = Math.min(MAXF, Math.round(Module.FIREFLIES.num("count") * Perf.mult()));
        float range = Module.FIREFLIES.num("range"), size = Module.FIREFLIES.num("size");
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < n; i++) {
            if (fph[i] == 0f) { fph[i] = 0.2f + r.nextFloat() * 0.8f; respawn(i, cam, range, r); }
            float ph = fph[i];
            fx[i] += Math.sin(secs * 0.7 + ph * 31.0) * 0.25 * dt;
            fy[i] += Math.sin(secs * 0.9 + ph * 53.0) * 0.18 * dt + 0.03 * dt;
            fz[i] += Math.cos(secs * 0.6 + ph * 23.0) * 0.25 * dt;
            double dx = fx[i] - cam.x, dy = fy[i] - cam.y, dz = fz[i] - cam.z;
            double d2 = dx * dx + dy * dy + dz * dz;
            if (d2 > range * range) { respawn(i, cam, range, r); continue; }
            float d = (float) Math.sqrt(d2);
            float tw = 0.5f + 0.5f * MathHelper.sin(secs * (1.2f + ph * 1.5f) + ph * 9f);
            tw *= tw;
            float edge = MathHelper.clamp((range - d) / (range * 0.3f), 0f, 1f) * MathHelper.clamp((d - 0.8f) / 1.5f, 0f, 1f);
            int a = (int) ((40 + 190 * tw) * edge);
            if (a < 3) continue;
            int col = Effects.grad(ph * 6f, time);
            float x = (float) dx, y = (float) dy, z = (float) dz;
            disc(b, m, x, y, z, 0.20f * size, col, (int) (a * 0.6f), 0);
            disc(b, m, x, y, z, 0.05f * size, 0xFFFFFF, a, (int) (a * 0.4f));
        }
    }

    private static void respawn(int i, Vec3d cam, float range, ThreadLocalRandom r) {
        fx[i] = cam.x + (r.nextDouble() * 2 - 1) * range;
        fy[i] = cam.y + (r.nextDouble() * 2 - 1) * range * 0.6;
        fz[i] = cam.z + (r.nextDouble() * 2 - 1) * range;
    }

    private static void auraFor(BufferBuilder b, Matrix4f m, Vec3d cam, PlayerEntity e, float td, float secs, float time, float scale) {
        Vec3d p = e.getLerpedPos(td);
        float cx = (float) (p.x - cam.x), cy = (float) (p.y - cam.y), cz = (float) (p.z - cam.z);
        float h = e.getHeight();
        float radius = Module.AURA.num("radius"), speed = Module.AURA.num("speed");

        if (Module.AURA.flag("rings")) {
            float pulse = 0.5f + 0.5f * MathHelper.sin(secs * 1.6f * speed);
            float r0 = radius * 0.72f;
            ring(b, m, cx, cy + 0.04f, cz, r0 - 0.02f, r0 + 0.10f + 0.05f * pulse, 0, (int) (200 * scale), time);
            ring(b, m, cx, cy + 0.04f, cz, r0 + 0.10f + 0.05f * pulse, r0 + 0.32f + 0.08f * pulse, (int) (200 * scale), 0, time + 1.3f);
            ring(b, m, cx, cy + h + 0.12f, cz, radius * 0.38f, radius * 0.46f, (int) (150 * scale), 0, time + 2.6f);
            float rise = (secs * 0.5f * speed) % 1f;
            ring(b, m, cx, cy + h * rise, cz, radius * 0.68f, radius * 0.76f, 0, (int) (120 * (1f - rise) * scale), time + 0.7f);
        }

        int n = Math.round(Module.AURA.num("orbs") * (scale < 1f ? 0.6f : 1f) * Math.max(0.5f, Perf.mult()));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 5; j++) {
                float tt = secs - j * 0.045f;
                float ang = tt * 1.9f * speed + i * MathHelper.TAU / n;
                float oy = cy + h * 0.5f + MathHelper.sin(tt * 1.3f * speed + i * 1.7f) * h * 0.38f;
                float ox = cx + MathHelper.cos(ang) * radius, oz = cz + MathHelper.sin(ang) * radius;
                float d = (float) Math.sqrt(ox * ox + oy * oy + oz * oz);
                float fade = MathHelper.clamp((d - 0.35f) / 0.8f, 0f, 1f);
                float fj = 1f - j * 0.2f;
                int a = (int) (235 * fj * fj * fade * scale);
                if (a < 3) continue;
                int col = Effects.grad(i * 1.1f, time);
                if (j == 0) {
                    disc(b, m, ox, oy, oz, 0.34f, col, (int) (a * 0.55f), 0);
                    disc(b, m, ox, oy, oz, 0.07f, 0xFFFFFF, a, (int) (a * 0.5f));
                } else {
                    disc(b, m, ox, oy, oz, 0.16f * fj, col, (int) (a * 0.5f), 0);
                }
            }
        }
    }

    /** Camera facing hexagon glow: bright at the center, transparent at the rim. */
    private static void disc(BufferBuilder b, Matrix4f m, float x, float y, float z, float size, int rgb, int aCenter, int aEdge) {
        for (int k = 0; k < 6; k++) {
            ex[k] = x + (R.x * HC[k] + U.x * HS[k]) * size;
            ey[k] = y + (R.y * HC[k] + U.y * HS[k]) * size;
            ez[k] = z + (R.z * HC[k] + U.z * HS[k]) * size;
        }
        int cc = argb(rgb, aCenter), ce = argb(rgb, aEdge);
        for (int q = 0; q < 6; q += 2) {
            int i1 = q + 1, i2 = (q + 2) % 6;
            b.vertex(m, x, y, z).color(cc);
            b.vertex(m, ex[q], ey[q], ez[q]).color(ce);
            b.vertex(m, ex[i1], ey[i1], ez[i1]).color(ce);
            b.vertex(m, ex[i2], ey[i2], ez[i2]).color(ce);
        }
    }

    private static void ring(BufferBuilder b, Matrix4f m, float cx, float cy, float cz,
                             float r0, float r1, int a0, int a1, float time) {
        final int SEG = Perf.seg();
        for (int i = 0; i < SEG; i++) {
            float t0 = i * MathHelper.TAU / SEG, t1 = (i + 1) * MathHelper.TAU / SEG;
            float s0 = MathHelper.sin(t0), k0 = MathHelper.cos(t0), s1 = MathHelper.sin(t1), k1 = MathHelper.cos(t1);
            int c0 = Effects.grad(t0, time), c1 = Effects.grad(t1, time);
            b.vertex(m, cx + k0 * r0, cy, cz + s0 * r0).color(argb(c0, a0));
            b.vertex(m, cx + k0 * r1, cy, cz + s0 * r1).color(argb(c0, a1));
            b.vertex(m, cx + k1 * r1, cy, cz + s1 * r1).color(argb(c1, a1));
            b.vertex(m, cx + k1 * r0, cy, cz + s1 * r0).color(argb(c1, a0));
        }
    }

    private static int argb(int rgb, int a) {
        return (MathHelper.clamp((int) (a * Perf.strength()), 0, 255) << 24) | (rgb & 0xFFFFFF);
    }
}
