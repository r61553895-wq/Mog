package dev.pulsefx;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/**
 * Light "frosted glass" menu. Layout is built in a fixed virtual resolution (900x540) and scaled to fit the window,
 * so it looks the same on a PC monitor and on a phone with a huge GUI scale.
 * The blur behind the panel is vanilla's menu background blur (Video Settings -> Menu Background Blur).
 */
public class MenuScreen extends Screen {
    private static final int VW = 900, VH = 540, SIDE = 210;
    private static final String[] TABS = {"Visuals", "Atmosphere", "Animations", "ViewModel", "Theme"};
    private static final String[] TAB_SUB = {"Effects and HUD", "Glow and ambience", "Swing animations", "Hand position", "Accent colors"};
    private static final int[][] PRESETS = {
            {0x9B5CFF, 0x35E6FF}, {0xFF3D3D, 0xFFC13D}, {0x2F6BFF, 0x2FFFD0},
            {0x3DFFA2, 0xD0FF3D}, {0xFF5CA8, 0xFFC2E0}
    };
    private static final int[] CH = {0xFFE5584F, 0xFF3DBE6C, 0xFF4C7DF0};
    private static final int TEXT = 0xFF1B2130, TEXT2 = 0xFF4A5264, MUTED = 0xFF7A8294;
    private static final int AX0 = SIDE + 22, AX1 = VW - 28, AY0 = 92, AY1 = VH - 22;

    private static final int[][] INS = new int[40][];

    private static final class Hit {
        int x, y, w, h, bx, bw;
        boolean scrolled;
        IntConsumer click;
        DoubleConsumer drag;
    }

    private final List<Hit> hits = new ArrayList<>();
    private final int[] grainX = new int[170], grainY = new int[170];
    private int tab;
    private float scroll, scrollTarget, contentH;
    private Module listening;
    private DoubleConsumer dragFn;
    private int dragX, dragW;

    // frame state
    private float sc = 1f, ox, oy, fade, openT, k = 1f, pillY = -1f, t;
    private long lastNs;
    private int mx, my; // mouse in virtual coordinates

    public MenuScreen() {
        super(Text.literal("PulseFX"));
        Random r = new Random(7);
        for (int i = 0; i < grainX.length; i++) { grainX[i] = 10 + r.nextInt(VW - 20); grainY[i] = 10 + r.nextInt(VH - 20); }
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void renderBackground(DrawContext g, int a, int b, float d) {
        super.renderBackground(g, a, b, d); // vanilla blur + dim
        g.fill(0, 0, width, height, 0x30FFFFFF);
    }

    // ================= drawing primitives (all go through the fade-in) =================
    private int fc(int col) {
        int a = (int) (((col >>> 24) & 255) * fade);
        return (a << 24) | (col & 0xFFFFFF);
    }

    private void fill(DrawContext g, int x1, int y1, int x2, int y2, int col) {
        if (x2 <= x1 || y2 <= y1) return;
        int c = fc(col);
        if ((c >>> 24) == 0) return;
        g.fill(x1, y1, x2, y2, c);
    }

    private static int[] insets(int r) {
        r = Math.max(0, Math.min(r, INS.length - 1));
        if (INS[r] == null) {
            int[] a = new int[r];
            for (int d = 0; d < r; d++) {
                double dy = r - d - 0.5;
                a[d] = r - (int) Math.round(Math.sqrt(r * (double) r - dy * dy));
            }
            INS[r] = a;
        }
        return INS[r];
    }

    /** Filled rounded rectangle, built from non-overlapping strips so translucent colors stay correct. */
    private void rr(DrawContext g, int x, int y, int w, int h, int r, int col) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) { fill(g, x, y, x + w, y + h, col); return; }
        int[] ins = insets(r);
        int s = 0;
        while (s < r) {
            int e = s;
            while (e + 1 < r && ins[e + 1] == ins[s]) e++;
            fill(g, x + ins[s], y + s, x + w - ins[s], y + e + 1, col);
            fill(g, x + ins[s], y + h - e - 1, x + w - ins[s], y + h - s, col);
            s = e + 1;
        }
        fill(g, x, y + r, x + w, y + h - r, col);
    }

    /** 1px rounded outline. */
    private void ring(DrawContext g, int x, int y, int w, int h, int r, int col) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) {
            fill(g, x, y, x + w, y + 1, col); fill(g, x, y + h - 1, x + w, y + h, col);
            fill(g, x, y + 1, x + 1, y + h - 1, col); fill(g, x + w - 1, y + 1, x + w, y + h - 1, col);
            return;
        }
        int[] ins = insets(r);
        for (int d = 0; d < r; d++) {
            int a = ins[d];
            if (d == 0) {
                fill(g, x + a, y, x + w - a, y + 1, col);
                fill(g, x + a, y + h - 1, x + w - a, y + h, col);
            } else {
                int b = Math.max(a + 1, ins[d - 1]);
                fill(g, x + a, y + d, x + b, y + d + 1, col);
                fill(g, x + w - b, y + d, x + w - a, y + d + 1, col);
                fill(g, x + a, y + h - 1 - d, x + b, y + h - d, col);
                fill(g, x + w - b, y + h - 1 - d, x + w - a, y + h - d, col);
            }
        }
        fill(g, x, y + r, x + 1, y + h - r, col);
        fill(g, x + w - 1, y + r, x + w, y + h - r, col);
    }

    private void circle(DrawContext g, int cx, int cy, int r, int col) { rr(g, cx - r, cy - r, r * 2, r * 2, r, col); }

    private int tw(String s, float scale) { return (int) Math.ceil(textRenderer.getWidth(s) * scale); }

    private void text(DrawContext g, String s, int x, int y, float scale, int col) {
        int c = fc(col);
        if ((c >>> 24) < 8) return; // vanilla treats near-zero alpha text as opaque
        if (scale == 1f) { g.drawText(textRenderer, s, x, y, c, false); return; }
        MatrixStack ms = g.getMatrices();
        ms.push();
        ms.translate(x, y, 0f);
        ms.scale(scale, scale, 1f);
        g.drawText(textRenderer, s, 0, 0, c, false);
        ms.pop();
    }
    private void ctext(DrawContext g, String s, int cx, int y, float scale, int col) { text(g, s, cx - tw(s, scale) / 2, y, scale, col); }
    private void rtext(DrawContext g, String s, int rx, int y, float scale, int col) { text(g, s, rx - tw(s, scale), y, scale, col); }

    /** Scissor in real GUI coordinates (DrawContext ignores the matrix stack for scissors), so leave the scaled layer first. */
    private void clip(DrawContext g, int x1, int y1, int x2, int y2) {
        MatrixStack ms = g.getMatrices();
        ms.pop();
        g.enableScissor((int) Math.floor(ox + x1 * sc), (int) Math.floor(oy + y1 * sc),
                (int) Math.ceil(ox + x2 * sc), (int) Math.ceil(oy + y2 * sc));
        ms.push();
        ms.translate(ox, oy, 0f);
        ms.scale(sc, sc, 1f);
    }
    private void unclip(DrawContext g) {
        MatrixStack ms = g.getMatrices();
        ms.pop();
        g.disableScissor();
        ms.push();
        ms.translate(ox, oy, 0f);
        ms.scale(sc, sc, 1f);
    }

    private int acc(float seed) { return 0xFF000000 | Effects.grad(seed, t); }

    private static boolean in(double px, double py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }
    private static String keyName(int key) {
        if (key < 0) return "NONE";
        String s = InputUtil.fromKeyCode(key, 0).getLocalizedText().getString().toUpperCase();
        return s.length() > 8 ? s.substring(0, 8) : s;
    }
    private static int ch(int rgb, int k) { return (rgb >> (16 - 8 * k)) & 255; }
    private static int setCh(int rgb, int k, int v) { int sh = 16 - 8 * k; return (rgb & ~(255 << sh)) | (v << sh); }

    private void hit(int x, int y, int w, int h, boolean scrolled, IntConsumer click) {
        Hit h0 = new Hit(); h0.x = x; h0.y = y; h0.w = w; h0.h = h; h0.scrolled = scrolled; h0.click = click; hits.add(h0);
    }
    private void hitDrag(int x, int y, int w, int h, boolean scrolled, int bx, int bw, DoubleConsumer drag) {
        Hit h0 = new Hit(); h0.x = x; h0.y = y; h0.w = w; h0.h = h; h0.scrolled = scrolled; h0.bx = bx; h0.bw = bw; h0.drag = drag; hits.add(h0);
    }

    private void drawSwitch(DrawContext g, int x, int y, int w, int h, float a, float seed) {
        int track = 0xFF000000 | Effects.lerpRgb(0xCDD3DF, acc(seed) & 0xFFFFFF, a);
        rr(g, x, y, w, h, h / 2, track);
        int r = (h - 4) / 2;
        int cx = x + h / 2 + (int) ((w - h) * a), cy = y + h / 2;
        circle(g, cx, cy + 1, r + 1, 0x30000000);
        circle(g, cx, cy, r, 0xFFFFFFFF);
    }

    private void drawSlider(DrawContext g, int x, int y, int w, float norm, int fillCol) {
        norm = MathHelper.clamp(norm, 0f, 1f);
        rr(g, x, y - 2, w, 5, 2, 0xFFD9DEE8);
        int fw = (int) (w * norm);
        if (fw > 0) rr(g, x, y - 2, Math.max(fw, 5), 5, 2, fillCol);
        int kx = x + fw;
        circle(g, kx, y + 1, 9, 0x26000000);
        circle(g, kx, y, 8, 0xFFFFFFFF);
        circle(g, kx, y, 3, fillCol);
    }

    // ================= frame =================
    @Override
    public void render(DrawContext g, int rawX, int rawY, float delta) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : MathHelper.clamp((now - lastNs) / 1.0e9f, 0f, 0.1f);
        lastNs = now;
        k = 1f - (float) Math.exp(-dt * 16f);
        openT = Math.min(1f, openT + dt / 0.22f);
        float inv = 1f - openT;
        fade = 1f - inv * inv * inv;

        super.render(g, rawX, rawY, delta); // background (blur) is drawn here
        hits.clear();
        t = Effects.time();

        float fit = Math.min((width - 16f) / VW, (height - 16f) / VH);
        sc = Math.max(0.25f, Math.min(1.5f, fit)) * (0.95f + 0.05f * fade);
        ox = (width - VW * sc) / 2f;
        oy = (height - VH * sc) / 2f;
        mx = (int) Math.floor((rawX - ox) / sc);
        my = (int) Math.floor((rawY - oy) / sc);

        MatrixStack ms = g.getMatrices();
        ms.push();
        ms.translate(ox, oy, 0f);
        ms.scale(sc, sc, 1f);

        drawFrame(g);
        drawSidebar(g);
        drawHeader(g);
        if (tab == TABS.length - 1) renderTheme(g); else renderModules(g);

        ms.pop();
    }

    private void drawFrame(DrawContext g) {
        for (int i = 3; i >= 1; i--) ring(g, -i, -i, VW + 2 * i, VH + 2 * i, 16 + i, ((0x1C - i * 7) << 24) | 0x1A2438);
        rr(g, 0, 0, VW, VH, 16, 0xC8F3F6FB);                       // glass body
        if (fade > 0.01f) g.fillGradient(16, 1, VW - 16, 110, fc(0x60FFFFFF), fc(0x00FFFFFF)); // top light
        for (int i = 0; i < grainX.length; i++) fill(g, grainX[i], grainY[i], grainX[i] + 1, grainY[i] + 1, (i & 1) == 0 ? 0x14203050 : 0x50FFFFFF); // matte grain
        ring(g, 0, 0, VW, VH, 16, 0xD8FFFFFF);
        ring(g, 1, 1, VW - 2, VH - 2, 15, 0x30FFFFFF);
    }

    private void drawSidebar(DrawContext g) {
        rr(g, 12, 12, SIDE - 12, VH - 24, 12, 0x60FFFFFF);
        ring(g, 12, 12, SIDE - 12, VH - 24, 12, 0x90FFFFFF);

        int lx = 32;
        for (char c : "PulseFX".toCharArray()) {
            String s = String.valueOf(c);
            text(g, s, lx, 30, 2f, acc(lx / 14f));
            lx += tw(s, 2f);
        }
        text(g, "visual client", 33, 52, 0.9f, MUTED);
        fill(g, 30, 74, SIDE - 18, 75, 0x1E203050);

        int tx = 24, tw0 = SIDE - 36, th = 42;
        float target = 90 + tab * (th + 6);
        if (pillY < 0) pillY = target;
        pillY += (target - pillY) * k;
        int py = Math.round(pillY);
        rr(g, tx, py, tw0, th, 11, (0x34 << 24) | (acc(0.3f) & 0xFFFFFF));
        rr(g, tx + 8, py + 11, 4, th - 22, 2, acc(0.8f));

        for (int i = 0; i < TABS.length; i++) {
            int ty = 90 + i * (th + 6);
            boolean sel = i == tab, hov = in(mx, my, tx, ty, tw0, th);
            if (hov && !sel) rr(g, tx, ty, tw0, th, 11, 0x40FFFFFF);
            text(g, TABS[i], tx + 22, ty + 9, 1.15f, sel ? TEXT : TEXT2);
            text(g, TAB_SUB[i], tx + 22, ty + 25, 0.8f, MUTED);
            final int idx = i;
            hit(tx, ty, tw0, th, false, b -> { tab = idx; scrollTarget = 0; scroll = 0; });
        }
        text(g, "RShift to close", 32, VH - 40, 0.9f, MUTED);
    }

    private void drawHeader(DrawContext g) {
        text(g, TABS[tab], AX0, 28, 2f, TEXT);
        text(g, TAB_SUB[tab], AX0 + 1, 52, 0.95f, MUTED);
        String hint = tab == TABS.length - 1 ? "Colors apply everywhere" : "Click: toggle    Right click: settings";
        rtext(g, hint, AX1, 36, 0.9f, MUTED);
        fill(g, AX0, 76, AX1, 77, 0x1E203050);
    }

    // ================= modules =================
    private void renderModules(DrawContext g) {
        int cw = AX1 - AX0;
        float maxScroll = Math.max(0, contentH - (AY1 - AY0));
        scrollTarget = MathHelper.clamp(scrollTarget, 0, maxScroll);
        scroll += (scrollTarget - scroll) * k;
        int y = AY0 - Math.round(scroll);

        clip(g, AX0 - 8, AY0, AX1 + 8, AY1);
        for (Module m : Module.ALL) {
            if (!m.category.equals(TABS[tab])) continue;
            int sh = m.settings.isEmpty() ? 0 : m.settings.size() * 34 + 14;
            m.openAnim += ((m.expanded ? 1f : 0f) - m.openAnim) * k;
            m.anim += ((m.on ? 1f : 0f) - m.anim) * k;
            int h = 58 + Math.round(sh * m.openAnim);
            boolean hov = in(mx, my, AX0, y, cw, 58) && my >= AY0 && my < AY1;

            rr(g, AX0, y, cw, h, 12, hov ? 0xDCFFFFFF : 0xB8FFFFFF);
            if (m.anim > 0.02f) rr(g, AX0 + 10, y + 15, 4, 28, 2, (((int) (255 * m.anim)) << 24) | (acc(y / 40f) & 0xFFFFFF));
            text(g, m.label, AX0 + 26, y + 13, 1.2f, TEXT);
            text(g, m.on ? "Enabled" : "Disabled", AX0 + 26, y + 33, 0.85f, m.on ? acc(y / 40f) : MUTED);

            int arrowX = AX0 + 26 + tw(m.label, 1.2f) + 10;
            if (!m.settings.isEmpty()) text(g, m.expanded ? "v" : ">", arrowX, y + 15, 1.1f, MUTED);

            int swx = AX1 - 18 - 46, bx = swx - 16 - 86;
            drawSwitch(g, swx, y + 17, 46, 24, m.anim, y / 40f);
            rr(g, bx, y + 16, 86, 26, 8, listening == m ? (0x40 << 24) | (acc(0.5f) & 0xFFFFFF) : 0xFFE8ECF4);
            ctext(g, listening == m ? "..." : keyName(m.bind), bx + 43, y + 24, 0.95f, listening == m ? TEXT : TEXT2);

            hit(AX0, y, bx - 8 - AX0, 58, true, b -> {
                if (b == 1 && !m.settings.isEmpty()) m.expanded = !m.expanded;
                else if (b == 0) { m.on = !m.on; Config.save(); }
            });
            if (!m.settings.isEmpty()) hit(arrowX - 4, y + 8, 22, 26, true, b -> m.expanded = !m.expanded);
            hit(bx, y + 14, 86, 30, true, b -> listening = listening == m ? null : m);
            hit(swx - 4, y + 13, 54, 32, true, b -> { m.on = !m.on; Config.save(); });

            if (sh > 0 && m.openAnim > 0.05f) {
                clip(g, AX0, y + 58, AX0 + cw, y + h);
                fill(g, AX0 + 16, y + 58, AX0 + cw - 16, y + 59, 0x1E203050);
                int sy = y + 66;
                for (Setting s : m.settings) {
                    drawSetting(g, s, sy, cw, m.openAnim > 0.9f);
                    sy += 34;
                }
                unclip(g);
            }
            y += h + 10;
        }
        unclip(g);
        contentH = y + Math.round(scroll) - AY0;

        if (maxScroll > 0) {
            int trackH = AY1 - AY0;
            int thumbH = Math.max(30, (int) (trackH * (trackH / contentH)));
            int thumbY = AY0 + (int) ((trackH - thumbH) * (scroll / maxScroll));
            rr(g, VW - 16, thumbY, 4, thumbH, 2, 0x55203050);
        }
    }

    private void drawSetting(DrawContext g, Setting s, int y, int cw, boolean active) {
        text(g, s.label, AX0 + 26, y + 9, 1f, TEXT2);
        int rx = AX0 + cw - 22;
        switch (s.type) {
            case BOOL -> {
                s.anim += ((s.b ? 1f : 0f) - s.anim) * k;
                drawSwitch(g, rx - 40, y + 4, 40, 22, s.anim, y / 40f);
                if (active) hit(rx - 44, y, 48, 30, true, b -> { s.b = !s.b; Config.save(); });
            }
            case NUM -> {
                int bw = 230, bx = rx - 58 - bw;
                float f = (s.v - s.min) / (s.max - s.min);
                drawSlider(g, bx, y + 14, bw, f, acc(y / 40f));
                rtext(g, s.display(), rx, y + 9, 1f, TEXT);
                if (active) hitDrag(bx - 10, y, bw + 20, 30, true, bx, bw, n -> s.setNorm(n));
            }
            case MODE -> {
                int bw = 200, bx = rx - bw;
                rr(g, bx, y + 2, bw, 26, 8, 0xFFE8ECF4);
                ctext(g, s.modes[s.mode], bx + bw / 2, y + 10, 1f, TEXT);
                text(g, "<", bx + 12, y + 10, 1f, MUTED);
                rtext(g, ">", bx + bw - 12, y + 10, 1f, MUTED);
                if (active) hit(bx, y, bw, 30, true, b -> {
                    int n = s.modes.length;
                    int dir = (b == 1 || mx < bx + bw / 2) ? -1 : 1;
                    s.mode = (s.mode + dir + n) % n;
                    Config.save();
                });
            }
        }
    }

    // ================= theme =================
    private void renderTheme(DrawContext g) {
        int cw = AX1 - AX0;
        rr(g, AX0, AY0, cw, VH - 22 - AY0, 12, 0xB8FFFFFF);

        text(g, "Presets", AX0 + 20, AY0 + 16, 1.1f, TEXT);
        int sw = 94, gap = (cw - 40 - sw * 6) / 5;
        for (int i = 0; i < 6; i++) {
            int x = AX0 + 20 + i * (sw + gap), y = AY0 + 40;
            for (int s = 0; s < sw; s += 2) {
                float f = s / (float) sw;
                int col = i < 5 ? Effects.lerpRgb(PRESETS[i][0], PRESETS[i][1], f) : MathHelper.hsvToRgb(f, 0.65f, 1f);
                fill(g, x + s, y, x + s + 2, y + 44, 0xFF000000 | col);
            }
            boolean sel = i < 5 ? (!Config.rainbow && Config.c1 == PRESETS[i][0] && Config.c2 == PRESETS[i][1]) : Config.rainbow;
            if (sel) { ring(g, x - 2, y - 2, sw + 4, 48, 0, 0xFF1B2130); ring(g, x - 3, y - 3, sw + 6, 50, 0, 0xFFFFFFFF); }
            else if (in(mx, my, x, y, sw, 44)) ring(g, x - 1, y - 1, sw + 2, 46, 0, 0xAA1B2130);
            final int idx = i;
            hit(x, y, sw, 44, false, b -> {
                if (idx < 5) { Config.c1 = PRESETS[idx][0]; Config.c2 = PRESETS[idx][1]; Config.rainbow = false; }
                else Config.rainbow = true;
                Config.save();
            });
        }

        int colW = (cw - 40 - 32) / 3;
        String[] names = {"R", "G", "B"};
        for (int row = 0; row < 2; row++) {
            int ly = AY0 + 116 + row * 84;
            text(g, row == 0 ? "Color 1" : "Color 2", AX0 + 20, ly, 1.1f, TEXT);
            int rgb = row == 0 ? Config.c1 : Config.c2;
            rr(g, AX0 + cw - 20 - 60, ly - 3, 60, 18, 6, 0xFF000000 | rgb);
            for (int c = 0; c < 3; c++) {
                int x = AX0 + 20 + c * (colW + 16), y = ly + 36;
                int v = ch(row == 0 ? Config.c1 : Config.c2, c);
                text(g, names[c], x, y - 18, 0.95f, MUTED);
                rtext(g, String.valueOf(v), x + colW, y - 18, 0.95f, TEXT);
                drawSlider(g, x, y, colW, v / 255f, CH[c]);
                final int fr = row, fk = c;
                hitDrag(x - 10, y - 12, colW + 20, 26, false, x, colW, n -> {
                    int val = (int) Math.round(n * 255);
                    if (fr == 0) Config.c1 = setCh(Config.c1, fk, val); else Config.c2 = setCh(Config.c2, fk, val);
                    Config.rainbow = false;
                });
            }
        }

        int py = AY0 + 292;
        text(g, "Preview", AX0 + 20, py, 1.1f, TEXT);
        int pw = cw - 40;
        for (int s = 0; s < pw; s += 4) {
            float f = s / (float) pw;
            int col = Config.rainbow ? MathHelper.hsvToRgb(f, 0.65f, 1f) : Effects.lerpRgb(Config.c1, Config.c2, f);
            fill(g, AX0 + 20 + s, py + 22, AX0 + 20 + Math.min(s + 4, pw), py + 42, 0xFF000000 | col);
        }
    }

    // ================= input =================
    private double vx(double rawX) { return (rawX - ox) / sc; }
    private double vy(double rawY) { return (rawY - oy) / sc; }

    @Override
    public boolean mouseClicked(double rawX, double rawY, int button) {
        double px = vx(rawX), py = vy(rawY);
        mx = (int) Math.floor(px); my = (int) Math.floor(py);
        if (listening != null) { listening = null; return true; }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!in(px, py, h.x, h.y, h.w, h.h)) continue;
            if (h.scrolled && (py < AY0 || py >= AY1)) continue;
            if (h.drag != null) {
                if (button == 0) {
                    dragFn = h.drag; dragX = h.bx; dragW = h.bw;
                    dragFn.accept(MathHelper.clamp((px - dragX) / dragW, 0.0, 1.0));
                }
                return true;
            }
            h.click.accept(button);
            return true;
        }
        return super.mouseClicked(rawX, rawY, button);
    }

    @Override
    public boolean mouseDragged(double rawX, double rawY, int button, double dx, double dy) {
        if (dragFn != null) { dragFn.accept(MathHelper.clamp((vx(rawX) - dragX) / dragW, 0.0, 1.0)); return true; }
        return super.mouseDragged(rawX, rawY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double rawX, double rawY, int button) {
        if (dragFn != null) { dragFn = null; Config.save(); return true; }
        return super.mouseReleased(rawX, rawY, button);
    }

    @Override
    public boolean mouseScrolled(double rawX, double rawY, double hAmount, double vAmount) {
        if (tab == TABS.length - 1) return true;
        float max = Math.max(0, contentH - (AY1 - AY0));
        scrollTarget = MathHelper.clamp(scrollTarget - (float) vAmount * 54f, 0, max);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) listening.bind = -1;
            else if (keyCode != GLFW.GLFW_KEY_ESCAPE) listening.bind = keyCode;
            listening = null;
            Config.save();
            return true;
        }
        if (PulseFX.menuKey.matchesKey(keyCode, scanCode)) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() { Config.save(); }
}
