package dev.pulsefx;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;

/** Quality level shared by all effects, with an automatic FPS guard that lowers it when the game gets slow. */
public final class Perf {
    private Perf() {}

    private static int level = 2, drop, counter;

    public static void tick(MinecraftClient mc) {
        int base = Module.OPT.on ? Module.OPT.mode("quality") : 2;
        if (Module.OPT.on && Module.OPT.flag("guard")) {
            if (++counter % 10 == 0) {
                int fps = mc.getCurrentFps();
                float lim = Module.OPT.num("fps");
                if (fps < lim * 0.55f) drop = 2;
                else if (fps < lim) drop = 1;
                else if (fps > lim * 1.25f) drop = 0;
            }
        } else drop = 0;
        level = Math.max(0, base - drop);
    }

    /** Ring segments. */
    public static int seg() { return level == 0 ? 16 : level == 1 ? 28 : 44; }

    /** Multiplier for particle counts. */
    public static float mult() { return level == 0 ? 0.35f : level == 1 ? 0.7f : 1f; }

    public static float strength() { return Module.GLOW.on ? Module.GLOW.num("strength") : 1f; }

    public static void additive() { RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE); }

    /** Blend mode for the classic effects: additive (glow) when Glow Boost is on. */
    public static void blend() {
        if (Module.GLOW.on && Module.GLOW.flag("additive")) additive();
        else RenderSystem.defaultBlendFunc();
    }
}
