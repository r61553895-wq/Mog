package dev.pulsefx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;

/** Glowing screen edges: animated accent color, low HP warning and hurt flash. A few draw calls only. */
public final class ScreenFx {
    private ScreenFx() {}

    public static void render(DrawContext g, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Module.SCREENGLOW.on || mc.player == null || mc.options.hudHidden || mc.currentScreen instanceof MenuScreen) return;

        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();
        float time = Effects.time();
        float a = Module.SCREENGLOW.num("intensity");
        if (Module.SCREENGLOW.flag("pulse")) a *= 0.82f + 0.18f * MathHelper.sin(time * 2f);
        int th = Math.max(10, (int) (Math.min(w, h) * Module.SCREENGLOW.num("size")));

        int cTop = Effects.grad(0f, time), cBot = Effects.grad(2.5f, time);
        int cL = Effects.grad(1.2f, time), cR = Effects.grad(3.7f, time);

        float low = 0f;
        if (Module.SCREENGLOW.flag("lowhp")) {
            float hp = mc.player.getHealth();
            if (hp <= 6f && hp > 0f) low = 1f - hp / 6f;
        }
        float hurt = Module.SCREENGLOW.flag("hurt") ? MathHelper.clamp(mc.player.hurtTime / 10f, 0f, 1f) : 0f;
        if (low > 0f || hurt > 0f) {
            float beat = 0.65f + 0.35f * MathHelper.sin(System.currentTimeMillis() / 140f);
            float red = Math.max(Math.min(1f, low * 1.5f), hurt);
            cTop = Effects.lerpRgb(cTop, 0xFF2020, red); cBot = Effects.lerpRgb(cBot, 0xFF2020, red);
            cL = Effects.lerpRgb(cL, 0xFF2020, red); cR = Effects.lerpRgb(cR, 0xFF2020, red);
            a = Math.max(a, Math.max(0.35f + 0.5f * low * beat, hurt * 0.9f));
        }

        int A = (int) (255 * MathHelper.clamp(a, 0f, 1f) * 0.6f);
        if (A < 3) return;

        g.fillGradient(0, 0, w, th, col(cTop, A), col(cTop, 0));
        g.fillGradient(0, h - th, w, h, col(cBot, 0), col(cBot, A));
        int step = Math.max(2, th / 8);
        for (int x = 0; x < th; x += step) {
            float f = 1f - x / (float) th;
            int al = (int) (A * f * f);
            if (al < 2) continue;
            g.fill(x, th / 2, x + step, h - th / 2, col(cL, al));
            g.fill(w - x - step, th / 2, w - x, h - th / 2, col(cR, al));
        }
    }

    private static int col(int rgb, int a) { return (MathHelper.clamp(a, 0, 255) << 24) | (rgb & 0xFFFFFF); }
}
