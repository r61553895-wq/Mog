package dev.pulsefx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Module {
    public static final List<Module> ALL = new ArrayList<>();

    public static final Module JUMP_CIRCLES = new Module("circles", "Jump Circles", "Visuals", true)
            .num("size", "Size", 0.5f, 2.5f, 0.1f, 1.2f)
            .num("life", "Duration (ms)", 400f, 1800f, 50f, 900f);
    public static final Module TRAIL = new Module("trail", "Trail", "Visuals", false)
            .num("length", "Length", 8f, 60f, 1f, 28f)
            .num("height", "Height", 0.3f, 0.9f, 0.05f, 0.55f);
    public static final Module HIT_FX = new Module("hit", "Hit FX", "Visuals", true)
            .num("count", "Particles", 0f, 40f, 1f, 14f)
            .bool("ring", "Ground ring", true);
    public static final Module TARGET_ESP = new Module("target", "Target ESP", "Visuals", true)
            .mode("style", "Style", 0, "Bands", "Ring", "Both")
            .num("speed", "Speed", 0.5f, 3f, 0.1f, 1f);
    public static final Module HUD = new Module("hud", "HUD", "HUD", true)
            .bool("coords", "Coordinates", true)
            .bool("list", "Module list", true);
    public static final Module NEARBY = new Module("nearby", "Nearby Players", "HUD", false)
            .mode("mode", "Mode", 0, "List", "Radar")
            .mode("side", "Side", 0, "Right", "Left")
            .num("range", "Range (blocks)", 10f, 256f, 5f, 64f)
            .num("max", "Max players", 3f, 15f, 1f, 8f)
            .bool("health", "Health", true)
            .bool("dist", "Distance", true);
    public static final Module SWING = new Module("swing", "Swing Animation", "Motion", false)
            .mode("anim", "Animation", 0, "Smooth", "Slash", "Spin", "Stab", "Chop", "Whip", "Flip", "Vanilla")
            .num("duration", "Duration (ticks)", 4f, 20f, 1f, 9f)
            .num("power", "Intensity", 0.5f, 1.5f, 0.05f, 1f);
    public static final Module VIEWMODEL = new Module("viewmodel", "View Model", "View", false)
            .num("x", "Position X", -1f, 1f, 0.02f, 0f)
            .num("y", "Position Y", -1f, 1f, 0.02f, 0f)
            .num("z", "Position Z", -1f, 1f, 0.02f, 0f)
            .num("rx", "Rotation X", -180f, 180f, 1f, 0f)
            .num("ry", "Rotation Y", -180f, 180f, 1f, 0f)
            .num("rz", "Rotation Z", -180f, 180f, 1f, 0f)
            .num("scale", "Scale", 0.4f, 1.6f, 0.05f, 1f);
    public static final Module THEME = new Module("theme", "Accent", "Theme", true)
            .hue("c1", "Color A", 0.74f)
            .hue("c2", "Color B", 0.52f)
            .bool("rainbow", "Rainbow", false);

    static { THEME.noToggle = true; THEME.alwaysOpen = true; }

    public final String id, label, category;
    public boolean on, noToggle, alwaysOpen, expanded, wasDown;
    public int bind;
    public final List<Setting> settings = new ArrayList<>();
    private final Map<String, Setting> map = new HashMap<>();
    public float anim, hudA, hover, openAnim; // UI smoothing state

    private Module(String id, String label, String category, boolean on) {
        this.id = id; this.label = label; this.category = category; this.on = on;
        this.anim = on ? 1f : 0f;
        ALL.add(this);
    }

    private Module add(Setting s) { settings.add(s); map.put(s.id, s); return this; }
    private Module num(String id, String l, float min, float max, float step, float def) { return add(Setting.num(id, l, min, max, step, def)); }
    private Module bool(String id, String l, boolean def) { return add(Setting.bool(id, l, def)); }
    private Module mode(String id, String l, int def, String... m) { return add(Setting.mode(id, l, def, m)); }
    private Module hue(String id, String l, float def) {
        Setting s = Setting.num(id, l, 0f, 1f, 0.005f, def); s.hue = true; return add(s);
    }

    public float num(String id) { return map.get(id).v; }
    public boolean flag(String id) { return map.get(id).b; }
    public int mode(String id) { return map.get(id).mode; }
    public Setting s(String id) { return map.get(id); }
}
