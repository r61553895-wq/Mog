package dev.pulsefx;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private Config() {}

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pulsefx.json");

    public static int c1 = 0x9B5CFF, c2 = 0x35E6FF;
    public static boolean rainbow;

    /** Re-reads accent colors from the Theme module. */
    public static void refresh() {
        c1 = Fx.rgb(Module.THEME.num("c1"));
        c2 = Fx.rgb(Module.THEME.num("c2"));
        rainbow = Module.THEME.flag("rainbow");
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
                JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
                for (Module m : Module.ALL) {
                    if (!mods.has(m.id)) continue;
                    JsonObject mo = mods.getAsJsonObject(m.id);
                    if (mo.has("on") && !m.noToggle) m.on = mo.get("on").getAsBoolean();
                    if (mo.has("bind")) m.bind = mo.get("bind").getAsInt();
                    if (mo.has("s")) {
                        JsonObject so = mo.getAsJsonObject("s");
                        for (Setting s : m.settings) {
                            if (!so.has(s.id)) continue;
                            switch (s.type) {
                                case BOOL -> s.b = so.get(s.id).getAsBoolean();
                                case NUM -> s.v = MathHelper.clamp(so.get(s.id).getAsFloat(), s.min, s.max);
                                case MODE -> s.mode = MathHelper.clamp(so.get(s.id).getAsInt(), 0, s.modes.length - 1);
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        for (Module m : Module.ALL) {
            m.anim = m.on ? 1f : 0f;
            m.hudA = m.anim;
            for (Setting s : m.settings) s.anim = s.type == Setting.Type.NUM ? s.norm() : (s.b ? 1f : 0f);
        }
        refresh();
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            JsonObject mods = new JsonObject();
            for (Module m : Module.ALL) {
                JsonObject mo = new JsonObject();
                mo.addProperty("on", m.on);
                mo.addProperty("bind", m.bind);
                JsonObject so = new JsonObject();
                for (Setting s : m.settings) {
                    switch (s.type) {
                        case BOOL -> so.addProperty(s.id, s.b);
                        case NUM -> so.addProperty(s.id, s.v);
                        case MODE -> so.addProperty(s.id, s.mode);
                    }
                }
                mo.add("s", so);
                mods.add(m.id, mo);
            }
            root.add("modules", mods);
            Files.writeString(FILE, root.toString());
        } catch (Exception ignored) {
        }
    }
}
