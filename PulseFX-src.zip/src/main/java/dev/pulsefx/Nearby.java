package dev.pulsefx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Nearby {
    private Nearby() {}

    record Row(String name, float dist, float hp, float maxHp, double dx, double dz) {}

    private static final int R = 42;
    private static final int PILL = 0xB4101018;
    private static final List<Row> ROWS = new ArrayList<>();

    public static void render(DrawContext g, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Module.NEARBY.on || mc.player == null || mc.world == null || mc.options.hudHidden) return;

        float range = Module.NEARBY.num("range");
        int max = (int) Module.NEARBY.num("max");
        float td = tc.getTickDelta(true);
        Vec3d me = mc.player.getLerpedPos(td);

        ROWS.clear();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            Vec3d pp = p.getLerpedPos(td);
            double dx = pp.x - me.x, dy = pp.y - me.y, dz = pp.z - me.z;
            float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d > range) continue;
            ROWS.add(new Row(p.getName().getString(), d, p.getHealth(), Math.max(1f, p.getMaxHealth()), dx, dz));
        }
        ROWS.sort((a, b) -> Float.compare(a.dist(), b.dist()));

        TextRenderer tr = mc.textRenderer;
        boolean right = Module.NEARBY.mode("side") == 0;
        int sw = g.getScaledWindowWidth();
        int y0 = g.getScaledWindowHeight() / 2 - 46;

        if (Module.NEARBY.mode("mode") == 1) drawRadar(g, mc, tr, right ? sw - 6 - 2 * R : 6, y0, range);
        else drawList(g, tr, right ? sw - 6 - 124 : 6, y0, max);
    }

    private static void drawRadar(DrawContext g, MinecraftClient mc, TextRenderer tr, int x, int y, float range) {
        int d = 2 * R;
        Ui.rr(g, x - 1, y - 1, d + 2, d + 2, R + 1, Fx.argb(Fx.gradT(0f), 0.28f));
        Ui.rr(g, x, y, d, d, R, 0xC8101018);
        g.fill(x + R - 1, y + 5, x + R, y + d - 5, 0x14FFFFFF);
        g.fill(x + 5, y + R - 1, x + d - 5, y + R, 0x14FFFFFF);

        // soft sweep
        float ang = (float) (Fx.ms() * 0.0022);
        float ca = (float) Math.cos(ang), sa = (float) Math.sin(ang);
        for (int k = 3; k < R - 2; k++) {
            int px = x + R + Math.round(ca * k), py = y + R + Math.round(sa * k);
            g.fill(px, py, px + 1, py + 1, Fx.argb(Fx.gradT(0f), 0.30f * (1f - k / (float) R)));
        }

        float yaw = (float) Math.toRadians(mc.gameRenderer.getCamera().getYaw());
        float cy = (float) Math.cos(yaw), sy = (float) Math.sin(yaw);
        for (Row r : ROWS) {
            double rx = -r.dx() * cy - r.dz() * sy;
            double ry = -r.dx() * sy + r.dz() * cy;
            float sx = (float) (rx / range * R), sz = (float) (-ry / range * R);
            float len = (float) Math.sqrt(sx * sx + sz * sz);
            if (len > R - 4) { sx *= (R - 4) / len; sz *= (R - 4) / len; }
            int col = Fx.lerp(0xFF4040, 0x40FF80, Fx.clamp01(r.hp() / r.maxHp()));
            Ui.rr(g, x + R + sx - 2.5f, y + R + sz - 2.5f, 5, 5, 2, Fx.argb(col, 0.25f));
            Ui.rr(g, x + R + sx - 1.5f, y + R + sz - 1.5f, 3, 3, 1, Fx.argb(col, 1f));
        }
        Ui.rr(g, x + R - 2, y + R - 2, 4, 4, 2, 0xFFFFFFFF);
        String t = ROWS.size() + "";
        Ui.text(g, tr, t, x + R - tr.getWidth(t) / 2, y + d + 3, 0xFF9A9AB2);
    }

    private static void drawList(DrawContext g, TextRenderer tr, int x, int y, int max) {
        boolean showHp = Module.NEARBY.flag("health"), showDist = Module.NEARBY.flag("dist");
        String title = "Nearby (" + ROWS.size() + ")";
        Ui.rr(g, x, y, 124, 15, 7, PILL);
        Ui.gradText(g, tr, title, x + 7, y + 4, 1f, 0.09f);
        y += 18;
        int n = Math.min(max, ROWS.size());
        for (int i = 0; i < n; i++) {
            Row r = ROWS.get(i);
            Ui.rr(g, x, y, 124, 14, 6, PILL);
            Ui.text(g, tr, tr.trimToWidth(r.name(), 56), x + 7, y + 3, 0xFFE6E6F4);
            int rightEdge = x + 118;
            if (showDist) {
                String ds = String.format(Locale.ROOT, "%.0fm", r.dist());
                Ui.textR(g, tr, ds, rightEdge, y + 3, 0xFF9A9AB2);
                rightEdge -= tr.getWidth(ds) + 5;
            }
            if (showHp) {
                float f = Fx.clamp01(r.hp() / r.maxHp());
                Ui.rr(g, rightEdge - 24, y + 5, 24, 4, 2, 0x30FFFFFF);
                Ui.bar(g, rightEdge - 24, y + 5, 24f * f, 4, Fx.argb(Fx.lerp(0xFF4040, 0x40FF80, f), 1f));
            }
            y += 16;
        }
        if (ROWS.size() > n) Ui.text(g, tr, "+" + (ROWS.size() - n) + " more", x + 7, y + 1, 0xFF7A7A92);
    }
}
