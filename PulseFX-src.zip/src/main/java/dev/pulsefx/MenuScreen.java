package dev.pulsefx;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

/** Compact floating panel: spring open/close, sliding tab pill, inertial scroll, animated controls. */
public class MenuScreen extends Screen {
    private static final String[] TABS = {"Visuals", "HUD", "Motion", "View", "Theme"};
    private static final int W = 344, H = 226;
    private static final int K_TAB = 0, K_MOD = 1, K_BOOL = 2, K_MODE = 3, K_SLIDER = 4;
    private static final int BG = 0xF2101017, DIM = 0xFF8B8BA3, TXT = 0xFFECECF4;
    private static final int HEAD_H = 26, ROW_H = 20, TRACK_W = 92;

    private record Hit(int x, int y, int w, int h, int kind, int idx, Module m, Setting s) {}

    private final Fx.Clock clock = new Fx.Clock();
    private final Fx.Spring open = new Fx.Spring(0f);
    private final Fx.Spring indX = new Fx.Spring(0f), indW = new Fx.Spring(40f);
    private final float[] tabSel = new float[TABS.length], tabHov = new float[TABS.length];
    private final int[] tabX = new int[TABS.length], tabW = new int[TABS.length];
    private final List<Hit> hits = new ArrayList<>();

    private int tab;
    private boolean closing, firstFrame = true;
    private float scroll, scrollT, tabFade = 1f, am = 1f, maxScroll;
    private Module binding;
    private Setting dragging;
    private int dragX;
    private float lcx, lcy, lscale = 1f, loff;
    private int crx, cry, crw, crh, ppx, ppy;

    public MenuScreen() { super(Text.literal("PulseFX")); }

    @Override public boolean shouldPause() { return false; }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    @Override public void removed() { Config.save(); }

    private int c(int argb) { return Ui.a(argb, am); }

    private static boolean in(float mx, float my, int x, int y, int w, int h) {
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }

    private List<Module> tabModules() {
        List<Module> out = new ArrayList<>();
        for (Module m : Module.ALL) if (m.category.equals(TABS[tab])) out.add(m);
        return out;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        float dt = clock.tick();
        open.target = closing ? 0f : 1f;
        open.step(dt, 17f, closing ? 1f : 0.62f);
        if (closing && open.p < 0.015f) { client.setScreen(null); return; }

        float p = MathHelper.clamp(open.p, 0f, 1.2f);
        float ga = Fx.clamp01(p * 1.25f);
        float s = 0.92f + 0.08f * p;
        int cx = width / 2, cy = height / 2;
        int px = cx - W / 2, py = cy - H / 2;
        float off = (1f - Math.min(p, 1f)) * 12f;
        lcx = cx; lcy = cy; lscale = s; loff = off; ppx = px; ppy = py;
        float mxl = cx + (mx - cx) / s, myl = cy + (my - cy - off) / s;
        am = ga;

        g.fillGradient(0, 0, width, height, Ui.a(0x66050510, ga),
                Ui.a(0xFF000000 | Fx.lerp(0x0A0A14, Config.c1, 0.22f), 0.55f * ga));

        hits.clear();
        MatrixStack ms = g.getMatrices();
        ms.push();
        ms.translate(cx, cy + off, 0f);
        ms.scale(s, s, 1f);
        ms.translate(-cx, -cy, 0f);

        Ui.shadow(g, px, py, W, H, 12, ga);
        Ui.rr(g, px - 1, py - 1, W + 2, H + 2, 13, c(0x1EFFFFFF));
        Ui.rr(g, px, py, W, H, 12, c(BG));

        // header
        ms.push();
        ms.translate(px + 15, py + 9, 0f);
        ms.scale(1.3f, 1.3f, 1f);
        Ui.gradText(g, textRenderer, "PulseFX", 0, 0, ga, 0.08f);
        ms.pop();
        Ui.textR(g, textRenderer, "v1.1", px + W - 14, py + 11, c(0xFF565670));

        drawTabs(g, dt, px, py + 32, mxl, myl);
        drawContent(g, dt, px, py, mxl, myl);

        ms.pop();
        firstFrame = false;
    }

    private void drawTabs(DrawContext g, float dt, int px, int ty, float mx, float my) {
        int x = px + 12;
        for (int i = 0; i < TABS.length; i++) {
            tabW[i] = textRenderer.getWidth(TABS[i]) + 20;
            tabX[i] = x;
            x += tabW[i] + 3;
        }
        indX.target = tabX[tab];
        indW.target = tabW[tab];
        if (firstFrame) { indX.snap(tabX[tab]); indW.snap(tabW[tab]); }
        indX.step(dt, 24f, 0.78f);
        indW.step(dt, 24f, 0.78f);

        int acc = Fx.gradT(0f);
        Ui.rr(g, indX.p, ty, Math.max(8, Math.round(indW.p)), 18, 9, c(Fx.argb(acc, 0.20f)));
        Ui.bar(g, indX.p + indW.p / 2f - 5f, ty + 16, 10f, 1, c(Fx.argb(Fx.gradT(0.3f), 0.9f)));

        for (int i = 0; i < TABS.length; i++) {
            boolean hov = in(mx, my, tabX[i], ty, tabW[i], 18);
            tabSel[i] = Fx.damp(tabSel[i], i == tab ? 1f : 0f, 16f, dt);
            tabHov[i] = Fx.damp(tabHov[i], hov ? 1f : 0f, 18f, dt);
            int col = Fx.lerp(0x8B8BA3, 0xFFFFFF, Math.max(tabSel[i], tabHov[i] * 0.7f));
            Ui.text(g, textRenderer, TABS[i], tabX[i] + 10, ty + 5, c(0xFF000000 | col));
            hits.add(new Hit(tabX[i], ty, tabW[i], 18, K_TAB, i, null, null));
        }
    }

    private void drawContent(DrawContext g, float dt, int px, int py, float mx, float my) {
        int rx = px + 10, ry = py + 56, rw = W - 20, rh = H - 66;
        crx = rx; cry = ry; crw = rw; crh = rh;

        tabFade = Fx.damp(tabFade, 1f, 11f, dt);
        scroll = Fx.damp(scroll, scrollT, 15f, dt);
        float saved = am;
        am = saved * Fx.smooth(tabFade);
        float slide = (1f - Fx.smooth(tabFade)) * 8f;

        g.enableScissor(rx - 2, ry, rx + rw + 2, ry + rh);
        float y = ry - scroll + slide;
        float startY = y;
        for (Module m : tabModules()) {
            y += drawModule(g, dt, m, rx, y, rw, mx, my) + 5f;
        }
        g.disableScissor();

        float contentH = y - startY;
        maxScroll = Math.max(0f, contentH - rh);
        scrollT = MathHelper.clamp(scrollT, 0f, maxScroll);

        if (maxScroll > 0f) {
            int bg = BG;
            g.fillGradient(rx - 2, ry, rx + rw + 2, ry + 9, c(bg), c(bg & 0xFFFFFF));
            g.fillGradient(rx - 2, ry + rh - 9, rx + rw + 2, ry + rh, c(bg & 0xFFFFFF), c(bg));
            float th = Math.max(16f, rh * rh / (contentH));
            float ty = ry + (rh - th) * (scroll / maxScroll);
            Ui.rr(g, rx + rw + 3, ty, 2, (int) th, 1, c(0x40FFFFFF));
        }
        am = saved;
    }

    /** Draws one module card. Returns its animated height. */
    private float drawModule(DrawContext g, float dt, Module m, int rx, float y, int rw, float mx, float my) {
        boolean visible = y + HEAD_H > cry - 120 && y < cry + crh + 400;
        boolean hovHead = in(mx, my, rx, (int) y, rw, HEAD_H) && in(mx, my, crx, cry, crw, crh);
        m.hover = Fx.damp(m.hover, hovHead ? 1f : 0f, 18f, dt);
        m.anim = Fx.damp(m.anim, m.on ? 1f : 0f, 16f, dt);
        boolean wantOpen = m.alwaysOpen || m.expanded;
        m.openAnim = Fx.damp(m.openAnim, wantOpen ? 1f : 0f, 13f, dt);
        float oa = Fx.smooth(m.openAnim);
        int n = m.settings.size();
        float body = n * ROW_H + 8f;
        float h = HEAD_H + body * oa;

        if (!visible) { addSettingAnimState(m, dt); return h; }

        int ix = (int) Math.floor(y);
        Ui.rr(g, rx, y, rw, Math.round(h), 8, c(Ui.a(0xFFFFFFFF, 0.075f + 0.06f * m.hover)));

        if (!m.noToggle) {
            if (m.anim > 0.02f) Ui.rr(g, rx, y + 7, 2, HEAD_H - 14, 1, c(Fx.argb(Fx.gradT(y * 0.004f), m.anim)));
            Ui.toggle(g, rx + 11, (int) y + 7, 24, 12, m.anim, am);
        } else {
            // live gradient preview
            int steps = 18, bw = 22;
            for (int i = 0; i < steps; i++) {
                int col = Fx.argb(Fx.gradT(i / (float) steps), 0.95f);
                g.fill(rx + 11 + i * 2, (int) y + 9, rx + 13 + i * 2, (int) y + 17, c(col));
            }
        }
        int lx = m.noToggle ? rx + 11 + 18 * 2 + 8 : rx + 44;
        int lc = Fx.lerp(0x8B8BA3, 0xFFFFFF, Math.max(m.anim * 0.7f, m.hover * 0.6f));
        if (m.noToggle) lc = 0xFFFFFF;
        Ui.text(g, textRenderer, m.label, lx, (int) y + 9, c(0xFF000000 | lc));

        int rightEdge = rx + rw - 10;
        if (!m.settings.isEmpty() && !m.alwaysOpen) {
            Ui.chevron(g, rx + rw - 15, y + HEAD_H / 2f, m.openAnim * 90f, c(Ui.a(0xFFFFFFFF, 0.35f + 0.4f * m.hover)));
            rightEdge -= 14;
        }
        if (!m.noToggle && (m.bind != 0 || binding == m)) {
            String t = binding == m ? "..." : InputUtil.fromKeyCode(m.bind, 0).getLocalizedText().getString();
            int tw = textRenderer.getWidth(t) + 10;
            float pulse = binding == m ? 0.55f + 0.45f * (float) Math.sin(Fx.ms() * 0.01) : 0.5f;
            Ui.rr(g, rightEdge - tw, y + 7, tw, 12, 6, c(Fx.argb(Fx.gradT(0.2f), 0.16f + 0.1f * pulse)));
            Ui.text(g, textRenderer, t, rightEdge - tw + 5, (int) y + 9, c(0xFFD0D0E4));
        }
        hits.add(new Hit(rx, (int) y, rw, HEAD_H, K_MOD, 0, m, null));

        if (oa > 0.02f) {
            float savedAm = am;
            am = savedAm * oa * oa;
            g.enableScissor(rx, ix, rx + rw, ix + Math.round(h));
            for (int i = 0; i < n; i++) {
                float sy = y + HEAD_H + 3 + i * ROW_H + (1f - oa) * -6f;
                drawSetting(g, dt, m.settings.get(i), rx, sy, rw, mx, my);
            }
            g.disableScissor();
            am = savedAm;
        } else {
            addSettingAnimState(m, dt);
        }
        return h;
    }

    private void addSettingAnimState(Module m, float dt) {
        for (Setting s : m.settings) {
            s.anim = Fx.damp(s.anim, s.type == Setting.Type.NUM ? s.norm() : (s.b ? 1f : 0f), 20f, dt);
        }
    }

    private void drawSetting(DrawContext g, float dt, Setting s, int rx, float sy, int rw, float mx, float my) {
        int right = rx + rw - 11;
        boolean hov = in(mx, my, rx, (int) sy, rw, ROW_H) && in(mx, my, crx, cry, crw, crh);
        s.hover = Fx.damp(s.hover, (hov || dragging == s) ? 1f : 0f, 18f, dt);
        Ui.text(g, textRenderer, s.label, rx + 16, (int) sy + 6, c(Ui.a(0xFFFFFFFF, 0.55f + 0.35f * s.hover)));

        switch (s.type) {
            case BOOL -> {
                s.anim = Fx.damp(s.anim, s.b ? 1f : 0f, 18f, dt);
                Ui.toggle(g, right - 22, (int) sy + 4, 22, 11, s.anim, am);
                hits.add(new Hit(rx, (int) sy, rw, ROW_H, K_BOOL, 0, null, s));
            }
            case MODE -> {
                int pw = 96;
                Ui.rr(g, right - pw, sy + 3, pw, 14, 7, c(Ui.a(0xFFFFFFFF, 0.08f + 0.05f * s.hover)));
                String t = s.modes[s.mode];
                Ui.text(g, textRenderer, t, right - pw / 2 - textRenderer.getWidth(t) / 2, (int) sy + 6,
                        c(0xFF000000 | Fx.gradT(0.1f)));
                Ui.text(g, textRenderer, "<", right - pw + 5, (int) sy + 6, c(0xFF565670));
                Ui.text(g, textRenderer, ">", right - 10, (int) sy + 6, c(0xFF565670));
                hits.add(new Hit(right - pw, (int) sy, pw, ROW_H, K_MODE, 0, null, s));
            }
            case NUM -> {
                s.anim = Fx.damp(s.anim, s.norm(), 24f, dt);
                String val = s.display();
                int tx = right - 34;
                Ui.textR(g, textRenderer, val, right, (int) sy + 6, c(0xFFD0D0E4));
                int x0 = tx - 8 - TRACK_W;
                float ty = sy + 8.5f;
                float f = Fx.clamp01(s.anim);
                if (s.hue) {
                    for (int i = 0; i < TRACK_W / 4; i++) {
                        g.fill(x0 + i * 4, (int) ty, x0 + i * 4 + 4, (int) ty + 3, c(0xFF000000 | Fx.rgb(i / (TRACK_W / 4f))));
                    }
                } else {
                    Ui.rr(g, x0, ty, TRACK_W, 3, 1, c(0x26FFFFFF));
                    Ui.bar(g, x0, ty, TRACK_W * f, 3, c(Fx.argb(Fx.gradT(0.2f), 0.95f)));
                }
                float kr = 3.5f + 1.2f * s.hover;
                float kx = x0 + TRACK_W * f;
                if (s.hover > 0.02f) Ui.rr(g, kx - kr - 2, ty + 1.5f - kr - 2, Math.round(kr * 2 + 4), Math.round(kr * 2 + 4),
                        (int) kr + 2, c(Fx.argb(Fx.gradT(0.2f), 0.18f * s.hover)));
                Ui.rr(g, kx - kr, ty + 1.5f - kr, Math.round(kr * 2), Math.round(kr * 2), (int) kr, c(0xFFFFFFFF));
                hits.add(new Hit(x0 - 4, (int) sy, TRACK_W + 8, ROW_H, K_SLIDER, 0, null, s));
            }
        }
    }

    // ------------------------------------------------------------------ input

    private float toLocalX(double mx) { return lcx + ((float) mx - lcx) / lscale; }
    private float toLocalY(double my) { return lcy + ((float) my - lcy - loff) / lscale; }

    private void slide(Setting s, float mxl) {
        s.setNorm((mxl - dragX) / TRACK_W);
        if (Module.THEME.settings.contains(s)) Config.refresh();
    }

    @Override
    public boolean mouseClicked(double mxRaw, double myRaw, int button) {
        if (closing) return true;
        float mx = toLocalX(mxRaw), my = toLocalY(myRaw);
        if (!in(mx, my, ppx, ppy, W, H)) { closing = true; return true; }
        binding = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!in(mx, my, h.x(), h.y(), h.w(), h.h())) continue;
            if (h.kind() != K_TAB && !in(mx, my, crx, cry, crw, crh)) continue;
            switch (h.kind()) {
                case K_TAB -> { if (tab != h.idx()) { tab = h.idx(); scrollT = 0f; scroll = 0f; tabFade = 0f; } }
                case K_MOD -> {
                    Module m = h.m();
                    if (button == 0 && !m.noToggle) { m.on = !m.on; Config.save(); }
                    else if (button == 1 && !m.settings.isEmpty() && !m.alwaysOpen) m.expanded = !m.expanded;
                    else if (button == 2 && !m.noToggle) binding = m;
                }
                case K_BOOL -> { h.s().b = !h.s().b; Config.refresh(); Config.save(); }
                case K_MODE -> {
                    Setting s = h.s();
                    int n = s.modes.length;
                    s.mode = (s.mode + (button == 1 ? n - 1 : 1)) % n;
                    Config.save();
                }
                case K_SLIDER -> { dragging = h.s(); dragX = h.x() + 4; slide(dragging, mx); }
                default -> { }
            }
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { slide(dragging, toLocalX(mx)); return true; }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) { dragging = null; Config.save(); }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scrollT = MathHelper.clamp(scrollT - (float) vAmount * 30f, 0f, maxScroll);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding != null) {
            binding.bind = keyCode == 256 ? 0 : keyCode;
            binding = null;
            Config.save();
            return true;
        }
        if (keyCode == 256 || (PulseFX.menuKey != null && PulseFX.menuKey.matchesKey(keyCode, scanCode))) {
            closing = true;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
