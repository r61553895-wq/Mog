package dev.pulsefx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import java.util.Locale;

public final class Hud {
    private Hud() {}

    private static final Fx.Clock CLOCK = new Fx.Clock();
    private static final int PILL = 0xB4101018;

    public static void render(DrawContext g, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float dt = CLOCK.tick();
        for (Module m : Module.ALL) {
            if (m.noToggle) continue;
            m.hudA = Fx.damp(m.hudA, m.on ? 1f : 0f, 11f, dt);
        }
        if (!Module.HUD.on || mc.player == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int sw = g.getScaledWindowWidth();

        // Watermark
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        String info = "  " + mc.getCurrentFps() + " fps  " + ping + " ms";
        int w = tr.getWidth("PulseFX") + tr.getWidth(info) + 14;
        Ui.rr(g, 6, 6, w, 15, 7, PILL);
        int x = Ui.gradText(g, tr, "PulseFX", 13, 10, 1f, 0.07f);
        Ui.text(g, tr, info, x, 10, 0xFF9A9AB2);

        int y = 24;
        if (Module.HUD.flag("coords")) {
            String c = String.format(Locale.ROOT, "%.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            int cw = tr.getWidth(c) + 14;
            Ui.rr(g, 6, y, cw, 15, 7, PILL);
            Ui.text(g, tr, c, 13, y + 4, 0xFFD6D6E6);
            y += 18;
        }

        if (Module.HUD.flag("list")) {
            float ry = 6f;
            for (Module m : Module.ALL) {
                if (m.noToggle || m == Module.HUD || m.hudA < 0.01f) continue;
                float a = Fx.smooth(m.hudA);
                int mw = tr.getWidth(m.label) + 14;
                float mx = sw - 6 - mw + (1f - a) * (mw + 10);
                Ui.rr(g, mx, ry, mw, 14, 6, Ui.a(PILL, a));
                Ui.rr(g, mx + 1, ry + 4, 2, 6, 1, Fx.argb(Fx.gradT(ry * 0.01f), a));
                Ui.text(g, tr, m.label, (int) mx + 7, (int) ry + 3, Fx.argb(0xE6E6F4, a));
                ry += 17f * a;
            }
        }
    }
}
