package dev.pulsefx;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

/** Keyframed first-person swing animations with eased, continuous interpolation. */
public final class SwingAnim {
    private SwingAnim() {}

    public static final int VANILLA = 7;
    public static float realProgress;

    enum Ease { IO, OUT, IN, QUART, BACK }

    record Key(float t, Ease e, float x, float y, float z, float rx, float ry, float rz) {}

    record Anim(float px, float py, float pz, boolean fullRot, Key[] keys) {}

    private static final float[] POSE = new float[6];
    private static final Key ZERO = k(0f, Ease.IO, 0, 0, 0, 0, 0, 0);

    private static Key k(float t, Ease e, float x, float y, float z, float rx, float ry, float rz) {
        return new Key(t, e, x, y, z, rx, ry, rz);
    }

    private static final Anim[] ANIMS = {
        // Smooth
        new Anim(0f, 0f, 0f, false, new Key[]{
            ZERO,
            k(0.28f, Ease.OUT, -0.05f, 0.02f, -0.10f, 14, 8, -6),
            k(0.62f, Ease.IO, 0.04f, -0.16f, -0.34f, -58, -22, 14),
            k(1f, Ease.IO, 0, 0, 0, 0, 0, 0)}),
        // Slash
        new Anim(0f, 0f, 0f, false, new Key[]{
            ZERO,
            k(0.22f, Ease.OUT, 0.18f, 0.10f, -0.05f, 10, 30, 34),
            k(0.55f, Ease.QUART, -0.32f, -0.22f, -0.30f, -64, -36, -50),
            k(1f, Ease.IO, 0, 0, 0, 0, 0, 0)}),
        // Spin
        new Anim(0f, -0.15f, -0.30f, true, new Key[]{
            ZERO,
            k(0.15f, Ease.OUT, 0f, 0.04f, -0.10f, 8, 0, 0),
            k(0.82f, Ease.IO, 0f, -0.02f, -0.18f, -350, 0, 0),
            k(1f, Ease.IO, 0, 0, 0, -360, 0, 0)}),
        // Stab
        new Anim(0f, 0f, 0f, false, new Key[]{
            ZERO,
            k(0.30f, Ease.IO, 0f, 0.04f, 0.10f, 8, 0, 0),
            k(0.52f, Ease.OUT, -0.03f, -0.05f, -0.62f, -10, 0, 0),
            k(1f, Ease.IO, 0, 0, 0, 0, 0, 0)}),
        // Chop
        new Anim(0f, 0f, 0f, false, new Key[]{
            ZERO,
            k(0.28f, Ease.OUT, 0f, 0.14f, -0.06f, 40, 0, 0),
            k(0.58f, Ease.QUART, 0f, -0.30f, -0.36f, -76, 0, 0),
            k(1f, Ease.IO, 0, 0, 0, 0, 0, 0)}),
        // Whip
        new Anim(0f, 0f, 0f, false, new Key[]{
            ZERO,
            k(0.25f, Ease.OUT, 0.16f, 0.08f, 0f, 0, 22, 30),
            k(0.50f, Ease.OUT, -0.34f, 0f, -0.20f, 0, -40, -62),
            k(0.72f, Ease.IO, -0.10f, 0f, 0f, 0, -12, -20),
            k(1f, Ease.BACK, 0, 0, 0, 0, 0, 0)}),
        // Flip
        new Anim(0f, -0.10f, -0.20f, true, new Key[]{
            ZERO,
            k(0.35f, Ease.OUT, 0f, 0.22f, -0.30f, -130, 0, 0),
            k(1f, Ease.IO, 0, 0, 0, -360, 0, 0)}),
        null // Vanilla
    };

    public static boolean custom() {
        return Module.SWING.on && Module.SWING.mode("anim") != VANILLA;
    }

    private static float ease(Ease e, float u) {
        switch (e) {
            case OUT: { float v = 1f - u; return 1f - v * v * v; }
            case IN: return u * u * u;
            case QUART: { float v = 1f - u; return 1f - v * v * v * v; }
            case BACK: { float v = u - 1f; return 1f + 2.70158f * v * v * v + 1.70158f * v * v; }
            default: return 0.5f - 0.5f * (float) Math.cos(Math.PI * u);
        }
    }

    private static void sample(Anim a, float t) {
        Key[] ks = a.keys();
        t = Fx.clamp01(t);
        int j = 0;
        while (j < ks.length - 2 && t >= ks[j + 1].t()) j++;
        Key p = ks[j], q = ks[j + 1];
        float span = q.t() - p.t();
        float u = span <= 0f ? 1f : Fx.clamp01((t - p.t()) / span);
        float w = ease(q.e(), u);
        POSE[0] = p.x() + (q.x() - p.x()) * w;
        POSE[1] = p.y() + (q.y() - p.y()) * w;
        POSE[2] = p.z() + (q.z() - p.z()) * w;
        POSE[3] = p.rx() + (q.rx() - p.rx()) * w;
        POSE[4] = p.ry() + (q.ry() - p.ry()) * w;
        POSE[5] = p.rz() + (q.rz() - p.rz()) * w;
    }

    public static void apply(MatrixStack m, Arm arm, float progress) {
        Anim a = ANIMS[Module.SWING.mode("anim")];
        if (a == null) return;
        sample(a, progress);
        float side = arm == Arm.RIGHT ? 1f : -1f;
        float pw = Module.SWING.num("power");
        float rs = a.fullRot() ? 1f : pw;
        m.translate(POSE[0] * pw * side, POSE[1] * pw, POSE[2] * pw);
        m.translate(a.px() * side, a.py(), a.pz());
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(POSE[3] * rs));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(POSE[4] * side * rs));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(POSE[5] * side * rs));
        m.translate(-a.px() * side, -a.py(), -a.pz());
    }
}
