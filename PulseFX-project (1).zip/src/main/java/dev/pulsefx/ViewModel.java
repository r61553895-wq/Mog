package dev.pulsefx;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

public final class ViewModel {
    private ViewModel() {}

    /** Called right after vanilla moved the matrix to the hand position, so rotations pivot around the hand. */
    public static void apply(MatrixStack m, Arm arm) {
        Module v = Module.VIEWMODEL;
        float side = arm == Arm.RIGHT ? 1f : -1f;
        m.translate(side * v.num("x"), v.num("y"), v.num("z"));
        float rx = v.num("rx"), ry = v.num("ry"), rz = v.num("rz");
        if (rx != 0f) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rx));
        if (ry != 0f) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * ry));
        if (rz != 0f) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * rz));
        float s = v.num("scale");
        if (s != 1f) m.scale(s, s, s);
    }
}
