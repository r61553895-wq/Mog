package dev.pulsefx;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Keyframe based replacement for the vanilla first-person swing.
 * Every animation is identity at progress 0 and 1, so it never leaves the item "stuck".
 * Keyframe poses are written for the RIGHT arm and mirrored for the left one.
 */
public final class SwingAnim {
    private SwingAnim() {}

    public static final int VANILLA = 7;

    /** Real swing progress of the hand currently rendered (vanilla value is zeroed by the mixin, see HeldItemRendererMixin). */
    public static float realProgress;

    private enum Ease { IO, OUT, IN, QUART, BACK }

    /** Pose: translation x/y/z (blocks) and rotation x/y/z (degrees). */
    private record Key(float t, Ease e, float x, float y, float z, float rx, float ry, float rz) {}

    /** pivot = point (relative to the hand) the rotations happen around; fullRot = ignore Intensity for rotations (360 spins). */
    private record Anim(float px, float py, float pz, boolean fullRot, Key... keys) {}

    private static Key k(float t, Ease e, float x, float y, float z, float rx, float ry, float rz) {
        return new Key(t, e, x, y, z, rx, ry, rz);
    }

    private static final Key ZERO = k(0f, Ease.IO, 0, 0, 0, 0, 0, 0);

    private static final Anim[] ANIMS = {
            // 0 Smooth: soft, slow arc forward and down
            new Anim(-0.04f, -0.08f, 0.12f, false,
                    ZERO,
                    k(0.40f, Ease.IO, 0.03f, -0.05f, -0.10f, -60, -10, -12),
                    k(1.00f, Ease.IO, 0, 0, 0, 0, 0, 0)),
            // 1 Slash: wind-up to the right, fast diagonal cut to the left, overshoot
            new Anim(-0.06f, -0.08f, 0.12f, false,
                    ZERO,
                    k(0.24f, Ease.IO, 0.06f, 0.06f, 0.04f, 12, -14, -24),
                    k(0.52f, Ease.QUART, -0.20f, -0.10f, -0.20f, -34, 34, 50),
                    k(0.70f, Ease.OUT, -0.24f, -0.12f, -0.22f, -38, 40, 56),
                    k(1.00f, Ease.IO, 0, 0, 0, 0, 0, 0)),
            // 2 Spin: full 360 turn around the item
            new Anim(0, 0, 0, true,
                    ZERO,
                    k(0.12f, Ease.OUT, 0, 0.06f, 0, 0, 0, 0),
                    k(0.88f, Ease.IO, 0, 0.06f, -0.14f, -8, 360, 0),
                    k(1.00f, Ease.IO, 0, 0, 0, 0, 360, 0)),
            // 3 Stab: pull back, then a sharp thrust forward
            new Anim(0, 0, 0, false,
                    ZERO,
                    k(0.30f, Ease.IO, 0, 0.03f, 0.14f, 16, 0, -4),
                    k(0.50f, Ease.QUART, -0.02f, -0.04f, -0.62f, -10, 0, 4),
                    k(0.66f, Ease.OUT, -0.02f, -0.04f, -0.66f, -12, 0, 4),
                    k(1.00f, Ease.IO, 0, 0, 0, 0, 0, 0)),
            // 4 Chop: raise, smash down, small bounce
            new Anim(-0.02f, -0.08f, 0.12f, false,
                    ZERO,
                    k(0.30f, Ease.OUT, 0.03f, 0.08f, 0.05f, 24, 0, -8),
                    k(0.52f, Ease.IN, -0.02f, -0.12f, -0.12f, -76, 0, 6),
                    k(0.62f, Ease.BACK, -0.02f, -0.10f, -0.10f, -68, 0, 4),
                    k(1.00f, Ease.IO, 0, 0, 0, 0, 0, 0)),
            // 5 Whip: horizontal backhand lash with overshoot
            new Anim(-0.08f, -0.05f, 0.15f, false,
                    ZERO,
                    k(0.26f, Ease.IO, 0.16f, 0, 0.04f, -4, -30, -14),
                    k(0.56f, Ease.BACK, -0.26f, -0.04f, -0.14f, -16, 56, 22),
                    k(0.80f, Ease.IO, -0.16f, -0.02f, -0.06f, -10, 30, 10),
                    k(1.00f, Ease.IO, 0, 0, 0, 0, 0, 0)),
            // 6 Flip: the item does a full forward flip
            new Anim(0f, 0.15f, -0.05f, true,
                    ZERO,
                    k(0.15f, Ease.OUT, 0, 0.08f, 0.06f, 10, 0, 0),
                    k(0.85f, Ease.IO, 0, 0.08f, -0.10f, -350, 0, 0),
                    k(1.00f, Ease.IO, 0, 0, 0, -360, 0, 0)),
    };

    private static final float[] pose = new float[6];

    private static float ease(Ease e, float u) {
        switch (e) {
            case OUT: { float v = 1f - u; return 1f - v * v * v; }
            case IN: return u * u * u;
            case QUART: { float v = 1f - u; return 1f - v * v * v * v; }
            case BACK: { float v = u - 1f; return 1f + 2.70158f * v * v * v + 1.70158f * v * v; }
            default: { // IO cubic
                if (u < 0.5f) return 4f * u * u * u;
                float v = -2f * u + 2f;
                return 1f - v * v * v / 2f;
            }
        }
    }

    private static void sample(Key[] ks, float p) {
        int j = 0;
        while (j < ks.length - 2 && p > ks[j + 1].t) j++;
        Key a = ks[j], b = ks[j + 1];
        float u = MathHelper.clamp((p - a.t) / (b.t - a.t), 0f, 1f);
        float e = ease(b.e, u);
        pose[0] = a.x + (b.x - a.x) * e;
        pose[1] = a.y + (b.y - a.y) * e;
        pose[2] = a.z + (b.z - a.z) * e;
        pose[3] = a.rx + (b.rx - a.rx) * e;
        pose[4] = a.ry + (b.ry - a.ry) * e;
        pose[5] = a.rz + (b.rz - a.rz) * e;
    }

    /** True when a custom (non-vanilla) animation is selected and the module is on. */
    public static boolean custom() {
        return Module.SWING.on && Module.SWING.mode("anim") != VANILLA;
    }

    /** @return true if the animation was applied (vanilla swing must be cancelled). */
    public static boolean apply(MatrixStack m, Arm arm, float vanillaProgress) {
        int mode = Module.SWING.mode("anim");
        if (mode == VANILLA || mode < 0 || mode >= ANIMS.length) return false;

        float raw = vanillaProgress > 0f ? vanillaProgress : realProgress;
        float p = MathHelper.clamp(raw, 0f, 1f);
        if (p <= 0f || p >= 1f) return true; // identity pose, but vanilla swing is still cancelled

        Anim a = ANIMS[mode];
        sample(a.keys, p);

        float k = Module.SWING.num("power");
        float rk = a.fullRot ? 1f : k;
        float i = arm == Arm.RIGHT ? 1f : -1f;

        m.translate(i * pose[0] * k, pose[1] * k, pose[2] * k);
        m.translate(i * a.px, a.py, a.pz);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * pose[4] * rk));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pose[3] * rk));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * pose[5] * rk));
        m.translate(-i * a.px, -a.py, -a.pz);
        return true;
    }
}
