package dev.pulsefx;

import net.minecraft.util.math.MathHelper;

import java.util.Locale;

public final class Setting {
    public enum Type { BOOL, NUM, MODE }

    public final Type type;
    public final String id, label;
    public boolean b;
    public float v, min, max, step;
    public String[] modes;
    public int mode;
    public float anim; // GUI animation

    private Setting(Type type, String id, String label) { this.type = type; this.id = id; this.label = label; }

    public static Setting bool(String id, String label, boolean def) {
        Setting s = new Setting(Type.BOOL, id, label); s.b = def; s.anim = def ? 1f : 0f; return s;
    }

    public static Setting num(String id, String label, float min, float max, float step, float def) {
        Setting s = new Setting(Type.NUM, id, label);
        s.min = min; s.max = max; s.step = step; s.v = def; return s;
    }

    public static Setting mode(String id, String label, String... modes) {
        Setting s = new Setting(Type.MODE, id, label); s.modes = modes; return s;
    }

    public void setNorm(double n) {
        float raw = (float) (min + (max - min) * MathHelper.clamp(n, 0.0, 1.0));
        v = MathHelper.clamp(Math.round(raw / step) * step, min, max);
    }

    public String display() {
        if (step >= 1f) return String.valueOf((int) v);
        return String.format(Locale.ROOT, step >= 0.1f ? "%.1f" : "%.2f", v);
    }
}
