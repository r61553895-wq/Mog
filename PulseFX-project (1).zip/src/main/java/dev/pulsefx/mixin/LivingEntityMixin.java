package dev.pulsefx.mixin;

import dev.pulsefx.Module;
import dev.pulsefx.SwingAnim;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {

    /** Slower swing for the local player only (purely visual, attacks and cooldowns are not affected). require = 0: never crash the game if this method changes. */
    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true, require = 0)
    private void pulsefx$swingDuration(CallbackInfoReturnable<Integer> cir) {
        if (!SwingAnim.custom()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && (Object) this == mc.player) {
            cir.setReturnValue((int) Module.SWING.num("duration"));
        }
    }
}
