package dev.pulsefx.mixin;

import dev.pulsefx.Module;
import dev.pulsefx.SwingAnim;
import dev.pulsefx.ViewModel;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {

    /**
     * Vanilla moves the item by a sin(sqrt(progress)) offset BEFORE applySwingOffset runs, which is why every custom
     * animation looked almost the same. We hide the progress from vanilla (0 = no offset) and keep the real value for SwingAnim.
     * ordinal 2 = third float argument = swingProgress (tickDelta, pitch, swingProgress, equipProgress).
     */
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
    private float pulsefx$hideVanillaSwing(float swingProgress) {
        SwingAnim.realProgress = swingProgress;
        if (swingProgress > 0f && SwingAnim.custom()) {
            MinecraftClient mc = MinecraftClient.getInstance();
            // empty hand uses its own arm swing, keep vanilla there
            if (mc.player != null && !mc.player.getMainHandStack().isEmpty()) return 0f;
        }
        return swingProgress;
    }

    @Inject(method = "applyEquipOffset", at = @At("TAIL"))
    private void pulsefx$viewModel(MatrixStack matrices, Arm arm, float equipProgress, CallbackInfo ci) {
        if (Module.VIEWMODEL.on) ViewModel.apply(matrices, arm);
    }

    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true)
    private void pulsefx$swing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        if (Module.SWING.on && SwingAnim.apply(matrices, arm, swingProgress)) ci.cancel();
    }
}
