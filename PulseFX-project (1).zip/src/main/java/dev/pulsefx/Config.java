package dev.pulsefx;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.MathHelper;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    public static int c1 = 0x9B5CFF, c2 = 0x35E6FF;
    public static boolean rainbow = false;

    private Config() {}

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("pulsefx.json"); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            if (o.has("c1")) c1 = o.get("c1").getAsInt();
            if (o.has("c2")) c2 = o.get("c2").getAsInt();
            if (o.has("rainbow")) rainbow = o.get("rainbow").getAsBoolean();
            if (!o.has("modules")) return;
            JsonObject ms = o.getAsJsonObject("modules");
            for (Module m : Module.ALL) {
                if (!ms.has(m.id)) continue;
                JsonObject mo = ms.getAsJsonObject(m.id);
                if (mo.has("on")) m.on = mo.get("on").getAsBoolean();
                if (mo.has("bind")) m.bind = mo.get("bind").getAsInt();
                if (!mo.has("s")) continue;
                JsonObject so = mo.getAsJsonObject("s");
                for (Setting s : m.settings) {
                    if (!so.has(s.id)) continue;
                    switch (s.type) {
                        case BOOL -> { s.b = so.get(s.id).getAsBoolean(); s.anim = s.b ? 1f : 0f; }
                        case NUM -> s.v = MathHelper.clamp(so.get(s.id).getAsFloat(), s.min, s.max);
                        case MODE -> s.mode = MathHelper.clamp(so.get(s.id).getAsInt(), 0, s.modes.length - 1);
                    }
                }
                m.anim = m.on ? 1f : 0f;
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("c1", c1);
            o.addProperty("c2", c2);
            o.addProperty("rainbow", rainbow);
            JsonObject ms = new JsonObject();
            for (Module m : Module.ALL) {
                JsonObject mo = new JsonObject();
                mo.addProperty("on", m.on);
                mo.addProperty("bind", m.bind);
                JsonObject so = new JsonObject();
                for (Setting s : m.settings) {
                    switch (s.type) {
                        case BOOL -> so.addProperty(s.id, s.b);
                        case NUM -> so.addProperty(s.id, s.v);
                        case MODE -> so.addProperty(s.id, s.mode);
                    }
                }
                mo.add("s", so);
                ms.add(m.id, mo);
            }
            o.add("modules", ms);
            Files.writeString(file(), o.toString());
        } catch (Exception ignored) {}
    }
}
