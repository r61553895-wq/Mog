package dev.pulsefx;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.ThreadLocalRandom;

public class PulseFX implements ClientModInitializer {
    public static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pulsefx.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.pulsefx"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Effects.tick(mc);

            boolean open = false;
            while (menuKey.wasPressed()) open = true;
            if (open && mc.currentScreen == null) mc.setScreen(new MenuScreen());

            if (mc.currentScreen == null && mc.player != null) {
                long win = mc.getWindow().getHandle();
                for (Module m : Module.ALL) {
                    if (m.bind < 0) continue;
                    boolean down = InputUtil.isKeyPressed(win, m.bind);
                    if (down && !m.wasDown) {
                        m.on = !m.on;
                        mc.player.sendMessage(Text.literal("§d[PulseFX] §f" + m.label + ": " + (m.on ? "§aON" : "§cOFF")), true);
                        Config.save();
                    }
                    m.wasDown = down;
                }
            }
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(Effects::render);
        HudRenderCallback.EVENT.register(Hud::render);
        HudRenderCallback.EVENT.register(Nearby::render);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && entity instanceof LivingEntity le) {
                if (Module.TARGET_ESP.on) Effects.setTarget(le);
                if (Module.HIT_FX.on) {
                    ThreadLocalRandom r = ThreadLocalRandom.current();
                    double cy = le.getBodyY(0.5);
                    int n = (int) Module.HIT_FX.num("count");
                    for (int i = 0; i < n; i++) {
                        world.addParticle(i % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.ENCHANTED_HIT,
                                le.getX(), cy, le.getZ(),
                                (r.nextDouble() - 0.5) * 0.5, r.nextDouble() * 0.35, (r.nextDouble() - 0.5) * 0.5);
                    }
                    if (Module.HIT_FX.flag("ring")) Effects.addCircle(le.getX(), le.getY(), le.getZ());
                }
            }
            return ActionResult.PASS;
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            var root = ClientCommandManager.literal("pulsefx");
            for (Module m : Module.ALL) {
                root.then(ClientCommandManager.literal(m.id).executes(ctx -> {
                    m.on = !m.on;
                    Config.save();
                    ctx.getSource().sendFeedback(Text.literal("§d[PulseFX] §f" + m.label + ": " + (m.on ? "§aON" : "§cOFF")));
                    return 1;
                }));
            }
            dispatcher.register(root);
        });
    }
}
